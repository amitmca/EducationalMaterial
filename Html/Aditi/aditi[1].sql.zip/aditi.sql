-- phpMyAdmin SQL Dump
-- version 2.11.5
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Jan 14, 2009 at 04:01 PM
-- Server version: 5.0.51
-- PHP Version: 5.2.5

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";

--
-- Database: `aditi`
--

-- --------------------------------------------------------

--
-- Table structure for table `mobiles`
--

CREATE TABLE `mobiles` (
  `fname` varchar(50) NOT NULL,
  `addr` varchar(100) NOT NULL,
  `company` varchar(10) NOT NULL,
  `model` varchar(15) NOT NULL,
  `month` varchar(12) NOT NULL,
  `day` varchar(2) NOT NULL,
  `year` varchar(4) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `mobiles`
--

INSERT INTO `mobiles` (`fname`, `addr`, `company`, `model`, `month`, `day`, `year`) VALUES
('Amit Anil Bhalerao', 'Morgaon Road,Baramati', 'NOKIA', 'Nokia3500', '9', '27', '2009'),
('Gauri Shankar Bhagat', 'Morgaon Road,Baramati', 'SONY', 'SONY1421', '8', '24', '2009');

-- --------------------------------------------------------

--
-- Table structure for table `recharge`
--

CREATE TABLE `recharge` (
  `fname` varchar(50) NOT NULL,
  `mobile` varchar(10) NOT NULL,
  `scratch` varchar(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `recharge`
--

INSERT INTO `recharge` (`fname`, `mobile`, `scratch`) VALUES
('Amit Anil Bhalerao', '9760163853', '123456789123451'),
('Ajit Anil BHalerao', '9423015260', '123456789123456');

-- --------------------------------------------------------

--
-- Table structure for table `sim`
--

CREATE TABLE `sim` (
  `fname` varchar(50) NOT NULL,
  `addr` varchar(100) NOT NULL,
  `city` varchar(30) NOT NULL,
  `contact` varchar(10) NOT NULL,
  `month` varchar(15) NOT NULL,
  `day` varchar(2) NOT NULL,
  `year` varchar(4) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `sim`
--

INSERT INTO `sim` (`fname`, `addr`, `city`, `contact`, `month`, `day`, `year`) VALUES
('Amit Anil Bhalerao', 'Morgaon Road', 'Baramati', '9730163853', '9', '27', '2009'),
('Gauri Shankar Bhagat', 'Morgaon Bhagat', 'Baramati', '9860640614', '8', '27', '2009'),
('Ajit Anil Bhalerao', 'Morgaon Road', 'baramati', '9423015260', '10', '27', '2009'),
('Priyanka Vinayak Bhalerao', 'Morgoan Road ', 'Baramati', '9874561234', '2', '2', '2009');

-- phpMyAdmin SQL Dump
-- version 2.11.5
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Jan 27, 2009 at 02:11 PM
-- Server version: 5.0.51
-- PHP Version: 5.2.5

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";

--
-- Database: `hotel`
--

-- --------------------------------------------------------

--
-- Table structure for table `record`
--

CREATE TABLE `record` (
  `rno` int(3) NOT NULL,
  `fname` varchar(30) NOT NULL,
  `addr` varchar(50) NOT NULL,
  `city` varchar(25) NOT NULL,
  `contact` decimal(10,0) NOT NULL,
  `no` int(3) NOT NULL,
  `month` varchar(12) NOT NULL,
  `day` varchar(2) NOT NULL,
  `year` int(4) NOT NULL,
  `day1` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `record`
--

INSERT INTO `record` (`rno`, `fname`, `addr`, `city`, `contact`, `no`, `month`, `day`, `year`, `day1`) VALUES
(100, 'Amit Anil Bhalerao', 'Morgoan Road', 'baramati', '9860960529', 3, '1', '27', 2009, 'tuesday'),
(102, 'Ajit Anil Bhalerao', 'Morgaon Road', 'baramati', '9860960529', 3, '2', '25', 2009, 'sunday'),
(100, 'Amit Anil Bhalerao', 'Morgaon Road', 'baramati', '9730163853', 5, '1', '26', 2009, 'sunday'),
(105, 'Sarang Vinayak Bhalerao', 'Morgoan Road', 'baramati', '9860960529', 5, '1', '27', 2009, 'monday'),
(105, 'Aniket Anil Bhandare', 'Pragati Nagar', 'Baramati', '9860650412', 5, '1', '28', 2009, 'monday'),
(110, 'Aniket anil Bhandare', 'Morgoan Road', 'Baramati', '9860960529', 3, '1', '28', 2009, 'sunday');

-- --------------------------------------------------------

--
-- Table structure for table `room`
--

CREATE TABLE `room` (
  `rno` int(3) NOT NULL,
  `fname` varchar(30) NOT NULL,
  `addr` varchar(50) NOT NULL,
  `city` varchar(25) NOT NULL,
  `contact` decimal(10,0) NOT NULL,
  `no` int(3) NOT NULL,
  `month` varchar(12) NOT NULL,
  `day` varchar(2) NOT NULL,
  `year` int(4) NOT NULL,
  `day1` varchar(10) NOT NULL,
  PRIMARY KEY  (`rno`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `room`
--

INSERT INTO `room` (`rno`, `fname`, `addr`, `city`, `contact`, `no`, `month`, `day`, `year`, `day1`) VALUES
(110, 'Aniket anil Bhandare', 'Morgoan Road', 'Baramati', '9860960529', 3, '1', '28', 2009, 'sunday');

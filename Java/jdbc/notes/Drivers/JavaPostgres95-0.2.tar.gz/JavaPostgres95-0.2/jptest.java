// a sample application to use the postgres java interface via jdbc.

// Copyright (c) 1996 Bradley McLean / Jeffrey Medeiros
//
// You may distribute under the terms of the GNU Public License as
// specified in the README file that comes with the JavaPostgres95 Kit

import java.sql.*;

class jptest {
   public static void main(String argv[]) {
      try {
//         DriverManager.setLogStream(System.out);

         Driver pgd = (Driver) new postgres95.PGDriver();

         String url = "jdbc:postgres95:jdatabase";

         Connection conn = DriverManager.getConnection(url,"user","pass");

         Statement stat = conn.createStatement();

         ResultSet rs = stat.executeQuery("Select * from weather");

         while ( rs.next() ) {
            String city = rs.getString(1);
            short lo = rs.getShort(2);
            short hi = rs.getShort(3);
            float prcp = rs.getFloat(4);
            Date date = rs.getDate(5);
            System.out.println(city+" "+lo+" "+hi+" "+prcp+" "+date);
         }
      } catch ( Exception e ) {
         System.err.println("E: "+e);
      }
   }
}

// Java Interface to Postgres
// 03/28/96 B. McLean

// Copyright (c) 1996 Bradley McLean / Jeffrey Medeiros
//
// You may distribute under the terms of the GNU Public License as
// specified in the README file that comes with the JavaPostgres95 Kit

package postgres95;

import java.sql.*;
import java.util.*;

/**
 * JDBC Interface to Postgres95 functions
 */
 
public class PGDriver implements Driver
{
   static final int MAJORVERSION = 1;
   static final int MINORVERSION = 0;

   static java.util.Vector connections = new Vector();

   // Each Driver should also support a null constructor so it can be
   // instantiated by doing
   //	 	java.sql.Driver d = Class.forName("foo.bah.Driver").newInstance(c);
   public PGDriver() throws SQLException {
      DriverManager.registerDriver(this);
   }

   // Try to make a database connection to the given URL.
   // The driver should return "null" if it realizes it is the wrong kind
   // of driver to connect to the given URL.  This will be common, as when
   // the JDBC driver manager is asked to connect to a given URL it passes
   // the URL to each loaded driver in turn.
   //
   // The driver should raise a SQLException if it is the right 
   // driver to connect to the given URL, but has trouble connecting to
   // the database.
   //
   // The java.util.Properties argument can be used to passed arbitrary
   // string tag/value pairs as connection arguments.
   // Normally at least a "user" and  "password" properties should be
   // included in the Properties.

   public Connection connect(String url, java.util.Properties info)
						throws SQLException {
      PGConnection PGC;

      /*
       * Decompose the url, and verify that it's for us.           
       */
      
      String host = null;
      String port = null;
      String dbname = null;
      int index = url.indexOf(':');
      
      if ( index == -1 )
         return null;	// illegal URL
      if ( url.substring(0,index).compareTo("jdbc") != 0 )
         return null;	// wrong type of URL
      url = url.substring(index+1);
      index = url.indexOf(':');
      if ( index == -1 )
         return null;	// illegal format
      if ( url.substring(0,index).compareTo("postgres95") != 0 )
         return null;	// wrong type of database
      url = url.substring(index+1);
      if ( url.substring(0,2).compareTo("//") == 0 ) {
         url = url.substring(2);
         index = url.indexOf('/');
         if ( index == -1 )
            host = url;
         else {
            host = url.substring(0,index);
            dbname = url.substring(index+1);
         }
         index = host.indexOf(':');
         if ( index != -1 ) {
            port = host.substring(index+1);
            host = host.substring(0,index);
         }
      } else
         dbname = url;
      // Further parsing of database name here in future?
      // (Pull the options / username, etc out of the url?

      // Start with any environmental defaults
      String pghost = info.getProperty("PGHOST");
      String pgport = info.getProperty("PGPORT");
      String pgoptions = info.getProperty("PGOPTIONS");
      String pgtty = info.getProperty("PGTTY");
      String pguser = info.getProperty("user");
      String pgpass = info.getProperty("password");
            
      // Plug in available info from the url.    
      if ( host != null )
         pghost = host;
      if ( port != null )
         pgport = port;
      
      // And use hard defaults for anything not defined.
      if ( pghost == null )
         pghost = "localhost";
      if ( pgport == null )
         pgport = "5432";
      if ( pgoptions == null )
         pgoptions = "";
      if ( pgtty == null )
         pgtty = "";
      if ( dbname == null )
         return null;	// Should we throw an exception here?
                                                
      PGC = new PGConnection(this,pghost,pgport,pgoptions,
                                        	pgtty,dbname,pguser,pgpass);
      // Keep track of our Connections                                                
      connections.addElement((Object) PGC);
      return PGC;
   }
   
   void closeConnection(PGConnection child) {
      connections.removeElement((Object) child);
   }
   
   // getMajorVersion and getMinorVersion return the major and minor
   // versions of the driver.  Initially these should be 1 and 0.
   public int getMajorVersion() {
      return MAJORVERSION;
   }
   public int getMinorVersion() {
      return MINORVERSION;
   }

   public boolean acceptsURL(String url) throws SQLException 
   {
      return false;
   }

   public DriverPropertyInfo[] getPropertyInfo(String url, java.util.Properties info) throws SQLException 
   {
      return(null);   
   }

   public boolean jdbcCompliant()
   {
       return false;
   }

} 


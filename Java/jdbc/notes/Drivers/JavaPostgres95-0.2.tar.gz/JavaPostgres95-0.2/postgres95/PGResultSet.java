// Java Interface to Postgres
// 03/28/96 B. McLean

// Copyright (c) 1996 Bradley McLean / Jeffrey Medeiros
//
// You may distribute under the terms of the GNU Public License as
// specified in the README file that comes with the JavaPostgres95 Kit

package postgres95;

import java.sql.*;
import java.util.*;
import java.io.*;

/**
 * JDBC Interface to Postgres95 functions
 */

class PGColumn {
   String name;
   int	oid;
   short size;
}

public class PGResultSet implements ResultSet
{
   PGStatement parent;
   String name;
   Vector columns;
   Vector tuples;
   int currentRow;

   /**
    * Helper function to read a Tuple from the server
    *
    */
   private Vector readTuple(DataInputStream in,short nfields,boolean binary)
                                        	 throws SQLException {
      Vector data = new Vector();
      int bytes = nfields / 8;
      int i;
      int bitmap_index = 0;
      int bitcnt = 0;
      int bmap;
System.out.println("readTuple1: ");

      try {
         if ( (nfields % 8) > 0 )
            bytes++;
         byte [] bitmap = new byte[bytes];
         in.read(bitmap,0,bytes);
System.out.println("readTuple2: "+bytes);

         bmap = bitmap[bitmap_index];

         for ( i=0; i < nfields; i++ ) {
            if ( (bmap & 0x80) == 0 )
               data.addElement(null);	// will this work?
            else {
               int len = parent.readint4();
System.out.println("readTuple3: "+len);
               if ( ! binary )
                  len -= 4;
               if ( len > 0 ) {
                  byte [] value = new byte[len];
                  in.read(value,0,len);
                  if ( ! binary )
                     data.addElement(new String(value,0));
                  else
                     data.addElement(value);
               } else if ( ! binary )
                  data.addElement("");
               else
                  data.addElement(null);
            }
            if ( ++bitcnt == 8 ) {
               bmap = bitmap[++bitmap_index];
               bitcnt = 0;
            } else
               bmap <<= 1;
   	 }
      } catch ( Exception e ) {
         throw new SQLException("Network error reading results");
      }
      return data;
   }

   /**
    * Helper function to read a result set from the network
    *
    */
   private void readResult(DataInputStream in) throws SQLException {

      short loop;
      short nfields;
      int type;

      // Reset the class
      columns = new Vector();
      tuples = new Vector();
      currentRow = 0;
System.out.println("readResult1: ");

      try {
         // First, pull in the attribute table
         nfields = parent.readint2();
System.out.println("readResult2: "+nfields);
         while ( nfields-- > 0 ) {
            PGColumn col = new PGColumn();
            col.name = parent.readline();
            col.oid = parent.readint4();
            col.size = parent.readint2();
            columns.addElement(col);
System.out.println("readResult2a: "+col.name+","+col.oid+","+col.size);
         }
System.out.println("readResult3: ");
         // Now, pull in the tuple results
         boolean loop2 = true;
         while ( loop2 ) {
            type = in.read();
System.out.println("readResult4: "+type);
            switch ( type ) {
            case 'T':
               throw new SQLException("Multiple tuple results not supported");
            case 'B':	// read binary tuple
            case 'D':	// read ascii tuple
               tuples.addElement(
                  	readTuple(in,(short) columns.size(),type == 'B'));
               break;
               case 'A':
               throw new SQLException("Asychronous portals not supported");
            case 'C':	// end of stream
               String command = parent.readline();
               loop2 = false;
               break;
            case 'E':	// errors
               String error = parent.readline();
               throw new SQLException("Tuple Error: "+error);
            case 'N':	// Notices from the server
               String notice = parent.readline();
               SQLWarning nw = new SQLWarning("Error: "+notice);
               if ( parent.warnings != null )
                  nw.setNextException(parent.warnings);
               parent.warnings = nw;
               break;
            default:
               throw new SQLException("Network protocol error reading results");
            }
         }
      } catch ( Exception e ) {
         throw new SQLException("Network error reading results");
      }
   }

   /**
    * Constructor for a result set
    *
    */
   PGResultSet(PGStatement st,String portal,DataInputStream in)
                                        	throws SQLException {
      parent = st;
      name = portal;

      readResult(in);
   }

   /**
    * Helper functions to get the current object
    *
    */

   private String value(String columnName) throws SQLException {
      for ( int loop=0; loop < columns.size(); loop++ ) {
         PGColumn col = (PGColumn) columns.elementAt(loop);
         if ( col.name.equals(columnName) )
            return value(loop+1);
      }
      return null ;
   }

   private Object value(int row,int column) throws SQLException {
      try {
         return ((Vector) tuples.elementAt(row-1)).elementAt(column-1);
      } catch ( Exception e ) {
         throw new SQLException("Out of result set bounds? " + e );
      }
   }
   private Object ovalue(int column) throws SQLException {
      try {
         return ((Vector) tuples.elementAt(currentRow-1)).elementAt(column-1);
      } catch ( Exception e ) {
         throw new SQLException("Out of result set bounds? " + e );
      }
   }
   private String value(int column) throws SQLException {
      try {
         return (String) (((Vector) tuples.elementAt(currentRow-1)).elementAt(column-1));
      } catch ( Exception e ) {
         throw new SQLException("Out of result set bounds? " + e );
      }
   }

   private byte [] bvalue(String columnName) throws SQLException {
      for ( int loop=0; loop < columns.size(); loop++ ) {
         PGColumn col = (PGColumn) columns.elementAt(loop);
         if ( col.name.equals(columnName) )
            return bvalue(loop+1);
      }
      return null;
   }

   private byte [] bvalue(int column) throws SQLException {
      try {
         return (byte [])(((Vector) tuples.elementAt(currentRow-1)).elementAt(column-1));
      } catch ( Exception e ) {
         throw new SQLException("Out of result set bounds? " + e );
      }
   }

   // The isNull() method returns true if the given column in the
   // current row holds the SQL "null".
   public boolean isNull(int column) throws SQLException {
      return (value(column) == null);
   }

   // New API (JPM)
   public boolean wasNull() throws SQLException {
      // check to see if the last access threw an exception
      return false; // fake it for now
   }

   // Methods for accessing columns in the current row.
   public String getString(int column) throws SQLException {
      try {
         return value(column);
      } catch ( Exception e ) {
         throw new SQLException("Result conversion error: "+e);
      }
   }
   // Methods for accessing columns in the column name.
   public String getString(String columnName) throws SQLException {
      try {
         return value(columnName);
      } catch ( Exception e ) {
         throw new SQLException("Result conversion error: "+e);
      }
   }
   public boolean getBoolean(int column) throws SQLException {
      try {
         return ( value(column).compareTo("t") == 0 );
      } catch ( Exception e ) {
         throw new SQLException("Result conversion error: "+e);
      }
   }
   public boolean getBoolean(String columnName) throws SQLException {
      try {
         return ( value(columnName).compareTo("t") == 0 );
      } catch ( Exception e ) {
         throw new SQLException("Result conversion error: "+e);
      }
   }
   public byte getByte(int column) throws SQLException {
      try {
         return (byte) Integer.valueOf(value(column)).intValue();
      } catch ( Exception e ) {
         throw new SQLException("Result conversion error: "+e);
      }
   }
   public byte getByte(String columnName) throws SQLException {
      try {
         return (byte) Integer.valueOf(value(columnName)).intValue();
      } catch ( Exception e ) {
         throw new SQLException("Result conversion error: "+e);
      }
   }
   public short getShort(int column) throws SQLException {
      try {
         return (short) Integer.valueOf(value(column)).intValue();
      } catch ( Exception e ) {
         throw new SQLException("Result conversion error: "+e);
      }
   }
   public short getShort(String columnName) throws SQLException {
      try {
         return (short) Integer.valueOf(value(columnName)).intValue();
      } catch ( Exception e ) {
         throw new SQLException("Result conversion error: "+e);
      }
   }
   public int getInt(int column) throws SQLException {
      try {
         return Integer.valueOf(value(column)).intValue();
      } catch ( Exception e ) {
         throw new SQLException("Result conversion error: "+e);
      }
   }
   public int getInt(String columnName) throws SQLException {
      try {
         return Integer.valueOf(value(columnName)).intValue();
      } catch ( Exception e ) {
         throw new SQLException("Result conversion error: "+e);
      }
   }
   public long getLong(int column) throws SQLException {
      try {
         return Long.valueOf(value(column)).longValue();
      } catch ( Exception e ) {
         throw new SQLException("Result conversion error: "+e);
      }
   }
   public long getLong(String columnName) throws SQLException {
      try {
         return Long.valueOf(value(columnName)).longValue();
      } catch ( Exception e ) {
         throw new SQLException("Result conversion error: "+e);
      }
   }
   public float getFloat(int column) throws SQLException {
      try {
         return Float.valueOf(value(column)).floatValue();
      } catch ( Exception e ) {
         throw new SQLException("Result conversion error: "+e);
      }
   }
   public float getFloat(String columnName) throws SQLException {
      try {
         return Float.valueOf(value(columnName)).floatValue();
      } catch ( Exception e ) {
         throw new SQLException("Result conversion error: "+e);
      }
   }
   public double getDouble(int column) throws SQLException {
      try {
         return Double.valueOf(value(column)).doubleValue();
      } catch ( Exception e ) {
         throw new SQLException("Result conversion error: "+e);
      }
   }
   public double getDouble(String columnName) throws SQLException {
      try {
         return Double.valueOf(value(columnName)).doubleValue();
      } catch ( Exception e ) {
         throw new SQLException("Result conversion error: "+e);
      }
   }
   public Bignum getBignum(int column, int scale)
                                        	throws SQLException {
      try {
         return new Bignum(value(column),scale);
      } catch ( Exception e ) {
         throw new SQLException("Result conversion error: "+e);
      }
   }
   public Bignum getBignum(String columnName, int scale)
                                        	throws SQLException {
      try {
         return new Bignum(value(columnName),scale);
      } catch ( Exception e ) {
         throw new SQLException("Result conversion error: "+e);
      }
   }

   public byte[] getBytes(int column) throws SQLException {
      return bvalue(column);	// Copy this first?
   }
   public byte[] getBytes(String columnName) throws SQLException {
      return bvalue(columnName);	// Copy this first?
   }

   public byte[] getLongBinaryStream(int column) throws SQLException {
      return bvalue(column);	// Copy this first?
   }
   public byte[] getLongBinaryStream(String columnName) throws SQLException {
      return bvalue(columnName);	// Copy this first?
   }

   public java.sql.Date getDate(int column) throws SQLException {
      try {
         String temp = value(column);
         int month = Integer.valueOf(temp.substring(0,2)).intValue();
         int day = Integer.valueOf(temp.substring(3,5)).intValue();
         int year = Integer.valueOf(temp.substring(6,10)).intValue();
         return new java.sql.Date(year-1900,month-1,day);
      } catch ( Exception e ) {
         throw new SQLException("Result conversion error: "+e);
      }
   }

   public java.sql.Date getDate(String columnName) throws SQLException
   {
      return(null);
   }

   public java.sql.Time getTime(int column) throws SQLException {
      try {
         String temp = value(column);
         int hour = Integer.valueOf(temp.substring(0,2)).intValue();
         int minute = Integer.valueOf(temp.substring(3,5)).intValue();
         int second = Integer.valueOf(temp.substring(6,9)).intValue();
         return new java.sql.Time(hour,minute,second);
      } catch ( Exception e ) {
         throw new SQLException("Result conversion error: "+e);
      }
   }

   public java.sql.Time getTime(String columnName) throws SQLException
   {
      return(null);
   }

   public java.sql.Timestamp getTimestamp(int column)
                                        	throws SQLException {
      try {
         return null;	// Postgres does not have this type.
      } catch ( Exception e ) {
         throw new SQLException("Result conversion error: "+e);
      }
   }

   public java.sql.Timestamp getTimestamp(String columnName)
   {
      return(null);
   }


   // The normal getChars and getBinary methods are suitable for
   // reading normal sized data.  However occasionally it may be
   // necessary to access LONGVARCHAR or LONGVARBINARY fields that
   // are multiple Megabytes in size.  To support this case we provide
   // getCharStream and getBinaryStream methods that return Java
   // IO streams from which data can be read in chunks.

   public java.io.InputStream getAsciiStream(int column)
                                        	throws SQLException {
      String temp = value(column);
      byte [] temp2 = new byte[temp.length()];
      temp.getBytes(0,temp.length(),temp2,0);
      return new ByteArrayInputStream(temp2);
   }

   public java.io.InputStream getAsciiStream(String columnName) throws SQLException
   {
       return(null);
   }

   public java.io.InputStream getUnicodeStream(int column)
                                        	throws SQLException {
      return getAsciiStream(column);	// Bad Implementation!
   }

   public java.io.InputStream getUnicodeStream(String columnName) throws SQLException
   {
      return(null);
   }

   public java.io.InputStream getBinaryStream(int column)
                                        	throws SQLException {
      return new ByteArrayInputStream(bvalue(column));
   }

   public java.io.InputStream getBinaryStream(String columnName) throws SQLException
   {
       return(null);
   }

   // next moves us to the next row of the results.
   // It returns true if if has moved to a valid row, false if
   // all the rows have been processed.
   public boolean next() throws SQLException {
      return (++currentRow <= tuples.size());
   }

   // Return the number of the current row.  The first row containing
   // actual data is row 1.
   public int getRowNumber() throws SQLException {
      return currentRow;
   }

   // Return the number of columns in the ResultSet
   public int getColumnCount() throws SQLException {
      return columns.size();
   }

   // The total number of rows returned by the query.  Note that on some
   // databases this method may be very expensive.
   public int getRowCount() throws SQLException {
      return tuples.size();
   }

   // close frees up internal state associated with the ResultSet
   // You should normally call close when you are done with a ResultSet
   // ResultSets are also closed automatically when their Statement is closed.
   public void close() throws SQLException {
      columns = null;
      tuples = null;
   }

   //----------------------------------------------------------------------
   // Advanced features:

   // getCursorname returns a cursor name that can be used to identify the
   // current position in the Resultset to a separate statement that is
   // executing a positioned update or positioned delete.  If the database
   // doesn't support positioned delete or update, it may return "" here.
   public String getCursorName() throws SQLException {
      return "";
   }

   // You can obtain a ResultMetaData object to obtain information
   // about the number, types and properties of the result columns.
   public ResultSetMetaData getMetaData() throws SQLException {
      return new PGResultSetMetaData(this);
   }

   public Object getObject(String columnName) throws SQLException
   {
      return(null);
   }

   // You can obtain a column result as a Java Object.
   // See the JDBC spec's "Dynamic Programming" chapter for details.
   public Object getObject(int column) throws SQLException {
      // BIG TIME COP OUT BRAD: NEED TO CONVERT THE PG TYPE TO THE JDBC TYPE
      //switch( sqlType ) {
      switch( 0 ) {
      case Types.BIT:
         return new Boolean(getBoolean(column));
      case Types.TINYINT:
         return new Integer((int) getByte(column));
      case Types.SMALLINT:
         return new Integer((int) getShort(column));
      case Types.INTEGER:
         return new Integer(getInt(column));
      case Types.BIGINT:
         return new Long(getLong(column));
      case Types.FLOAT:
         return new Float(getDouble(column));
      case Types.REAL:
         return new Float(getFloat(column));
      case Types.DOUBLE:
         return new Double(getDouble(column));
      case Types.NUMERIC:
         // Should we examine the metadata to find out how to scale?
         return getBignum(column,0);
      case Types.DECIMAL:
         // Should we examine the metadata to find out how to scale?
         return getBignum(column,0);
      case Types.CHAR:
         return getString(column);
      case Types.VARCHAR:
         return getString(column);
      case Types.LONGVARCHAR:
         return getAsciiStream(column);
      case Types.DATE:
         return getDate(column);
      case Types.TIME:
         return getTime(column);
      case Types.TIMESTAMP:
         return getTimestamp(column);
      case Types.BINARY:
         return getBytes(column);
      case Types.VARBINARY:
         return getBytes(column);
      case Types.LONGVARBINARY:
         return getBinaryStream(column);
      case Types.NULL:
         return null;
      default:
         return null;
      }
   }

   public SQLWarning getWarnings() throws SQLException
   {
       return(null);
   }

   public void clearWarnings() throws SQLException
   {

   }

   public int findColumn(String columnName) throws SQLException
   {
      return(0);
   }
}


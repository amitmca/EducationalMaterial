// Java Interface to Postgres
// 03/28/96 B. McLean

// Copyright (c) 1996 Bradley McLean / Jeffrey Medeiros
//
// You may distribute under the terms of the GNU Public License as
// specified in the README file that comes with the JavaPostgres95 Kit

package postgres95;

import java.sql.*;
import java.util.*;
import java.net.*;

/**
 * JDBC Interface to Postgres95 functions
 */

class PGNotify {
   int pid;
   String name;
   PGNotify(int p,byte nm[]) {
      pid = p;
      name = new String(nm,0);
   }
}

public class PGStatement implements Statement
{
   static final int MAX_MESSAGE_LEN = 8194;
   PGConnection parent;
   long results;

   int MaxFieldSize = 8192;
   int MaxRows = 0;
   boolean escape = true;
   long QueryTimeout = 0;
   SQLWarning warnings = null;
   Vector resultSets;
   Vector statuses;
   Vector notifies;
   int currentResult;

   PGStatement(PGConnection newparent) {
      parent = newparent;
      clearStatus();
   }

   private void clearStatus() {
      resultSets = new Vector();
      statuses = new Vector();
      notifies = new Vector();
      currentResult = 0;
   }
   private void sendQuery(String sql) throws SQLException {
      byte [] buf = new byte[8194];
      if ( sql.length() > (MAX_MESSAGE_LEN - 2) )
         throw new SQLException("Query too long.  Maximum is " +
                        	MAX_MESSAGE_LEN);
      buf[0] = 'Q';
      sql.getBytes(0,sql.length(),buf,1);
      buf[sql.length()+1] = 0;
      try {
         parent.sock_out.write(buf,0,sql.length()+2);
         parent.sock_out.flush();
      } catch (Exception e) {
         throw new SQLException("Network write error: "+e);
      }
   }

   protected String readline() throws SQLException {
      StringBuffer line = new StringBuffer();
      byte in;

      while ( true ) {
         try {
         in = (byte) parent.sock_in.read();
         } catch ( Exception e ) {
            throw new SQLException("Network read error: "+e);
         }
         if ( in == 0 )
            break;
         line.append((char)in);
      }
      return line.toString();
   }

   protected short readint2() throws SQLException {
      try {
         int ret = parent.sock_in.readUnsignedByte();
         return (short) (ret | (parent.sock_in.readUnsignedByte() << 8));
      } catch ( Exception e ) {
         throw new SQLException("Network read error: "+e);
      }
   }

   protected int readint4() throws SQLException {
      try {
         int ret = parent.sock_in.readUnsignedByte();
         ret |= parent.sock_in.readUnsignedByte() << 8;
         ret |= parent.sock_in.readUnsignedByte() << 16;
         return ret | (parent.sock_in.readUnsignedByte() << 24);
      } catch ( Exception e ) {
         throw new SQLException("Network read error: "+e);
      }
   }
   private void readResults() throws SQLException {
      int type;
      String pname = null;

      while ( true ) {
         try {
            type = parent.sock_in.read();
System.out.println("readResults1: "+type);
            switch ( type ) {
            case 'A': // Notify arrived
               int pid = readint2();
               byte [] name = new byte[16];
               parent.sock_in.readFully(name,0,16);
               if ( notifies == null )
                  notifies = new Vector();
               notifies.addElement(new PGNotify(pid,name));
               break;
            case 'C': // portal query command results - No Tuples
               statuses.addElement(readline());
               byte [] nullq = new byte[3];
               nullq[0] = 'Q';
               nullq[1] = ' ';
               nullq[2] = 0;

               while ( true ) {
                  parent.sock_out.write(nullq,0,3);
                  parent.sock_out.flush();	// send out a null query

                  String result = readline();
                  if ( result.length() > 0 )
                     if ( result.charAt(0) == 'I' ) {
                        if ( result.length() > 1 )
                           throw new SQLException("Network protocol failure");
                        break;
                     }
                  statuses.addElement(result);
               }
               return;
            case 'E': // Error result
               throw new SQLException("Error received",readline());
            case 'I': // Empty query
               if ( readline().length() > 0 )
                  throw new SQLException("Network protocol failure");
               resultSets.addElement( null);
               return;
            case 'N': // Notices from Backend
               SQLWarning nw = new SQLWarning("Error: "+readline());
               if ( warnings != null )
                  nw.setNextException(warnings);
               warnings = nw;
               break;
            case 'P': // Syncronous portal
               pname = readline();
               break;
            case 'T': // Tuple Results
               resultSets.addElement(new PGResultSet(this,pname,parent.sock_in));
               return;
            case 'D': // Copy Command begins (in)
//               return new PGResultSet(COPY_IN);	// empty result set
// how to handle this?
      	    return;
            case 'B': // Copy Command begins (out)
//               return new PGResultSet(COPY_OUT);	// empty result set
// how to handle this?
      	    return;
            default:	// Ruh Roh
               throw new SQLException("Network protocol error");
            }
         } catch ( SQLException e ) {
            throw e;
         } catch ( Exception e ) {
            throw new SQLException("Network read error: "+e);
         }
      }
   }

   // executeQuery method executes the given SQL string which must
   // be a query that returns a single ResultSet.
   // (See also the more general "execute" below.)
   public ResultSet executeQuery(String sql) throws SQLException {
      if ( execute(sql) )
         return (ResultSet) resultSets.firstElement();
      throw new SQLException("No ResultSet returned");
   }

   // This method execute a SQL statement that is known to be a simple
   // database update (such as a SQL UPDATE, INSERT, DELETE, ...)
   // The result is the number of rows that have been modified.
   // (See also the more general "execute" below.)
   public int executeUpdate(String sql) throws SQLException {
      execute(sql);
      if ( statuses.size() > 0 )
         try {
            return Integer.valueOf((String) statuses.firstElement()).intValue();
         } catch ( Exception e ) {
            return 1;
         }
      throw new SQLException("No Status returned");
   }

   // close frees up internal state associated with the statement.
   // You should normally call close when you are done with a statement.
   // N.B. any ResultSets associated with the Statement will become
   // unusable when the Statement is closed.
   public void close() throws SQLException {
   }

   //----------------------------------------------------------------------

   // The maxFieldSize is a limit (in bytes) on how much data can be
   // returned as part of a field.  If the limit is exceeded, the data
   // is truncated and a warning is added (see Statement.getWarnings).
   // You should normally not need to change the default limit.
   // Zero means no limit.
   public int getMaxFieldSize() throws SQLException {
      return MaxFieldSize;
   }
   public void setMaxFieldSize(int max) throws SQLException {
      MaxFieldSize = max;
   }

   // The maxRows value is a limit on how many rows can be returned as
   // part of a ResultSet.  You should normally not need to change
   // the default limit.  Zero means no limit.
   public int getMaxRows() throws SQLException {
      return MaxRows;
   }
   public void setMaxRows(int max) throws SQLException {
      MaxRows = max;
   }

   // if escape scanning is on (the default) the driver will do escape
   // substitution before sending the SQL to the database.
   public void setEscapeProcessing(boolean enable) throws SQLException {
      escape = enable;
   }

   // The queryTimeout is how many seconds the driver will allow for an
   // SQL statement to execute before giving up.  Zero means no limit.
   public int getQueryTimeout() throws SQLException {
      return (int) (QueryTimeout / 1000);
   }
   public void setQueryTimeout(int seconds) throws SQLException {
      QueryTimeout = seconds * 1000;
   }

   // Cancel can be used by one thread to cancel a statement that
   // is being executed by another thread.
   public void cancel() throws SQLException {

   }

   // getWarnings will return any warning information related to
   // the current statement execution.  Note that SQLWarning may be
   // a chain.  If a statement is re-executed then warnings associated
   // with its previous execution will be automatically discarded.

   public SQLWarning getWarnings() throws SQLException {
      return warnings;
   }
   public void clearWarnings() throws SQLException {
      warnings = null;
   }
   //----------------------- Multiple Results --------------------------

   // Under some (uncommon) situations a single SQL statement may return
   // multiple result sets and/or update counts.  Normally you can ignore
   // this, unless you're executing a stored procedure that you know may
   // return multiple results, or unless you're dynamically executing an
   // unknown SQL string.  The "execute", "getMoreResults", "getResultSet"
   // and "getUpdateCount" methods let you navigate through multiple results.

   // The "execute" method execute a SQL statement and returns "true"
   // if the first result is a ResultSet, false otherwise.  You can
   // then use getResultSet or getUpdateCount to retrieve the result,
   // and getMoreResults to move to any subseuqnet result(s).

   public void exec(String sql) throws SQLException {
      clearStatus();
      sendQuery(sql);
      readResults();
//if ( statuses.size() > 0 ) {
//   int loop=0;

//   while ( loop < statuses.size() )
//      System.out.println("Status: "+statuses.elementAt(loop++));
//}
   }

   public boolean execute(String sql) throws SQLException {
      if ( parent.autoCommit )
         parent.begin();
      exec(sql);
      if ( parent.autoCommit )
         parent.commit();
      if ( resultSets.size() > 0 )
         return true;
      return false;
   }

   // getResultSet returns the current result as a ResultSet.  It
   // returns NULL if the current result is not a ResultSet.
   public ResultSet getResultSet() throws SQLException {
      if ( currentResult < resultSets.size() )
         return (ResultSet) resultSets.elementAt(currentResult);
      return null;
   }

   // getUpdateCount returns the current result, which should be an update
   // count.   It returns -1 if there are no more results or if the
   // current result is a ResultSet.
   public int getUpdateCount() throws SQLException {
      if ( currentResult >= resultSets.size() )
         if ( (currentResult-resultSets.size()) < statuses.size() )
            return Integer.valueOf((String) statuses.firstElement()).intValue();
      return -1;
   }

   // getMoreResults moves to the next result.  It returns true if
   // this result is a ResultSet.  getMoreResults also implicitly
   // closes the current ResultSet.
   public boolean getMoreResults() throws SQLException {
      if ( currentResult < resultSets.size() ) {
         PGResultSet r = (PGResultSet) resultSets.elementAt(currentResult);
         // r.close();
      }
      if ( ++currentResult >= resultSets.size() )
         return false;
      return true;
   }

   public void setCursorName(String name) throws SQLException
   {

   }

}


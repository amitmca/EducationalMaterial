// a sample application to use the postgres java interface via jdbc.

// Copyright (c) 1996 Bradley McLean / Jeffrey Medeiros
//
// You may distribute under the terms of the GNU Public License as
// specified in the README file that comes with the JavaPostgres95 Kit

import java.sql.*;

class jptest3 {
   public static void main(String argv[]) {
      try {
//         DriverManager.setLogStream(System.out);

         Driver pgd = (Driver) new postgres95.PGDriver();

         String url = "jdbc:postgres95:jdatabase";

         Connection conn = DriverManager.getConnection(url,"user","password");

         PreparedStatement stat = conn.prepareStatement("delete from weather where city = ?");

         stat.setString(1,"Boston");
         
         System.out.println("result is "+stat.executeUpdate());

      } catch ( Exception e ) {
         System.err.println("E: "+e);
      }
   }
}

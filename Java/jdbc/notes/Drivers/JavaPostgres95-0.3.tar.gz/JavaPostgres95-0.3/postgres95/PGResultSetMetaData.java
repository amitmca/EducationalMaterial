// Java Interface to Postgres
// 03/28/96 B. McLean

// Copyright (c) 1996 Bradley McLean / Jeffrey Medeiros
//
// You may distribute under the terms of the GNU Public License as
// specified in the README file that comes with the JavaPostgres95 Kit

package postgres95;

import java.sql.*;
import java.util.*;
import java.io.*;

/**
 * JDBC Interface to Postgres95 functions
 */

public class PGResultSetMetaData implements ResultSetMetaData
{
   PGResultSet rs;

   PGResultSetMetaData(PGResultSet rs) {
      this.rs = rs;
   }

    /**
     * What's the number of columns in the ResultSet?
     *
     * @return the number
     */
	public int getColumnCount() throws SQLException {
	    return rs.getColumnCount();
	}

    /**
     * Is the column automatically numbered, thus read-only?
     *
     * @param column the first column is 1, the second is 2, ...
     * @return true if so
     */
	public boolean isAutoIncrement(int column) throws SQLException {
	    return false;
	}

    /**
     * Does a column's case matter?
     *
     * @param column the first column is 1, the second is 2, ...
     * @return true if so
     */
	public boolean isCaseSensitive(int column) throws SQLException {
	    return true;
	}

    /**
     * Can the column be used in a where clause?
     *
     * @param column the first column is 1, the second is 2, ...
     * @return true if so
     */
	public boolean isSearchable(int column) throws SQLException {
	    return true;
	}

    /**
     * Is the column a cash value?
     *
     * @param column the first column is 1, the second is 2, ...
     * @return true if so
     */
	public boolean isCurrency(int column) throws SQLException {
	   return false;
//	   if ((PGColumn) rs.columns.get(column)).oid == ??
	}

    /**
     * Can you put a NULL in this column?
     *
     * @param column the first column is 1, the second is 2, ...
     * @return columnNoNulls, columnNullable or columnNullableUnknown
     */
	public int isNullable(int column) throws SQLException {
	    return columnNullableUnknown;
	}

    /**
     * Does not allow NULL values.
     */
    int columnNoNulls = 0;

    /**
     * Allows NULL values.
     */
    int columnNullable = 1;

    /**
     * Nullability unknown.
     */
    int columnNullableUnknown = 2;

    /**
     * Is the column a signed number?
     *
     * @param column the first column is 1, the second is 2, ...
     * @return true if so
     */
	public boolean isSigned(int column) throws SQLException {
	    return true;
	}

    /**
     * What's the column's normal max width in chars?
     *
     * @param column the first column is 1, the second is 2, ...
     * @return max width
     */
	public int getColumnDisplaySize(int column) throws SQLException {
	    return ((PGColumn) rs.columns.elementAt(column-1)).size;
	}

    /**
     * What's the suggested column title for use in printouts and
     * displays?
     *
     * @param column the first column is 1, the second is 2, ...
     * @return true if so
     */
	public String getColumnLabel(int column) throws SQLException {
	    return ((PGColumn) rs.columns.elementAt(column-1)).name;
	}
    /**
     * What's a column's name?
     *
     * @param column the first column is 1, the second is 2, ...
     * @return column name
     */
	public String getColumnName(int column) throws SQLException {
	    return ((PGColumn) rs.columns.elementAt(column-1)).name;
    }
    /**
     * What's a column's table's schema?
     *
     * @param column the first column is 1, the second is 2, ...
     * @return schema name or "" if not applicable
     */
	public String getSchemaName(int column) throws SQLException {
	    return "";
	}

    /**
     * What's a column's number of decimal digits?
     *
     * @param column the first column is 1, the second is 2, ...
     * @return precision
     */
	public int getPrecision(int column) throws SQLException {
	    return ((PGColumn) rs.columns.elementAt(column-1)).size;
	}

    /**
     * What's a column's number of digits to right of decimal?
     *
     * @param column the first column is 1, the second is 2, ...
     * @return scale
     */
	public int getScale(int column) throws SQLException {
	    return 0;
	}

    /**
     * What's a column's table name?
     *
     * @return table name or "" if not applicable
     */
	public String getTableName(int column) throws SQLException {
	    return "";
	}

    /**
     * What's a column's table's catalog name?
     *
     * @param column the first column is 1, the second is 2, ...
     * @return column name or "" if not applicable.
     */
	public String getCatalogName(int column) throws SQLException {
	    return "";
	}

    /**
     * What's a column's SQL type?
     *
     * @param column the first column is 1, the second is 2, ...
     * @return SQL type
     * @see Types
     */
      public int getColumnType(int column) throws SQLException {
        return SQLType(((PGColumn) rs.columns.elementAt(column-1)).oid);
      }

    /**
     * What's a column's data source specific type name?
     *
     * @param column the first column is 1, the second is 2, ...
     * @return type name
     */
	public String getColumnTypeName(int column) throws SQLException {
	    return ((PGColumn) rs.columns.elementAt(column-1)).name;
	}

    /**
     * Is a column definitely not writable?
     *
     * @param column the first column is 1, the second is 2, ...
     * @return true if so
     */
	public boolean isReadOnly(int column) throws SQLException {
	    return false;
	}

    /**
     * Is it possible for a write on the column to succeed?
     *
     * @param column the first column is 1, the second is 2, ...
     * @return true if so
     */
	public boolean isWritable(int column) throws SQLException {
	    return true;
	}

    /**
     * Will a write on the column definitely succeed?
     *
     * @param column the first column is 1, the second is 2, ...
     * @return true if so
     */
	public boolean isDefinitelyWritable(int column) throws SQLException {
	    return false;
	}


   private int SQLType(int PGtype_oid) {
     switch (PGtype_oid) {
	case 16: // bool
	  return Types.BIT;
	case 18: // char
	  return Types.CHAR;
	case 21: // int2
	  return Types.SMALLINT;
	case 23: // int4
 	  return Types.INTEGER;
	case 1043: // varchar == 11
	  return Types.VARCHAR;
	case 1082: // date
	  return Types.DATE;
	case 1083: // time
	  return Types.TIME;
     }
     return 0;
   }

}

// Java Interface to Postgres
// $Id: PGColumn.java,v 1.1 1997/04/12 13:22:08 finder Exp $

// Copyright (c) 1996 Bradley McLean / Jeffrey Medeiros
// Modifications Copyright (c) 1996/1997 Martin Rode
// Copyright (c) 1997 Peter T Mount
//
// You may distribute under the terms of the GNU Public License as
// specified in the README file that comes with the JavaPostgres95 Kit

// Column Names are stored in 'columns'
// Values are stored in 'tuples'

package postgres95;

import java.sql.*;
import java.math.*;
import java.util.*;
import java.io.*;

/**
 * JDBC Interface to Postgres95 functions
 */

public class PGColumn {
   String name;
   int	oid;
   short size;
}

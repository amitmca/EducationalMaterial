// Java Interface to Postgres
// $Id: PGPreparedStatement.java,v 1.3 1997/04/12 21:44:47 finder Exp finder $

// Copyright (c) 1996 Bradley McLean / Jeffrey Medeiros
// Modifications Copyright (c) 1996/1997 Martin Rode
// Copyright (c) 1997 Peter T Mount
//
// You may distribute under the terms of the GNU Public License as
// specified in the README file that comes with the JavaPostgres95 Kit

// PM Peter Mount <pmount@maidast.demon.co.uk>
// TG Thorsten Greiner <thorsten.greiner@consol.de>

package postgres95;

import java.sql.*;
import java.math.*;
import java.util.*;
import java.text.*;

/**
 * JDBC Interface to Postgres95 functions
 */

class PGparameter {
   Object value;
   int type;
   public PGparameter(Object v,int t) {
      value = v;
      type = t;
   }
}

public class PGPreparedStatement extends PGStatement
   implements PreparedStatement
{
  String query;
  Vector parms;
  
  // TG May 16 97: internationalisation bug fix
  SimpleDateFormat sdf;
  
  PGPreparedStatement(PGConnection c,String q)
  {
    super(c);
    query = q;
    parms = new Vector();
    sdf = new SimpleDateFormat("EEE MMM dd HH:mm:ss yyyy zzz");
  }
  
  protected String prepareParm(PGparameter p) {
      switch ( p.type ) {
      case Types.BIT:
      case Types.TINYINT:
      case Types.SMALLINT:
      case Types.INTEGER:
      case Types.BIGINT:
      case Types.FLOAT:
      case Types.REAL:
      case Types.DOUBLE:
      case Types.NUMERIC:
      case Types.DECIMAL:
         return (String) p.value;
      case Types.CHAR:
      case Types.VARCHAR:
      case Types.LONGVARCHAR:
      case Types.DATE:
      case Types.TIME:
	// TG May 16 97: TIMESTAMP moved out, also bug fix
	if(p.value != null)
	  return "'" + p.value + "'";
	else
	  return "null";
	
	// TG May 16 97: Timestamp support
      case Types.TIMESTAMP:
	if(p.value != null)
	  return "'" + sdf.format((java.util.Date)p.value) + "'";
	else
	  return "null";
	
      case Types.BINARY:
      case Types.VARBINARY:
      case Types.LONGVARBINARY:
         return (String) p.value;
      case Types.NULL:
         return null;
      default:
         return null;
      }      
   }

   protected String prepareQuery() throws SQLException {
   // Scan through the provided string, and plug in parameter values
      StringBuffer newquery = new StringBuffer();
      int start = 0;
      int quest;
      int parm = 0;
      
      try {
         while ( true ) {
            quest = query.indexOf("?",start);
            if ( quest == -1 ) {
               newquery.append(query.substring(start));
               break;
            }
            if ( quest > start )
               newquery.append(query.substring(start,quest));
            start = quest+1;
            newquery.append(prepareParm((PGparameter)parms.elementAt(parm++)));
         }
      } catch ( Exception e ) {
	// TG May 16 97: Additional line
	e.printStackTrace();
	
	throw new SQLException("Query parameter insertion failed: "+e);
      }
      //System.out.println("PGP: Query is:"+ newquery.toString());
      return newquery.toString();
   }
   // This method executes a "prepared" query statement.
   // See the definition of Statement.executeQuery
   public ResultSet executeQuery() throws SQLException {
      return super.executeQuery(prepareQuery());
   }

   // This method executes a "prepared" modify statement.
   // See the definition of Statement.executeUpdate
   public int executeUpdate() throws SQLException {
      return super.executeUpdate(prepareQuery());
   }
   
   //----------------------------------------------------------------------
   // Methods for setting IN parameters into this statement.
   // Parameters are numbered starting at 1.
   private void setparm(int index,Object value,int type) {
      while ( parms.size() < index )
         parms.addElement(null);   
      parms.setElementAt(new PGparameter(value,type),index-1);
   }
   
   // You always need to specify a SQL type when sending a NULL.
   public void setNull(int parameterIndex, int sqlType) throws SQLException {
      setparm(parameterIndex,null,sqlType);
   }

   // The following methods allow you to set various SQLtypes as parameters.
   // Note that the method include the SQL type in their name.
   public void setBoolean(int parameterIndex, boolean x) throws SQLException {
      setparm(parameterIndex,x ? "t" : "f",Types.BIT);
   }
   public void setByte(int parameterIndex, byte x) throws SQLException {
      setparm(parameterIndex,new Integer((int)x).toString(),Types.TINYINT);
    }
   public void setShort(int parameterIndex, short x) throws SQLException {
      setparm(parameterIndex,new Integer((int)x).toString(),Types.SMALLINT);
   }
   public void setInt(int parameterIndex, int x) throws SQLException {
      setparm(parameterIndex,new Integer(x).toString(),Types.INTEGER);
   }
   public void setLong(int parameterIndex, long x) throws SQLException {
      setparm(parameterIndex,new Long(x).toString(),Types.BIGINT);
   }
   public void setFloat(int parameterIndex, float x) throws SQLException {
      setparm(parameterIndex,new Float(x).toString(),Types.FLOAT);
   }
   public void setDouble(int parameterIndex, double x) throws SQLException {
      setparm(parameterIndex,new Double(x).toString(),Types.DOUBLE);
   }
   public void setBigDecimal(int parameterIndex, BigDecimal x) throws SQLException {
      setparm(parameterIndex,x.toString(),Types.NUMERIC);
   }
   public void setString(int parameterIndex, String x) throws SQLException {
      setparm(parameterIndex,x,Types.CHAR);
   }
   public void setBytes(int parameterIndex, byte x[]) throws SQLException {
      setparm(parameterIndex,x,Types.BINARY);
   }
   public void setBinaryStream(int parameterIndex, byte x[]) throws SQLException {
      setparm(parameterIndex,x,Types.LONGVARBINARY);
   }

  // This has been completely rewritten
  public void setDate(int parameterIndex, java.sql.Date x) throws SQLException
  {
    Calendar cal = new GregorianCalendar();
    cal.setTime(x);
    setparm(parameterIndex,
	    ((cal.get(Calendar.MONTH) < 9) ? "0" : "") +
	    Integer.toString(cal.get(Calendar.MONTH)+1) + "-" +
	    ((cal.get(Calendar.DATE) < 10) ? "0" : "") +
	    Integer.toString(cal.get(Calendar.DATE)) + "-" +
	    Integer.toString(cal.get(Calendar.YEAR)) // +1900)
	    ,Types.DATE);
    
     // Original code
     //setparm(parameterIndex,
     //((x.getMonth() < 9) ? "0" : "") +
     //Integer.toString(x.getMonth()+1) + "-" +
     //((x.getDate() < 10) ? "0" : "") +
     //Integer.toString(x.getDate()) + "-" +
     //Integer.toString(x.getYear()+1900),Types.DATE);
   }
  
  // This has been completely rewritten
  public void setTime(int parameterIndex, java.sql.Time x) throws SQLException
  {
    Calendar cal = new GregorianCalendar();
    cal.setTime(x);
    setparm(parameterIndex,
	    ((cal.get(Calendar.HOUR) < 10) ? "0" : "") +
	    Integer.toString(cal.get(Calendar.HOUR)) + ":" +
	    ((cal.get(Calendar.MINUTE) < 10) ? "0" : "") +
	    Integer.toString(cal.get(Calendar.MINUTE)) + ":" +
	    ((cal.get(Calendar.SECOND) < 10) ? "0" : "") +
	    Integer.toString(cal.get(Calendar.SECOND)),
	    Types.TIME);
    
    // Original code
    //setparm(parameterIndex,
    //((x.getHours() < 10) ? "0" : "") +
    //Integer.toString(x.getHours()) + ":" +
    //((x.getMinutes() < 10) ? "0" : "") +
    //Integer.toString(x.getMinutes()) + ":" +
    //((x.getSeconds() < 10) ? "0" : "") +
    //Integer.toString(x.getSeconds()),Types.TIME);
   }
  
  public void setTimestamp(int parameterIndex, java.sql.Timestamp x) throws SQLException
  {
    // TG May 16 97: rewrite for timestamp support
    setparm(parameterIndex,x,Types.TIMESTAMP);
    //setparm(parameterIndex,x.toString(),Types.TIMESTAMP);
  }

   // The normal setChars and setBinary methods are suitable for passing
   // normal sized data.  However occasionally it may be necessary to send
   // extremely large values as LONGVARCHAR or LONGVARBINARY parameters.
   // In this case you can pass in a java.io.InputStream object, and the
   // JDBC runtimes will read data from that stream as needed, until they reach
   // end-of-file.  Note that these stream objects can either be standard Java
   // stream objects, or your own subclass that implements the standard interface.
   // setAsciiStreamParameter and setUnicodeStreamParameter imply the use of
   // the SQL LONGVARCHAR type, and setBinaryStreamParameter implies the
   // SQL LONGVARBINARY type.
   // For each stream type you must specify the number of bytes to be read 
   // from the stream and sent to the database.

   public void setAsciiStream(int parameterIndex, java.io.InputStream x, int length)
							throws SQLException {
   // Okay, need to link this up with the large object technology...
   }
   public void setUnicodeStream(int parameterIndex, java.io.InputStream x, int length)
							throws SQLException {
   }
   public void setBinaryStream(int parameterIndex, java.io.InputStream x, int length) 
							throws SQLException {
   }

   // Parameters remain in force for repeated use of the same statement.
   // You can use clearParameters to remove any parameters associated with
   // a statement.
   public void clearParameters() throws SQLException {
      parms = new Vector();
   }

   //----------------------------------------------------------------------
   // Advanced features:

   // You can set a parameter as a Java object.  See the JDBC spec's 
   // "Dynamic Programming" chapter for information on valid Java types.
   public void setObject(int parameterIndex, Object x, int sqlType)
							throws SQLException { }

   public void setObject(int parameterIndex, Object x, int sqlType, int scale)
							throws SQLException { }

   public void setObject(int parameterIndex, Object x)
							throws SQLException { }

   // This method executed an arbitrary "prepared" statement.
   // See the definition of Statement.execute
   public boolean execute() throws SQLException {
      return super.execute(prepareQuery());
   }
}


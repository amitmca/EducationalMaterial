// Java Interface to Postgres
// $Id: PGResultSet.java,v 1.2 1997/04/12 21:30:40 finder Exp finder $

// Copyright (c) 1996 Bradley McLean / Jeffrey Medeiros
// Modifications Copyright (c) 1996/1997 Martin Rode
// Copyright (c) 1997 Peter T Mount
//
// You may distribute under the terms of the GNU Public License as
// specified in the README file that comes with the JavaPostgres95 Kit

// PM Peter Mount <pmount@maidast.demon.co.uk>
// TG Thorsten Greiner <thorsten.greiner@consol.de>

// Column Names are stored in 'columns'
// Values are stored in 'tuples'

package postgres95;

import java.sql.*;
import java.math.*;
import java.util.*;
import java.text.*;
import java.io.*;

/**
 * JDBC Interface to Postgres95 functions
 */

public class PGResultSet implements ResultSet
{
  PGStatement parent;
  String name;
  Vector columns;
  Vector tuples;
  int currentRow;
  private Hashtable months;
  private boolean wasException;
  private PGResultSetMetaData meta;
  
  /**
   * Helper function to read a Tuple from the server
   *
   */
  private Vector readTuple(DataInputStream in, short nfields, boolean binary) throws SQLException
  {
    Vector data = new Vector();
    int bytes = nfields / 8;
    int i;
    int bitmap_index = 0;
    int bitcnt = 0;
    int bmap;
    
    // System.out.println("readTuple1: "+bytes+" nF:"+nfields+" mod:"+(nfields % 8));
    
    try {
      if( (nfields % 8) > 0 )
	bytes++;
      
      byte[] bitmap = new byte[bytes+1]; // +1 because there would be an error with nfields=8
      
      in.read(bitmap,0,bytes);
      // System.out.println("readTuple2: "+bytes);
      
      bmap = bitmap[bitmap_index];
      
      for( i=0; i < nfields; i++ ) {
	if( (bmap & 0x80) == 0 ) {
	  data.addElement(null);	// will this work?
	} else {
	  int len = parent.readint4();
	  // System.out.println("readTuple3: "+len+" i:"+i+" Fields:"+nfields);
	  if( ! binary )
	    len -= 4;
	  
	  if( len > 0 ) {
	    byte [] value = new byte[len];
	    in.read(value,0,len);
	    if ( ! binary )
	      // This line is deprecated
	      //data.addElement(new String(value,0));
	      data.addElement(new String(value));
	    else
	      data.addElement(value);
	  } else if( ! binary )
	    data.addElement("");
	  else
	    data.addElement(null);
	}
	if( ++bitcnt == 8 ) {
	  bmap = bitmap[++bitmap_index];
	  bitcnt = 0;
	} else
	  bmap <<= 1;
      }
    } catch ( Exception e ) {
      throw new SQLException("Network error reading results"+e);
    }
    return data;
  }
  
  /**
   * Helper function to read a result set from the network
   *
   */
  private void readResult(DataInputStream in) throws SQLException
  {
    short loop;
    short nfields;
    int type;
    
    // Reset the class
    columns = new Vector();
    tuples = new Vector();
    currentRow = 0;
    // System.out.println("readResult1: ");
    
    try {
      // First, pull in the attribute table
      nfields = parent.readint2();
      
      // System.out.println("readResult2: "+nfields);
      while ( nfields-- > 0 ) {
	PGColumn col = new PGColumn();
	col.name = parent.readline();
	col.oid = parent.readint4();
	col.size = parent.readint2();
	columns.addElement(col);
	// System.out.println("readResult2a: "+col.name+","+col.oid+","+col.size);
      }
      
      // System.out.println("readResult3: ");
      // Now, pull in the tuple results
      boolean loop2 = true;
      while ( loop2 ) {
	type = in.read();
	switch ( type ) {
	case 'T':
	  throw new SQLException("Multiple tuple results not supported");
	  
	case 'B':	// read binary tuple
	case 'D':	// read ascii tuple
	  tuples.addElement(
			    readTuple(in,(short) columns.size(),type == 'B'));
	  // PGd.h("Tuples add element:"+tuples);
	  break;
	  
	case 'A':
	  throw new SQLException("Asychronous portals not supported");
	  
	case 'C':	// end of stream
	  String command = parent.readline();
	  loop2 = false;
	  break;
	  
	case 'E':	// errors
	  String error = parent.readline();
	  throw new SQLException("Tuple Error: "+error);
	  
	case 'N':	// Notices from the server
	  String notice = parent.readline();
	  SQLWarning nw = new SQLWarning("Error: "+notice);
	  if( parent.warnings != null )
	    nw.setNextException(parent.warnings);
	  parent.warnings = nw;
	  break;
	  
	default:
	  throw new SQLException("Network protocol error reading results: "+type);
	}
      }
    } catch ( Exception e ) {
      throw new SQLException("Network error reading results");
    }
  }
  
  /**
   * Constructor for a result set
   *
   */
  PGResultSet(PGStatement st,String portal,DataInputStream in) throws SQLException
  {
    // TG May 16 97: This is for abstime support
    months = new Hashtable();
    months.put("Jan", new Integer(1));
    months.put("Feb", new Integer(2));
    months.put("Mar", new Integer(3));
    months.put("Apr", new Integer(4));
    months.put("May", new Integer(5));
    months.put("Jun", new Integer(6));
    months.put("Jul", new Integer(7));
    months.put("Aug", new Integer(8));
    months.put("Sep", new Integer(9));
    months.put("Oct", new Integer(10));
    months.put("Nov", new Integer(11));
    months.put("Dec", new Integer(12));
    
    parent = st;
    name = portal;
    
    readResult(in);
    meta = new PGResultSetMetaData(this);
  }
  
  /**
   * Helper functions to get the current object
   *
   */
  private String value(String columnName) throws SQLException
  {
    return value(findColumn(columnName));
  }
  
  private Object value(int row,int column) throws SQLException
  {
    try {
      return ((Vector) tuples.elementAt(row-1)).elementAt(column-1);
    } catch ( Exception e ) {
      throw new SQLException("Out of result set bounds? value(int, int)" + e );
    }
  }
  
  private Object ovalue(int column) throws SQLException
  {
    try {
      return ((Vector) tuples.elementAt(currentRow-1)).elementAt(column-1);
    } catch ( Exception e ) {
      throw new SQLException("Out of result set bounds? ovalue(int)" + e );
    }
  }
  
  private String value(int column) throws SQLException
  {
    try {
      return (String) (((Vector) tuples.elementAt(currentRow-1)).elementAt(column-1));    
    } catch ( Exception e ) {
      throw new SQLException("value(int) CR:"+(currentRow-1)+" CL:"+(column-1)+"->" + e );
    }
  }
  
  private byte [] bvalue(String columnName) throws SQLException
  {
    for ( int loop=0; loop < columns.size(); loop++ ) {
      PGColumn col = (PGColumn) columns.elementAt(loop);
      if ( col.name.equals(columnName) )
	return bvalue(loop+1);
    }
    return null;
  }
  
  private byte [] bvalue(int column) throws SQLException
  {
    try {
      return (byte [])(((Vector) tuples.elementAt(currentRow-1)).elementAt(column-1));
    } catch ( Exception e ) {
      throw new SQLException("Out of result set bounds? " + e );
    }
  }
  
  // The isNull() method returns true if the given column in the
  // current row holds the SQL "null".
  
  private boolean isNull(int column) throws SQLException
  {
    return (value(column) == null);
  }
  
  private boolean isNull(String columnName) throws SQLException
  {
    return (value(columnName) == null);
  }
  
  // Martins Test class in interface method: getCursorName (hack!)
  private void printTuples()
  {
    int i;
    int j;
    Vector v;
    
    PGd.h("===============================");
    for (i=0; i<tuples.size(); i++) {
      v = (Vector) tuples.elementAt(i);
      for (j=0; j<v.size(); j++) {
	PGd.h("I: "+i+" J: "+j+" ="+v.elementAt(j));
      }
    }
    PGd.h("===============================");
  }  
  
  // New API (JPM)
  public boolean wasNull() throws SQLException
  {
    return wasException;
  }
  
  // Methods for accessing columns in the current row.
  public String getString(int column) throws SQLException
  {
    wasException = false;
    // PGd.h("getString(int)");
    try {
      if (isNull(column))
	return null;
      else
	return value(column);
    } catch ( Exception e ) {
      wasException = true;
      throw new SQLException("Result conversion error: "+e);
    }
  }
  
  // Methods for accessing columns in the column name.
  public String getString(String columnName) throws SQLException
  {
    wasException = false;
    try {
      if (isNull(columnName))
	return null;
      else
	return value(columnName);
    } catch ( Exception e ) {
      wasException = true;
      throw new SQLException("Result conversion error: "+e);
    }
  }
  
  public boolean getBoolean(int column) throws SQLException
  {
    wasException = false;
    try {
      return ( value(column).compareTo("t") == 0 );
    } catch ( Exception e ) {
      wasException = true;
      throw new SQLException("Result conversion error: "+e);
    }
  }
  
  public boolean getBoolean(String columnName) throws SQLException
  {
    wasException = false;
    try {
      return ( value(columnName).compareTo("t") == 0 );
    } catch ( Exception e ) {
      wasException = true;
      throw new SQLException("Result conversion error: "+e);
    }
  }
  
  public byte getByte(int column) throws SQLException
  {
    wasException = false;
    try {
      return (byte) Integer.valueOf(value(column)).intValue();
    } catch ( Exception e ) {
      wasException = true;
      throw new SQLException("Result conversion error: "+e);
    }
  }
  
  public byte getByte(String columnName) throws SQLException
  {
    wasException = false;
    try {
      return (byte) Integer.valueOf(value(columnName)).intValue();
    } catch ( Exception e ) {
      wasException = true;
      throw new SQLException("Result conversion error: "+e);
    }
  }
  
  public short getShort(int column) throws SQLException
  {
    wasException = false;
    try {
      return (short) Integer.valueOf(value(column)).intValue();
    } catch ( Exception e ) {
      wasException = true;
      throw new SQLException("Result conversion error: "+e);
    }
  }
  
  public short getShort(String columnName) throws SQLException
  {
    wasException = false;
    try {
      return (short) Integer.valueOf(value(columnName)).intValue();
    } catch ( Exception e ) {
      wasException = true;
      throw new SQLException("Result conversion error: "+e);
    }
  }
  
  public int getInt(int column) throws SQLException
  {
    wasException = false;
    try {
      if (isNull(column))
	return 0;
      else
	return Integer.valueOf(value(column)).intValue();
    } catch ( Exception e ) {
      wasException = true;
      throw new SQLException("Result conversion error: "+e);
    }
  }
  
  public int getInt(String columnName) throws SQLException
  {
    wasException = false;
    try {
      if (isNull(columnName))
	return 0;
      else
	return Integer.valueOf(value(columnName)).intValue();
    } catch ( Exception e ) {
      wasException = true;
      throw new SQLException("Result conversion error: "+e);
    }
  }
  
  public long getLong(int column) throws SQLException
  {
    wasException = false;
    try {
      if (isNull(column))
	return 0;
      else
	return Long.valueOf(value(column)).longValue();
    } catch ( Exception e ) {
      wasException = true;
      throw new SQLException("getLong(int) conversion error: "+e);
    }
  }
  
  public long getLong(String columnName) throws SQLException
  {
    wasException = false;
    try {
      if (isNull(columnName))
	return 0; // SQL convention: SQLNull = 0, although it's null
      else 
	return Long.valueOf(value(columnName)).longValue();
    } catch ( Exception e ) {
      wasException = true;
      throw new SQLException("Result conversion error: "+e);
    }
  }
  
  public float getFloat(int column) throws SQLException
  {
    wasException = false;
    try {
      if (isNull(column))
	return 0;
      else
	return Float.valueOf(value(column)).floatValue();
    } catch ( Exception e ) {
      wasException = true;
      throw new SQLException("Result conversion error: "+e);
    }
  }
  
  public float getFloat(String columnName) throws SQLException
  {
    wasException = false;
    try {
      if (isNull(columnName))
	return 0;
      else
	return Float.valueOf(value(columnName)).floatValue();
    } catch ( Exception e ) {
      wasException = true;
      throw new SQLException("Result conversion error: "+e);
    }
  }
  
  public double getDouble(int column) throws SQLException
  {
    wasException = false;
    try {
      if (isNull(column))
	return 0;
      else
	return Double.valueOf(value(column)).doubleValue();
    } catch ( Exception e ) {
      wasException = true;
      throw new SQLException("Result conversion error: "+e);
    }
  }
  
  public double getDouble(String columnName) throws SQLException
  {
    wasException = false;
    try {
      if (isNull(columnName))
	return 0;
      else
	return Double.valueOf(value(columnName)).doubleValue();
    } catch ( Exception e ) {
      wasException = true;
      throw new SQLException("Result conversion error: "+e);
    }
  }
  
  public BigDecimal getBigDecimal(int column, int scale) throws SQLException
  {
    wasException = false;
    try {
      return new BigDecimal(new BigInteger(value(column)), scale);
    } catch ( Exception e ) {
      wasException = true;
      throw new SQLException("Result conversion error: "+e);
    }
  }
  
  public BigDecimal getBigDecimal(String columnName, int scale) throws SQLException
  {
    wasException = false;
    try {
      return new BigDecimal(new BigInteger(value(columnName)));
    } catch ( Exception e ) {
      wasException = true;
      throw new SQLException("Result conversion error: "+e);
    }
  }
  
  public byte[] getBytes(int column) throws SQLException
  {
    return bvalue(column);	// Copy this first?
  }
  
  public byte[] getBytes(String columnName) throws SQLException
  {
    return bvalue(columnName);	// Copy this first?
  }
  
  public byte[] getLongBinaryStream(int column) throws SQLException
  {
    return bvalue(column);	// Copy this first?
  }
  
  public byte[] getLongBinaryStream(String columnName) throws SQLException
  {
    return bvalue(columnName);	// Copy this first?
  }
  
  public java.sql.Date getDate(int column) throws SQLException
  {
    wasException = false;
    try {
      String temp = value(column);
      
      // TG May 16 97: bug fix
      if(temp == null) return null;
      
      int month = Integer.valueOf(temp.substring(0,2)).intValue();
      int day = Integer.valueOf(temp.substring(3,5)).intValue();
      int year = Integer.valueOf(temp.substring(6,10)).intValue();
      return new java.sql.Date(year-1900,month-1,day);
    } catch ( Exception e ) {
      wasException = true;
      throw new SQLException("Result conversion error: "+e);
    }
  }
  
  public java.sql.Date getDate(String columnName) throws SQLException
  {
    wasException = false;
    try {
      String temp = value(columnName);
      
      // TG May 16 97: bug fix
      if(temp == null) return null;
      
      int month = Integer.valueOf(temp.substring(0,2)).intValue();
      int day = Integer.valueOf(temp.substring(3,5)).intValue();
      int year = Integer.valueOf(temp.substring(6,10)).intValue();
      return new java.sql.Date(year-1900,month-1,day);
    } catch ( Exception e ) {
      wasException = true;
      throw new SQLException("Result conversion error: "+e);
    }
  }
  
  public java.sql.Time getTime(int column) throws SQLException
  {
    wasException = false;
    try {
      String temp = value(column);
      
      // TG May 16 97: bug fix
      if(temp == null) return null;
      
      int hour = Integer.valueOf(temp.substring(0,2)).intValue();
      int minute = Integer.valueOf(temp.substring(3,5)).intValue();
      int second = Integer.valueOf(temp.substring(6,9)).intValue();
      return new java.sql.Time(hour,minute,second);
    } catch ( Exception e ) {
      wasException = true;
      throw new SQLException("Result conversion error: "+e);
      }
  }
  
  public java.sql.Time getTime(String columnName) throws SQLException
  {
    wasException = false;
    try {
      String temp = value(columnName);
      
      // TG May 16 97: bug fix
      if(temp == null) return null;
      
      int hour = Integer.valueOf(temp.substring(0,2)).intValue();
      int minute = Integer.valueOf(temp.substring(3,5)).intValue();
      int second = Integer.valueOf(temp.substring(6,9)).intValue();
      return new java.sql.Time(hour,minute,second);
    } catch ( Exception e ) {
      wasException = true;
      throw new SQLException("Result conversion error: "+e);
    }
  }
  
  public java.sql.Timestamp getTimestamp(int column) throws SQLException
  {
    try {
      // TG May 16 97: Support for timestamps using abstime
      String temp = value(column);
      if(temp == null) return null;
      
      return new Timestamp(
			   Integer.valueOf(temp.substring(20, 24)).intValue()-1900,
			   ((Integer)months.get(temp.substring(4, 7))).intValue(),
			   Integer.valueOf(temp.substring(8, 10)).intValue(),
			   Integer.valueOf(temp.substring(11, 13)).intValue(),
			   Integer.valueOf(temp.substring(14, 16)).intValue(),
			   Integer.valueOf(temp.substring(17, 19)).intValue(),
			   0 );
      
    } catch ( Exception e ) {
      wasException = true;
      throw new SQLException("Result conversion error: "+e);
    }
  }
  
  public java.sql.Timestamp getTimestamp(String columnName) throws SQLException
  {
    try {
      String temp = value(columnName);
      if(temp == null) return null;
      
      return new Timestamp(
			   Integer.valueOf(temp.substring(20, 24)).intValue()-1900,
			   ((Integer)months.get(temp.substring(4, 7))).intValue(),
			   Integer.valueOf(temp.substring(8, 10)).intValue(),
			   Integer.valueOf(temp.substring(11, 13)).intValue(),
			   Integer.valueOf(temp.substring(14, 16)).intValue(),
			   Integer.valueOf(temp.substring(17, 19)).intValue(),
			   0 );
      
    } catch ( Exception e ) {
      wasException = true;
      throw new SQLException("Result conversion error: "+e);
    }
  }
  
  // The normal getChars and getBinary methods are suitable for
  // reading normal sized data.  However occasionally it may be
  // necessary to access LONGVARCHAR or LONGVARBINARY fields that
  // are multiple Megabytes in size.  To support this case we provide
  // getCharStream and getBinaryStream methods that return Java
  // IO streams from which data can be read in chunks.
  
  public java.io.InputStream getAsciiStream(int column) throws SQLException
  {
    String temp = value(column);
    byte [] temp2 = new byte[temp.length()];
    
    // This is deprecated
    //temp.getBytes(0,temp.length(),temp2,0);
    System.arraycopy(temp.getBytes(),0,temp2,0,temp.length());
    
    return new ByteArrayInputStream(temp2);
  }
  
  public java.io.InputStream getAsciiStream(String columnName) throws SQLException
  {
    return(null);
  }
  
  public java.io.InputStream getUnicodeStream(int column) throws SQLException
  {
    return getAsciiStream(column);	// Bad Implementation!
  }
  
  public java.io.InputStream getUnicodeStream(String columnName) throws SQLException
  {
    return(null);
  }
  
  public java.io.InputStream getBinaryStream(int column) throws SQLException
  {
    return new ByteArrayInputStream(bvalue(column));
  }
  
  public java.io.InputStream getBinaryStream(String columnName) throws SQLException
  {
    return(null);
  }
  
  // next moves us to the next row of the results.
  // It returns true if if has moved to a valid row, false if
  // all the rows have been processed.
  public boolean next() throws SQLException {
    // PGd.h("NEXT!");
    if (tuples == null) {
     PGd.h("tuples == null!");
     return false;
    } else
      return ((++currentRow) <= tuples.size());
  }
  
  // Return the number of the current row.  The first row containing
  // actual data is row 1.
  public int getRowNumber() throws SQLException
  {
    return currentRow;
  }
  
  // Return the number of columns in the ResultSet
  public int getColumnCount() throws SQLException
  {
    return columns.size();
  }
  
  // The total number of rows returned by the query.  Note that on some
  // databases this method may be very expensive.
  public int getRowCount() throws SQLException
  {
    return tuples.size();
  }
  
  // close frees up internal state associated with the ResultSet
  // You should normally call close when you are done with a ResultSet
  // ResultSets are also closed automatically when their Statement is closed.
  public void close() throws SQLException
  {
    columns = null;
    tuples = null;
  }
  
  //----------------------------------------------------------------------
  // Advanced features:
  
  // getCursorname returns a cursor name that can be used to identify the
  // current position in the Resultset to a separate statement that is
  // executing a positioned update or positioned delete.  If the database
  // doesn't support positioned delete or update, it may return "" here.
  public String getCursorName() throws SQLException
  {
    printTuples();
    return (new Integer(currentRow)).toString();
  }
  
  // You can obtain a ResultMetaData object to obtain information
  // about the number, types and properties of the result columns.
  public ResultSetMetaData getMetaData() throws SQLException
  {
    return meta;
  }
  
  public Object getObject(String columnName) throws SQLException
  {
    return(getObject(findColumn(columnName)));
  }
  
  // You can obtain a column result as a Java Object.
  // See the JDBC spec's "Dynamic Programming" chapter for details.
  public Object getObject(int column) throws SQLException {
    try {
      switch( meta.getColumnType(column) )
	{
	  
	case Types.BIT:
	  return new Boolean(getBoolean(column));
	  
	case Types.TINYINT:
	  return new Integer((int) getByte(column));
	  
	case Types.SMALLINT:
	  return new Integer((int) getShort(column));
	  
	case Types.INTEGER:
	  return new Integer(getInt(column));
	  
	case Types.BIGINT:
	  return new Long(getLong(column));
	  
	case Types.FLOAT:
	  return new Float(getDouble(column));
	  
	case Types.REAL:
	  return new Float(getFloat(column));
	  
	case Types.DOUBLE:
	  return new Double(getDouble(column));
	  
	case Types.NUMERIC:
	  // Should we examine the metadata to find out how to scale?
	  return getBigDecimal(column,0);
	  
	case Types.DECIMAL:
	  // Should we examine the metadata to find out how to scale?
	  return getBigDecimal(column,0);
	  
	case Types.CHAR:
	  return getString(column);
	  
	case Types.VARCHAR:
	  return getString(column);
	  
	case Types.LONGVARCHAR:
	  return getAsciiStream(column);
	  
	case Types.DATE:
	  return getDate(column);
	  
	case Types.TIME:
	  return getTime(column);
	  
	case Types.TIMESTAMP:
	  return getTimestamp(column);
	  
	case Types.BINARY:
	  return getBytes(column);
	  
	case Types.VARBINARY:
	  return getBytes(column);
	  
	case Types.LONGVARBINARY:
	  return getBinaryStream(column);
	  
	case Types.NULL:
	  return null;
	  
	default:
	  return null;
	}
    } catch (Exception e) {
      throw new SQLException("getObject-Eception: "+e);
    }
  }
  
  private int SQLtype(int PGtype_oid)
  {
    switch (PGtype_oid)
      {
      case 16: // bool
	return Types.BIT;
	
      case 18: // char
	return Types.CHAR;
	
      case 21: // int2
	return Types.SMALLINT;
	
      case 23: // int4
	return Types.INTEGER;
      
      case 1043: // varchar == 11
	return Types.VARCHAR;
      
      case 1082: // date
	return Types.DATE;
      
      case 1083: // time
	return Types.TIME;
      }
    return 0;
  }
  
  public SQLWarning getWarnings() throws SQLException
  {
    return(null);
  }
  
  public void clearWarnings() throws SQLException
  {
    
  }
  
  public int findColumn(String columnName) throws SQLException
  {
    for ( int loop=0; loop < columns.size(); loop++ ) {
      PGColumn col = (PGColumn) columns.elementAt(loop);
      if ( col.name.equals(columnName) ) {
	return (loop + 1);
      }
    }
    throw new SQLException("Couldn't find "+columnName+" in ResultSet");
  }
}

Title: A faculty book system
Description: Hi, this program is for my Java assignment.. this is a simple program which make use of JTable, MDI, text file, array, etc... if you like this program, pls vote me :D 
Just compile and run the program.
javac FacultyBookList_Main
java FacultyBookList_Main
ZIP file updated with icons. (thks to Carl)
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=2986&lngWId=2

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.

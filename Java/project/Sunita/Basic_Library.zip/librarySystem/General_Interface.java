import javax.swing.*;
import java.awt.*;

public interface General_Interface
{
	public General_Info gen = new General_Info();
    public JPanel master = new JPanel();
    public JPanel tab = new JPanel();
    public remark rem = new remark();
    public ImageIcon icon = new ImageIcon("");
    public JTabbedPane tabbedPane = new JTabbedPane();
}
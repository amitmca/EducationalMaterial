import javax.swing.*;
import java.awt.*;

public interface book_loan_Interface
{
	public book_loan_main gen = new book_loan_main();
	public JButton button = null;
	
}
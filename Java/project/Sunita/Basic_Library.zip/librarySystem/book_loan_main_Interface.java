import javax.swing.*;
import java.awt.*;

public interface book_loan_main_Interface
{
	public book_loan_tab loan = new book_loan_tab();
    //public book_loan_master mast = new book_loan_master();
    public JPanel master = new JPanel();
    public JPanel tab = new JPanel();          
    //public ImageIcon icon = new ImageIcon("");
    //public JTabbedPane tabbedPane = new JTabbedPane();
} 

import javax.swing.*;
import java.awt.*;

public interface video_Interface
{
	 	public video_master gen = new video_master();

}
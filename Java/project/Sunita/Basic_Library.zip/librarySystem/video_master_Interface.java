import javax.swing.*;
import java.awt.*;

public interface video_master_Interface
{
    public video_master_info mast = new video_master_info();
    public JPanel master = new JPanel(); 
    public JPanel tab = new JPanel();
    public video_tab tabbed1 = new video_tab();
    public ImageIcon icon = new ImageIcon("");
    public JTabbedPane tabbedPane = new JTabbedPane();

}
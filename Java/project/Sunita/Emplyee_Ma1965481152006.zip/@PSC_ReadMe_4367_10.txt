Title: Emplyee Management System
Description: The beginnings of a Light-Weight Employee Management System! Shows how to use the TableLayoutPanel, BackgroundWorker, TableAdapter, BindingSource, How to perform filtering on a typed dataset as well as searching it, Delegates, Custom Events, Pass Data Between Forms, Access and use custom Application Settings, And how to create nice Login Dialog!
Please post any comments you may have and I will do my best to answer them.
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=4367&lngWId=10

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.

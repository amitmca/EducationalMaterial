#region Using
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using RDB_test.myControls;
#endregion

namespace RDB_test {
    public partial class MainForm : Form {
        #region Reference Variables
        //
        //  Reference Variables
        //
        private userLoginControl newLoginCntrl;
        private String UsersName;
        private System.Diagnostics.Stopwatch myStopWatch;
        private employeeControl newEmployeeCntrl;
        internal bool isLoggedIn;
        #endregion//<--End-->Reference Variables Region

        #region Constructor
        //
        //  Constructor
        //
        public MainForm() {
            InitializeComponent();
            }
        #endregion
        //
        //  MainForm Load
        //
        private void MainForm_Load(object sender, EventArgs e) {
            //  hide the progressBar on the status strip.
            this.toolStripProgressBar1.Visible = false;

            //  set the default value, since we're not logged in.
            this.isLoggedIn = false;

            //  Create a new StopWatch to record how long the user as been online.
            myStopWatch = new System.Diagnostics.Stopwatch();
            myStopWatch.Start();

            //  Disable toolstrip items that are not available yet.
            this.openDocToolStripButton.Enabled = false;
            this.closeDocToolStripButton.Enabled = false;
            }
        //
        //  MainForm FormClosing
        //
        private void MainForm_FormClosing(object sender, FormClosingEventArgs e) {
            //  Ask the user if he/she wishes to quit.
            if (MessageBox.Show("Are you sure you want to Quit?", "Quitting", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.No) {
                e.Cancel = true;
                }
            }

        #region Login, Logout & Account
        #region ShowLogin
        //
        //  ShowLogin
        //
        private void ShowLogin(bool IsLogin) {
            //  Check if there are any controls loaded in the targetPanel collection.
            int i = this.targetPanel.Controls.Count;
            if (i <= 0) {
                //  Check to see if the control is already created.
                if (this.newLoginCntrl == null) {
                    //  Create a new userLoginControl.
                    this.newLoginCntrl = new userLoginControl(IsLogin);

                    //  Change the location of are newly created control.
                    this.newLoginCntrl.Left = 20;
                    this.newLoginCntrl.Top = 20;

                    //  Wire the userLoginControl's custom event handlers.
                    this.newLoginCntrl.loginSuccessful +=
                        new userLoginControl.LoginSuccessful(LoginSuccessful);
                    this.newLoginCntrl.loginUnsuccessful +=
                        new userLoginControl.LoginUnsuccessful(LoginUnsuccessful);
                    this.newLoginCntrl.loginClose +=
                        new userLoginControl.LoginClose(LoginClose);
                    this.newLoginCntrl.accountCreated +=
                        new userLoginControl.AccountCreated(AccountCreated);
                    this.newLoginCntrl.accountNotCreated +=
                        new userLoginControl.AccountNotCreated(AccountNotCreated);
                    this.newLoginCntrl.startMyTimer +=
                        new userLoginControl.StartMyTimer(StartMyTimer);

                    //  Add the control to the TargetPanel.
                    this.targetPanel.Controls.Add(this.newLoginCntrl);

                    //  Show the form.
                    this.newLoginCntrl.Show();
                    }
                }
            }
        #endregion//<--End-->ShowLogin Region

        #region Logout
        //
        //  Logout
        //
        private void Logout() {
            //  If the user has any open documents warn them to close everything first.
            if (this.targetPanel.Controls.Count > 0) {
                MessageBox.Show("Please save your data and close any open documents before proceeding!"
                    , "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
            else {
                this.UsersName = null;
                this.isLoggedIn = false;
                this.statusToolStripStatusLabel.Text = "You have been logged out...";
                this.closeDocToolStripButton.Enabled = false;
                this.openDocToolStripButton.Enabled = false;
                //  Reset the toolTipText to sync with the underlying function.
                this.accountToolStripButton.ToolTipText = "Login or Create a New Account";
                }
            }
        #endregion//<--End-->Logout Region

        #region Login Events
        //
        //  LoginSuccessful
        //
        private void LoginSuccessful(object sender, EventArgs e) {
            //  Store the Name in a Variable.
            this.UsersName = RDB_test.Properties.Settings.Default.UserName;

            //  Alert the user that they have been logged in.
            String msg = String.Format("You have been logged in as \"{0}\"", this.UsersName.ToUpper());
            this.statusToolStripStatusLabel.Text = msg;

            //  Raise the LoginClose Event
            this.LoginClose(sender, e);

            // Turn off progress on the progress bar.
            this.progressTimer.Stop();
            this.toolStripProgressBar1.Visible = false;

            //  Enable tool bar items.
            this.openDocToolStripButton.Enabled = true;

            //  Set the isLoggedIn flag.
            this.isLoggedIn = true;

            //  Change the ToolTipText.
            this.accountToolStripButton.ToolTipText = "Click here to log out";
            }
        //
        //  LoginUnsuccessful
        //
        private void LoginUnsuccessful(object sender, EventArgs e) {
            //  Alert the user that they were not logged in.
            String msg = String.Format("You have not been logged in! Please try again.");
            this.statusToolStripStatusLabel.Text = msg;

            // Turn off progress on the progress bar.
            this.progressTimer.Stop();
            this.toolStripProgressBar1.Visible = false;
            }
        //
        //  LoginClose
        //
        private void LoginClose(object sender, EventArgs e) {
            //  Remove the newLoginCntrl from the TargetPanel's Control List.
            this.targetPanel.Controls.Clear();
            //  Set the control to null so we can re-load it if necessary.
            this.newLoginCntrl = null;
            // Turn off progress on the progress bar.
            this.progressTimer.Stop();
            this.toolStripProgressBar1.Visible = false;
            }
        #endregion//<--End-->Login Events Region

        #region Account
        //
        //  AccountCreated
        //
        private void AccountCreated(object sender, EventArgs e) {
            String msg = ("Account has been created; Please Login!");
            this.statusToolStripStatusLabel.Text = msg;

            // Turn off
            this.progressTimer.Stop();
            this.toolStripProgressBar1.Visible = false;
            }
        //
        //  AccountNotCreated
        //
        private void AccountNotCreated(object sender, EventArgs e) {
            String msg = ("Account was not created; Please try again!");
            this.statusToolStripStatusLabel.Text = msg;

            // Turn off
            this.progressTimer.Stop();
            this.toolStripProgressBar1.Visible = false;
            }
        #endregion//<--End-->Account Region

        #region Progress
        //
        //  StartMyTimer
        //
        private void StartMyTimer(object sender, EventArgs e) {
            //  Show the progressBar.
            this.toolStripProgressBar1.Visible = true;

            //  Start the progress for account operations.
            this.progressTimer.Start();
            }
        #endregion//<--End-->Progress Region
        #endregion//<--End-->Login, Logout & Account Region

        #region Stop Watch
        //
        //  HowLongRunning
        //
        private String HowLongRunning() {
            TimeSpan ts = myStopWatch.Elapsed;
            return String.Format("{0:00}:{1:00}:{2:00}", ts.Hours, ts.Minutes, ts.Seconds);
            }
        #endregion//<--End-->Stop Watch Region
        //
        //  AccountToolStripButton Click
        //
        private void accountToolStripButton_Click(object sender, EventArgs e) {
            //  I wired the events in the menu pertaining to login and account to this event.
            //  Lets see who's firing the event.
            if ((sender is ToolStripMenuItem) || (sender is ToolStripButton)) {
                if ((sender == this.loginToolStripMenuItem) || (sender == this.accountToolStripButton)) {
                    if (this.isLoggedIn == false) {
                        //  User wants to Login.
                        this.ShowLogin(true);
                        }
                    else {
                        this.Logout();
                        }
                    }
                else if (sender == this.createAccountToolStripMenuItem) {
                    //  User wants to create an Account.
                    this.ShowLogin(false);
                    }
                }
            }
        //
        //  ExitToolStripMenuItem Click
        //
        private void exitToolStripMenuItem_Click(object sender, EventArgs e) {
            //  Exit the application.
            Application.Exit();
            }
        //
        //  ProgressTimer Tick
        //
        private void progressTimer_Tick(object sender, EventArgs e) {
            // Update progress bar
            if ((this.toolStripProgressBar1.Value + this.toolStripProgressBar1.Step) > this.toolStripProgressBar1.Maximum) {
                this.toolStripProgressBar1.Value = this.toolStripProgressBar1.Minimum;
                }
            else {
                this.toolStripProgressBar1.Value += this.toolStripProgressBar1.Step;
                }
            }
        //
        //  DetailSheetToolStripMenuItem Click
        //
        private void detailSheetToolStripMenuItem_Click(object sender, EventArgs e) {
            //  If no control exists create one.
            if (this.newEmployeeCntrl == null) {
                this.newEmployeeCntrl = new employeeControl();
                this.newEmployeeCntrl.Left = 20;
                this.newEmployeeCntrl.Top = 20;
                this.targetPanel.Controls.Add(this.newEmployeeCntrl);
                this.newEmployeeCntrl.Show();
                this.closeDocToolStripButton.Enabled = true;
                }
            }
        //
        //  CloseDocToolStripButton Click
        //
        private void closeDocToolStripButton_Click(object sender, EventArgs e) {
            int count = this.targetPanel.Controls.Count;
            //  If there are controls remove them all the targetPanel.
            if (count > 0) {
                this.targetPanel.Controls.Clear();
                this.newLoginCntrl = null;
                this.newEmployeeCntrl = null;
                this.closeDocToolStripButton.Enabled = false;
                }
            }
        //
        //  CutToolStripMenuItem Click
        //
        private void cutToolStripMenuItem_Click(object sender, EventArgs e) {
            //Todo: Create code to capture text from users' documents.
            }
        //
        //  TimeToolStripMenuItem Click
        //
        private void timeToolStripMenuItem_Click(object sender, EventArgs e) {
            //  Create a message to inform the user upon request how long they've been on for.
            String msg = String.Format("You have been on the system for {0}", this.HowLongRunning());
            this.statusToolStripStatusLabel.Text = msg;
            }
        }
    }
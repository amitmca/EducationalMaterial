import java.util.*;

class datenew 
{
	datenew()
	{
		Date today = new Date();
	}
	public static void main(String[] args) 
	{
		new datenew();
	}
}

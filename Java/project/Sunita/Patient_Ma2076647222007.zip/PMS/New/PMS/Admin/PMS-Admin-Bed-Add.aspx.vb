Imports System.Data.SqlClient

Public Class PMS_Admin_Bed_Add
    Inherits System.Web.UI.Page

#Region " Web Form Designer Generated Code "

    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

    End Sub
    Protected WithEvents lblErrorMsg As System.Web.UI.WebControls.Label
    Protected WithEvents Label2 As System.Web.UI.WebControls.Label
    Protected WithEvents Label3 As System.Web.UI.WebControls.Label
    Protected WithEvents btnAdd As System.Web.UI.WebControls.Button
    Protected WithEvents btnUpdate As System.Web.UI.WebControls.Button
    Protected WithEvents btnCancel As System.Web.UI.WebControls.Button
    Protected WithEvents txtBedName As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtBedRate As System.Web.UI.WebControls.TextBox

    'NOTE: The following placeholder declaration is required by the Web Form Designer.
    'Do not delete or move it.
    Private designerPlaceholderDeclaration As System.Object

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: This method call is required by the Web Form Designer
        'Do not modify it using the code editor.
        InitializeComponent()
    End Sub

#End Region
#Region "ConnectionStrings Variables"
    Dim con As New SqlConnection(ConfigurationSettings.AppSettings("PMSconstr"))
    Dim cmd As New SqlCommand
    Dim dr As SqlDataReader
    Dim da As New SqlDataAdapter
    Dim ds As New DataSet
#End Region
#Region "FillUserDetails"
    Sub FillUserDetails(ByVal BedID As Integer)
        con.Open()
        cmd = New SqlCommand("PMS_Bed_Details_Proc", con)
        cmd.CommandType = CommandType.StoredProcedure
        cmd.Parameters.Add("@nBedID", BedID)
        cmd.Parameters.Add("@sMode", "ViewByID")
        dr = cmd.ExecuteReader()
        While dr.Read
            txtBedName.Text = dr("strBedName")
            txtBedRate.Text = dr("strBedRate")
        End While
        con.Close()
    End Sub
#End Region
    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        If Not Page.IsPostBack Then
            If Request("BedID") <> "" Then
                btnAdd.Visible = False
                btnUpdate.Visible = True
                FillUserDetails(Request("BedID"))
            Else
                btnAdd.Visible = True
                btnUpdate.Visible = False
            End If
        End If
    End Sub
    Private Sub btnAdd_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnAdd.Click
        Dim iresult As Integer
        con.Open()
        cmd = New SqlCommand("PMS_Bed_Details_Proc", con)
        cmd.CommandType = CommandType.StoredProcedure
        cmd.Parameters.Add("@sMode", "Create")
        cmd.Parameters.Add("@strBedName", txtBedName.Text)
        cmd.Parameters.Add("@strBedRate", txtBedRate.Text)
        iresult = cmd.ExecuteNonQuery()
        con.Close()
        If iresult = 1 Then
            Response.Redirect("PMS-Admin-Bed-Details.aspx")
        Else
            lblErrorMsg.Text = "Bed cannot be added"
        End If
    End Sub

    Private Sub btnCancel_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnCancel.Click
        Response.Redirect("PMS-Admin-Bed-Details.aspx")
    End Sub

    Private Sub btnUpdate_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnUpdate.Click

        Dim iresult As Integer
        con.Open()
        cmd = New SqlCommand("PMS_Bed_Details_Proc", con)
        cmd.CommandType = CommandType.StoredProcedure
        cmd.Parameters.Add("@sMode", "Update")
        cmd.Parameters.Add("@nBedID", Request("BedID"))
        cmd.Parameters.Add("@strBedName", txtBedName.Text)
        cmd.Parameters.Add("@strBedRate", txtBedRate.Text)
        iresult = cmd.ExecuteNonQuery()
        con.Close()
        If iresult = 1 Then
            Response.Redirect("PMS-Admin-Bed-Details.aspx")
        Else
            lblErrorMsg.Text = "Bed cannot be updated"
        End If
    End Sub
End Class

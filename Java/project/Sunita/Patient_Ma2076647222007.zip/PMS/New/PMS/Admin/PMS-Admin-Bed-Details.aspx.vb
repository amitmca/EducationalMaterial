Imports System.Data.SqlClient
Public Class PMS_Admin_Bed_Details
    Inherits System.Web.UI.Page

#Region " Web Form Designer Generated Code "

    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

    End Sub
    Protected WithEvents lblErrorMsg As System.Web.UI.WebControls.Label
    Protected WithEvents btnAddNew As System.Web.UI.WebControls.Button
    Protected WithEvents dgAdministrator As System.Web.UI.WebControls.DataGrid

    'NOTE: The following placeholder declaration is required by the Web Form Designer.
    'Do not delete or move it.
    Private designerPlaceholderDeclaration As System.Object

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: This method call is required by the Web Form Designer
        'Do not modify it using the code editor.
        InitializeComponent()
    End Sub

#End Region
#Region "ConnectionStrings Variables"
    Dim con As New SqlConnection(ConfigurationSettings.AppSettings("PMSconstr"))
    Dim cmd As New SqlCommand
    Dim dr As SqlDataReader
    Dim da As New SqlDataAdapter
    Dim ds As New DataSet
#End Region
#Region "BindDataGrid"
    Sub BindDataGrid()
        con.Open()
        cmd = New SqlCommand("PMS_Bed_Details_Proc", con)
        cmd.CommandType = CommandType.StoredProcedure
        cmd.Parameters.Add("@sMode", "View")
        da.SelectCommand = cmd
        da.Fill(ds, "Bed_Tbl")
        con.Close()
        dgAdministrator.DataSource = ds.Tables("Bed_Tbl")
        dgAdministrator.DataBind()
    End Sub
#End Region
    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        If Not Page.IsPostBack Then
            BindDataGrid()
        End If
    End Sub
    Private Sub btnAddNew_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnAddNew.Click
        Response.Redirect("PMS-Admin-Bed-Add.aspx")
    End Sub
    Private Sub dgAdministrator_ItemDataBound(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.DataGridItemEventArgs) Handles dgAdministrator.ItemDataBound
        If (e.Item.ItemType = ListItemType.Header) Or (e.Item.ItemType = ListItemType.Footer) Then
            Return
        End If
        Dim cellItem As TableCell = CType(e.Item.Cells(5), TableCell)
        Dim LBtnDel As Button = CType(cellItem.Controls(1), Button)
        LBtnDel.Attributes.Add("onclick", "javascript: return confirm('Are you sure you want to delete?')")

    End Sub

    Private Sub dgAdministrator_ItemCommand(ByVal source As Object, ByVal e As System.Web.UI.WebControls.DataGridCommandEventArgs) Handles dgAdministrator.ItemCommand
        If e.CommandName = "Edit" Then
            Response.Redirect("PMS-Admin-Bed-Add.aspx?BedID=" & e.Item.Cells(0).Text)
        End If
        If e.CommandName = "Delete" Then
            con.Open()
            cmd = New SqlCommand("PMS_Bed_Details_Proc", con)
            cmd.CommandType = CommandType.StoredProcedure
            cmd.Parameters.Add("@nBedID", e.Item.Cells(0).Text)
            cmd.Parameters.Add("@sMode", "Delete")
            cmd.ExecuteNonQuery()
            con.Close()
            lblErrorMsg.Text = "Bed '" & e.Item.Cells(1).Text & "' was sucessfully deleted"
            BindDataGrid()
        End If
    End Sub

    Private Sub dgAdministrator_PageIndexChanged(ByVal source As Object, ByVal e As System.Web.UI.WebControls.DataGridPageChangedEventArgs) Handles dgAdministrator.PageIndexChanged
        dgAdministrator.CurrentPageIndex = e.NewPageIndex()
        BindDataGrid()
    End Sub
    Function getStatus(ByVal StatusID As Integer)
        If StatusID = 0 Then
            Return "Free"
        ElseIf StatusID = 1 Then
            Return "Allocated"
        End If
    End Function
End Class

Imports System.Data.SqlClient
Public Class PMS_Admin_Doctors_Add
    Inherits System.Web.UI.Page

#Region " Web Form Designer Generated Code "

    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

    End Sub
    Protected WithEvents lblErrorMsg As System.Web.UI.WebControls.Label
    Protected WithEvents Label2 As System.Web.UI.WebControls.Label
    Protected WithEvents btnAdd As System.Web.UI.WebControls.Button
    Protected WithEvents btnUpdate As System.Web.UI.WebControls.Button
    Protected WithEvents btnCancel As System.Web.UI.WebControls.Button
    Protected WithEvents Label3 As System.Web.UI.WebControls.Label
    Protected WithEvents Label1 As System.Web.UI.WebControls.Label
    Protected WithEvents Label4 As System.Web.UI.WebControls.Label
    Protected WithEvents Label5 As System.Web.UI.WebControls.Label
    Protected WithEvents Label6 As System.Web.UI.WebControls.Label
    Protected WithEvents txtDoctorsName As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtDoctorsAddress As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtDoctorsPhone As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtDocotrsSpecial As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtDoctorsUsername As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtDoctorsPassword As System.Web.UI.WebControls.TextBox

    'NOTE: The following placeholder declaration is required by the Web Form Designer.
    'Do not delete or move it.
    Private designerPlaceholderDeclaration As System.Object

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: This method call is required by the Web Form Designer
        'Do not modify it using the code editor.
        InitializeComponent()
    End Sub

#End Region
#Region "ConnectionStrings Variables"
    Dim con As New SqlConnection(ConfigurationSettings.AppSettings("PMSconstr"))
    Dim cmd As New SqlCommand
    Dim dr As SqlDataReader
    Dim da As New SqlDataAdapter
    Dim ds As New DataSet
#End Region
#Region "FillUserDetails"
    Sub FillUserDetails(ByVal DoctorID As Integer)
        con.Open()
        cmd = New SqlCommand("PMS_Doctors_Details_Proc", con)
        cmd.CommandType = CommandType.StoredProcedure
        cmd.Parameters.Add("@nDoctorsID", DoctorID)
        cmd.Parameters.Add("@sMode", "ViewByID")
        dr = cmd.ExecuteReader()
        While dr.Read
            txtDoctorsName.Text = dr("strDoctorsName")
            txtDoctorsAddress.Text = dr("strDoctorsAddress")
            txtDoctorsPhone.Text = dr("strDoctorsPhone")
            txtDocotrsSpecial.Text = dr("strDoctorsSpecial")
            txtDoctorsUsername.Text = dr("strDoctorsUsername")
            txtDoctorsPassword.Text = dr("strDoctorsPassword")
        End While
        con.Close()
    End Sub
#End Region
    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        If Not Page.IsPostBack Then
            If Request("DoctorID") <> "" Then
                btnAdd.Visible = False
                btnUpdate.Visible = True
                txtDoctorsUsername.ReadOnly = True
                FillUserDetails(Request("DoctorID"))
            Else
                btnAdd.Visible = True
                btnUpdate.Visible = False
            End If
        End If
    End Sub
    Private Sub btnAdd_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnAdd.Click
        Dim iresult As Integer
        con.Open()
        cmd = New SqlCommand("PMS_Doctors_Details_Proc", con)
        cmd.CommandType = CommandType.StoredProcedure
        cmd.Parameters.Add("@sMode", "Create")
        cmd.Parameters.Add("@strDoctorsName", txtDoctorsName.Text)
        cmd.Parameters.Add("@strDoctorsAddress", txtDoctorsAddress.Text)
        cmd.Parameters.Add("@strDoctorsPhone", txtDoctorsPhone.Text)
        cmd.Parameters.Add("@strDoctorsSpecial", txtDocotrsSpecial.Text)
        cmd.Parameters.Add("@strDoctorsUsername", txtDoctorsUsername.Text)
        cmd.Parameters.Add("@strDoctorsPassword", txtDoctorsPassword.Text)
        iresult = cmd.ExecuteNonQuery()
        con.Close()
        If iresult = 1 Then
            Response.Redirect("PMS-Admin-Doctors-Details.aspx")
        Else
            lblErrorMsg.Text = "Docotrs Username already Exist. Please select another Username."
        End If
    End Sub

    Private Sub btnCancel_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnCancel.Click
        Response.Redirect("PMS-Admin-Doctors-Details.aspx")
    End Sub

    Private Sub btnUpdate_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnUpdate.Click

        Dim iresult As Integer
        con.Open()
        cmd = New SqlCommand("PMS_Doctors_Details_Proc", con)
        cmd.CommandType = CommandType.StoredProcedure
        cmd.Parameters.Add("@sMode", "Update")
        cmd.Parameters.Add("@nDoctorsID", Request("DoctorID"))
        cmd.Parameters.Add("@strDoctorsName", txtDoctorsName.Text)
        cmd.Parameters.Add("@strDoctorsAddress", txtDoctorsAddress.Text)
        cmd.Parameters.Add("@strDoctorsPhone", txtDoctorsPhone.Text)
        cmd.Parameters.Add("@strDoctorsSpecial", txtDocotrsSpecial.Text)
        cmd.Parameters.Add("@strDoctorsPassword", txtDoctorsPassword.Text)
        iresult = cmd.ExecuteNonQuery()
        con.Close()
        If iresult = 1 Then
            Response.Redirect("PMS-Admin-Doctors-Details.aspx")
        End If
    End Sub
End Class

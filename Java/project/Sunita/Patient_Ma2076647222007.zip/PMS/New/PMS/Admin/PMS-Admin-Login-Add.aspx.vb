Imports System.Data.SqlClient

Public Class PMS_Admin_Login_Add
    Inherits System.Web.UI.Page

#Region " Web Form Designer Generated Code "

    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

    End Sub
    Protected WithEvents btnCancel As System.Web.UI.WebControls.Button
    Protected WithEvents btnUpdate As System.Web.UI.WebControls.Button
    Protected WithEvents btnAdd As System.Web.UI.WebControls.Button
    Protected WithEvents txtPassword As System.Web.UI.WebControls.TextBox
    Protected WithEvents Label3 As System.Web.UI.WebControls.Label
    Protected WithEvents txtUserName As System.Web.UI.WebControls.TextBox
    Protected WithEvents Label2 As System.Web.UI.WebControls.Label
    Protected WithEvents drpAdminType As System.Web.UI.WebControls.DropDownList
    Protected WithEvents Label1 As System.Web.UI.WebControls.Label
    Protected WithEvents lblErrorMsg As System.Web.UI.WebControls.Label

    'NOTE: The following placeholder declaration is required by the Web Form Designer.
    'Do not delete or move it.
    Private designerPlaceholderDeclaration As System.Object

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: This method call is required by the Web Form Designer
        'Do not modify it using the code editor.
        InitializeComponent()
    End Sub

#End Region
#Region "ConnectionStrings Variables"
    Dim con As New SqlConnection(ConfigurationSettings.AppSettings("PMSconstr"))
    Dim cmd As New SqlCommand
    Dim dr As SqlDataReader
    Dim da As New SqlDataAdapter
    Dim ds As New DataSet
#End Region
#Region "FillUserDetails"
    Sub FillUserDetails(ByVal nAdminID As Integer)
        con.Open()
        cmd = New SqlCommand("PMS_Admin_Login_Details_Proc", con)
        cmd.CommandType = CommandType.StoredProcedure
        cmd.Parameters.Add("@nAdminID", nAdminID)
        cmd.Parameters.Add("@sMode", "ViewByID")
        dr = cmd.ExecuteReader()
        While dr.Read
            txtUserName.Text = dr("strUserName")
            txtPassword.Text = dr("strPassword")
            Dim liSelect As New ListItem
            liSelect.Text = dr("strAdminType")
            liSelect.Value = dr("strAdminType")
            drpAdminType.SelectedIndex = drpAdminType.Items.IndexOf(liSelect)
        End While
        con.Close()
    End Sub
#End Region
    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        If Not Page.IsPostBack Then
            btnAdd.Attributes.Add("onclick", "javascript: return ValidateForm();")
            btnUpdate.Attributes.Add("onclick", "javascript: return ValidateForm();")

            If Request("AdminID") <> "" Then
                btnAdd.Visible = False
                btnUpdate.Visible = True
                txtUserName.ReadOnly = True
                FillUserDetails(Request("AdminID"))
            Else
                btnAdd.Visible = True
                btnUpdate.Visible = False
            End If
        End If
    End Sub
    Private Sub btnAdd_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnAdd.Click
        Dim iresult As Integer
        con.Open()
        cmd = New SqlCommand("PMS_Admin_Login_Details_Proc", con)
        cmd.CommandType = CommandType.StoredProcedure
        cmd.Parameters.Add("@sMode", "Create")
        cmd.Parameters.Add("@strUsername", txtUserName.Text)
        cmd.Parameters.Add("@strPassword", txtPassword.Text)
        cmd.Parameters.Add("@strAdminType", drpAdminType.SelectedValue)
        iresult = cmd.ExecuteNonQuery()
        con.Close()
        If iresult = 1 Then
            Response.Redirect("PMS-Admin-Login-Details.aspx")
        Else
            lblErrorMsg.Text = "Username already Exist. Please select another Username."
        End If
    End Sub

    Private Sub btnCancel_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnCancel.Click
        Response.Redirect("PMS-Admin-Login-Details.aspx")
    End Sub

    Private Sub btnUpdate_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnUpdate.Click

        Dim iresult As Integer
        con.Open()
        cmd = New SqlCommand("PMS_Admin_Login_Details_Proc", con)
        cmd.CommandType = CommandType.StoredProcedure
        cmd.Parameters.Add("@sMode", "Update")
        cmd.Parameters.Add("@nAdminID", Request("AdminID"))
        cmd.Parameters.Add("@strPassword", txtPassword.Text)
        cmd.Parameters.Add("@strAdminType", drpAdminType.SelectedValue)
        iresult = cmd.ExecuteNonQuery()
        con.Close()
        If iresult = 1 Then
            Response.Redirect("PMS-Admin-Login-Details.aspx")
        Else
            lblErrorMsg.Text = "Username already Exist. Please select another Username."
        End If
    End Sub
End Class

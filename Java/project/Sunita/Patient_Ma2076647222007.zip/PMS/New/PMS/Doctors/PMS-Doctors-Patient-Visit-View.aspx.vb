Imports System.Data.SqlClient

Public Class PMS_Doctors_Patient_Visit_View
    Inherits System.Web.UI.Page

#Region " Web Form Designer Generated Code "

    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

    End Sub
    Protected WithEvents lblErrorMsg As System.Web.UI.WebControls.Label
    Protected WithEvents Label2 As System.Web.UI.WebControls.Label
    Protected WithEvents txtPatientName As System.Web.UI.WebControls.TextBox
    Protected WithEvents Label3 As System.Web.UI.WebControls.Label
    Protected WithEvents Label4 As System.Web.UI.WebControls.Label
    Protected WithEvents Label1 As System.Web.UI.WebControls.Label
    Protected WithEvents txtPatientSymptoms As System.Web.UI.WebControls.TextBox
    Protected WithEvents btnCancel As System.Web.UI.WebControls.Button
    Protected WithEvents btnUpdate As System.Web.UI.WebControls.Button
    Protected WithEvents Label5 As System.Web.UI.WebControls.Label
    Protected WithEvents Label6 As System.Web.UI.WebControls.Label
    Protected WithEvents btnDischarge As System.Web.UI.WebControls.Button
    Protected WithEvents lblBedID As System.Web.UI.WebControls.Label
    Protected WithEvents txtPatientDisease As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtPatientTreatment As System.Web.UI.WebControls.TextBox
    Protected WithEvents Label7 As System.Web.UI.WebControls.Label
    Protected WithEvents lblPatientID As System.Web.UI.WebControls.Label
    Protected WithEvents txtPatientType As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtBedName As System.Web.UI.WebControls.TextBox

    'NOTE: The following placeholder declaration is required by the Web Form Designer.
    'Do not delete or move it.
    Private designerPlaceholderDeclaration As System.Object

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: This method call is required by the Web Form Designer
        'Do not modify it using the code editor.
        InitializeComponent()
    End Sub

#End Region
#Region "ConnectionStrings Variables"
    Dim con As New SqlConnection(ConfigurationSettings.AppSettings("PMSconstr"))
    Dim cmd As New SqlCommand
    Dim dr As SqlDataReader
    Dim da As New SqlDataAdapter
    Dim ds As New DataSet
#End Region
#Region "FillUserDetails"
    Sub FillVisitDetails(ByVal VisitID As Integer)
        con.Open()
        cmd = New SqlCommand("PMS_Patient_Visit_Details_Proc", con)
        cmd.CommandType = CommandType.StoredProcedure
        cmd.Parameters.Add("@nPatientVisitID", VisitID)
        cmd.Parameters.Add("@sMode", "ViewByID")
        dr = cmd.ExecuteReader()
        While dr.Read
            lblPatientID.Text = dr("nPatientID")
            If dr("nPatientType") = 0 Then
                txtPatientType.Text = "Out Patient"
            Else
                txtPatientType.Text = "In Patient"
            End If
            lblBedID.Text = dr("nBedID")
            txtPatientSymptoms.Text = dr("strSymptoms")
            txtPatientDisease.Text = dr("strDisease")
            txtPatientTreatment.Text = dr("strTreatment")
        End While
        con.Close()
        FillPatientDetails(lblPatientID.Text)
        FillBedDetails(lblBedID.Text)
    End Sub

    Sub FillPatientDetails(ByVal PatientID As Integer)
        con.Open()
        cmd = New SqlCommand("PMS_Patient_Details_Proc", con)
        cmd.CommandType = CommandType.StoredProcedure
        cmd.Parameters.Add("@nPatientID", PatientID)
        cmd.Parameters.Add("@sMode", "ViewByID")
        dr = cmd.ExecuteReader()
        While dr.Read
            txtPatientName.Text = dr("strPatientName")
        End While
        con.Close()
    End Sub
    Sub FillBedDetails(ByVal BedID As Integer)
        txtBedName.Text = "None"
        con.Open()
        cmd = New SqlCommand("PMS_Bed_Details_Proc", con)
        cmd.CommandType = CommandType.StoredProcedure
        cmd.Parameters.Add("@nBedID", BedID)
        cmd.Parameters.Add("@sMode", "ViewByID")
        dr = cmd.ExecuteReader()
        While dr.Read
            txtBedName.Text = dr("strBedName")
        End While
        con.Close()
    End Sub


#End Region
    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        If Not Page.IsPostBack Then
            If Request("VisitID") <> "" Then
                FillVisitDetails(Request("VisitID"))
            End If
        End If
    End Sub

    Private Sub btnCancel_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnCancel.Click
        Response.Redirect("PMS-Doctors-Patient-Visit.aspx")
    End Sub

    Private Sub btnUpdate_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnUpdate.Click
        con.Open()
        cmd = New SqlCommand("PMS_Patient_Visit_Details_Proc", con)
        cmd.CommandType = CommandType.StoredProcedure
        cmd.Parameters.Add("@nPatientVisitID", Request("VisitID"))
        cmd.Parameters.Add("@strSymptoms", txtPatientSymptoms.Text)
        cmd.Parameters.Add("@strDisease", txtPatientDisease.Text)
        cmd.Parameters.Add("@strTreatment", txtPatientTreatment.Text)
        cmd.Parameters.Add("@sMode", "UpdateDoctors")
        cmd.ExecuteNonQuery()
        con.Close()

        If txtPatientType.Text = "Out Patient" Then
            con.Open()
            cmd = New SqlCommand("PMS_Patient_Visit_Details_Proc", con)
            cmd.CommandType = CommandType.StoredProcedure
            cmd.Parameters.Add("@nPatientVisitID", Request("VisitID"))
            cmd.Parameters.Add("@sMode", "UpdateDischargeStatus")
            cmd.ExecuteNonQuery()
            con.Close()
        End If

        Response.Redirect("PMS-Doctors-Patient-Visit.aspx")
    End Sub

    Private Sub btnDischarge_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnDischarge.Click
        If txtPatientType.Text = "In Patient" Then
            con.Open()
            cmd = New SqlCommand("PMS_Patient_Visit_Details_Proc", con)
            cmd.CommandType = CommandType.StoredProcedure
            cmd.Parameters.Add("@nPatientVisitID", Request("VisitID"))
            cmd.Parameters.Add("@strSymptoms", txtPatientSymptoms.Text)
            cmd.Parameters.Add("@strDisease", txtPatientDisease.Text)
            cmd.Parameters.Add("@strTreatment", txtPatientTreatment.Text)
            cmd.Parameters.Add("@sMode", "UpdateDoctors")
            cmd.ExecuteNonQuery()
            con.Close()

            con.Open()
            cmd = New SqlCommand("PMS_Patient_Visit_Details_Proc", con)
            cmd.CommandType = CommandType.StoredProcedure
            cmd.Parameters.Add("@nPatientVisitID", Request("VisitID"))
            cmd.Parameters.Add("@sMode", "UpdateDischargeStatus")
            cmd.ExecuteNonQuery()
            con.Close()

            con.Open()
            cmd = New SqlCommand("PMS_Bed_Details_Proc", con)
            cmd.CommandType = CommandType.StoredProcedure
            cmd.Parameters.Add("@nBedID", lblBedID.Text)
            cmd.Parameters.Add("@nBedBooked", "0")
            cmd.Parameters.Add("@sMode", "UpdateStatus")
            cmd.ExecuteNonQuery()
            con.Close()
            Response.Redirect("PMS-Doctors-Patient-Visit.aspx")
        Else
            lblErrorMsg.Text = "The Patient is OUT Patient. So cant be discharged"
        End If
    End Sub
End Class

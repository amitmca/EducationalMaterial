Imports System.Data.SqlClient

Public Class PMS_Doctors_Patient_Visit
    Inherits System.Web.UI.Page

#Region " Web Form Designer Generated Code "

    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

    End Sub
    Protected WithEvents lblErrorMsg As System.Web.UI.WebControls.Label
    Protected WithEvents dgAdministrator As System.Web.UI.WebControls.DataGrid

    'NOTE: The following placeholder declaration is required by the Web Form Designer.
    'Do not delete or move it.
    Private designerPlaceholderDeclaration As System.Object

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: This method call is required by the Web Form Designer
        'Do not modify it using the code editor.
        InitializeComponent()
    End Sub

#End Region
#Region "ConnectionStrings Variables"
    Dim con As New SqlConnection(ConfigurationSettings.AppSettings("PMSconstr"))
    Dim cmd As New SqlCommand
    Dim dr As SqlDataReader
    Dim da As New SqlDataAdapter
    Dim ds As New DataSet
#End Region
#Region "BindDataGrid"
    Sub BindDataGrid()
        con.Open()
        cmd = New SqlCommand("PMS_Patient_Visit_Details_Proc", con)
        cmd.CommandType = CommandType.StoredProcedure
        cmd.Parameters.Add("@sMode", "ViewForDoctors")
        cmd.Parameters.Add("@nDoctorsID", Session("DoctorID"))
        da.SelectCommand = cmd
        da.Fill(ds, "Patient_Visit_Tbl")
        con.Close()
        dgAdministrator.DataSource = ds.Tables("Patient_Visit_Tbl")
        dgAdministrator.DataBind()
    End Sub
#End Region
    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        If Not Page.IsPostBack Then
            BindDataGrid()
        End If
    End Sub

    Private Sub dgAdministrator_ItemCommand(ByVal source As Object, ByVal e As System.Web.UI.WebControls.DataGridCommandEventArgs) Handles dgAdministrator.ItemCommand
        If e.CommandName = "View" Then
            Response.Redirect("PMS-Doctors-Patient-Visit-View.aspx?VisitID=" & e.Item.Cells(0).Text)
        End If
    End Sub

    Private Sub dgAdministrator_PageIndexChanged(ByVal source As Object, ByVal e As System.Web.UI.WebControls.DataGridPageChangedEventArgs) Handles dgAdministrator.PageIndexChanged
        dgAdministrator.CurrentPageIndex = e.NewPageIndex()
        BindDataGrid()
    End Sub
    Function getPatientName(ByVal PatientID As Integer)
        Dim strPatientName As String
        con.Open()
        cmd = New SqlCommand("PMS_Patient_Details_Proc", con)
        cmd.CommandType = CommandType.StoredProcedure
        cmd.Parameters.Add("@nPatientID", PatientID)
        cmd.Parameters.Add("@sMode", "ViewByID")
        dr = cmd.ExecuteReader()
        While dr.Read
            strPatientName = dr("strPatientName")
        End While
        con.Close()
        Return strPatientName
    End Function

End Class

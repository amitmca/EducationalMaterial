Imports System.Data.SqlClient
Public Class PMS_Staff_Patient_Add
    Inherits System.Web.UI.Page

#Region " Web Form Designer Generated Code "

    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

    End Sub
    Protected WithEvents lblErrorMsg As System.Web.UI.WebControls.Label
    Protected WithEvents Label2 As System.Web.UI.WebControls.Label
    Protected WithEvents Label3 As System.Web.UI.WebControls.Label
    Protected WithEvents Label1 As System.Web.UI.WebControls.Label
    Protected WithEvents Label4 As System.Web.UI.WebControls.Label
    Protected WithEvents btnAdd As System.Web.UI.WebControls.Button
    Protected WithEvents btnUpdate As System.Web.UI.WebControls.Button
    Protected WithEvents btnCancel As System.Web.UI.WebControls.Button
    Protected WithEvents Label7 As System.Web.UI.WebControls.Label
    Protected WithEvents Label8 As System.Web.UI.WebControls.Label
    Protected WithEvents txtPatientName As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtPatientAddress As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtPatientPhone As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtPatientDOB As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtPatientBloodGrp As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtPatientEmergency As System.Web.UI.WebControls.TextBox
    Protected WithEvents Label5 As System.Web.UI.WebControls.Label

    'NOTE: The following placeholder declaration is required by the Web Form Designer.
    'Do not delete or move it.
    Private designerPlaceholderDeclaration As System.Object

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: This method call is required by the Web Form Designer
        'Do not modify it using the code editor.
        InitializeComponent()
    End Sub

#End Region
#Region "ConnectionStrings Variables"
    Dim con As New SqlConnection(ConfigurationSettings.AppSettings("PMSconstr"))
    Dim cmd As New SqlCommand
    Dim dr As SqlDataReader
    Dim da As New SqlDataAdapter
    Dim ds As New DataSet
#End Region
#Region "FillUserDetails"
    Sub FillUserDetails(ByVal PatientID As Integer)
        con.Open()
        cmd = New SqlCommand("PMS_Patient_Details_Proc", con)
        cmd.CommandType = CommandType.StoredProcedure
        cmd.Parameters.Add("@nPatientID", PatientID)
        cmd.Parameters.Add("@sMode", "ViewByID")
        dr = cmd.ExecuteReader()
        While dr.Read
            txtPatientName.Text = dr("strPatientName")
            txtPatientDOB.Text = dr("strPatientDOB")
            txtPatientAddress.Text = dr("strPatientAddress")
            txtPatientPhone.Text = dr("strPatientPhone")
            txtPatientBloodGrp.Text = dr("strPatientBloodGroup")
            txtPatientEmergency.Text = dr("strPatientEmergency")
        End While
        con.Close()
    End Sub
#End Region
    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        If Not Page.IsPostBack Then
            If Request("PatientID") <> "" Then
                btnAdd.Visible = False
                btnUpdate.Visible = True
                FillUserDetails(Request("PatientID"))
            Else
                btnAdd.Visible = True
                btnUpdate.Visible = False
            End If
        End If
    End Sub
    Private Sub btnAdd_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnAdd.Click
        Dim iresult As Integer
        con.Open()
        cmd = New SqlCommand("PMS_Patient_Details_Proc", con)
        cmd.CommandType = CommandType.StoredProcedure
        cmd.Parameters.Add("@sMode", "Create")
        cmd.Parameters.Add("@strPatientName", txtPatientName.Text)
        cmd.Parameters.Add("@strPatientDOB", txtPatientDOB.Text)
        cmd.Parameters.Add("@strPatientAddress", txtPatientAddress.Text)
        cmd.Parameters.Add("@strPatientPhone", txtPatientPhone.Text)
        cmd.Parameters.Add("@strPatientBloodGroup", txtPatientBloodGrp.Text)
        cmd.Parameters.Add("@strPatientEmergency", txtPatientEmergency.Text)
        iresult = cmd.ExecuteNonQuery()
        con.Close()
        If iresult = 1 Then
            Response.Redirect("PMS-Staff-Patient-Details.aspx")
        Else
            lblErrorMsg.Text = "Patient cannot be added successfully."
        End If
    End Sub

    Private Sub btnCancel_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnCancel.Click
        Response.Redirect("PMS-Staff-Patient-Details.aspx")
    End Sub

    Private Sub btnUpdate_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnUpdate.Click

        Dim iresult As Integer
        con.Open()
        cmd = New SqlCommand("PMS_Patient_Details_Proc", con)
        cmd.CommandType = CommandType.StoredProcedure
        cmd.Parameters.Add("@sMode", "Update")
        cmd.Parameters.Add("@nPatientID", Request("PatientID"))
        cmd.Parameters.Add("@strPatientName", txtPatientName.Text)
        cmd.Parameters.Add("@strPatientDOB", txtPatientDOB.Text)
        cmd.Parameters.Add("@strPatientAddress", txtPatientAddress.Text)
        cmd.Parameters.Add("@strPatientPhone", txtPatientPhone.Text)
        cmd.Parameters.Add("@strPatientBloodGroup", txtPatientBloodGrp.Text)
        cmd.Parameters.Add("@strPatientEmergency", txtPatientEmergency.Text)
        iresult = cmd.ExecuteNonQuery()
        con.Close()
        If iresult = 1 Then
            Response.Redirect("PMS-Staff-Patient-Details.aspx")
        End If
    End Sub
End Class

Imports System.Data.SqlClient

Public Class PMS_Staff_Patient_Visit_Add
    Inherits System.Web.UI.Page

#Region " Web Form Designer Generated Code "

    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

    End Sub
    Protected WithEvents lblErrorMsg As System.Web.UI.WebControls.Label
    Protected WithEvents Label2 As System.Web.UI.WebControls.Label
    Protected WithEvents Label7 As System.Web.UI.WebControls.Label
    Protected WithEvents Label8 As System.Web.UI.WebControls.Label
    Protected WithEvents btnCancel As System.Web.UI.WebControls.Button
    Protected WithEvents txtPatientName As System.Web.UI.WebControls.TextBox
    Protected WithEvents ddlDoctors As System.Web.UI.WebControls.DropDownList
    Protected WithEvents txtDoctorSpecial As System.Web.UI.WebControls.TextBox
    Protected WithEvents btnAssign As System.Web.UI.WebControls.Button
    Protected WithEvents Label1 As System.Web.UI.WebControls.Label
    Protected WithEvents txtPatientSymptoms As System.Web.UI.WebControls.TextBox
    Protected WithEvents Label3 As System.Web.UI.WebControls.Label
    Protected WithEvents Label4 As System.Web.UI.WebControls.Label
    Protected WithEvents dllPatientType As System.Web.UI.WebControls.DropDownList
    Protected WithEvents dllBed As System.Web.UI.WebControls.DropDownList

    'NOTE: The following placeholder declaration is required by the Web Form Designer.
    'Do not delete or move it.
    Private designerPlaceholderDeclaration As System.Object

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: This method call is required by the Web Form Designer
        'Do not modify it using the code editor.
        InitializeComponent()
    End Sub

#End Region
#Region "ConnectionStrings Variables"
    Dim con As New SqlConnection(ConfigurationSettings.AppSettings("PMSconstr"))
    Dim cmd As New SqlCommand
    Dim dr As SqlDataReader
    Dim da As New SqlDataAdapter
    Dim ds As New DataSet
#End Region
#Region "FillUserDetails"
    Sub FillPatientDetails(ByVal PatientID As Integer)
        con.Open()
        cmd = New SqlCommand("PMS_Patient_Details_Proc", con)
        cmd.CommandType = CommandType.StoredProcedure
        cmd.Parameters.Add("@nPatientID", PatientID)
        cmd.Parameters.Add("@sMode", "ViewByID")
        dr = cmd.ExecuteReader()
        While dr.Read
            txtPatientName.Text = dr("strPatientName")
        End While
        con.Close()
    End Sub
    Sub FillDoctorsDetails()
        con.Open()
        cmd = New SqlCommand("PMS_Doctors_Details_Proc", con)
        cmd.CommandType = CommandType.StoredProcedure
        cmd.Parameters.Add("@sMode", "View")
        da.SelectCommand = cmd
        da.Fill(ds, "Doctors_Tbl")
        con.Close()
        ddlDoctors.DataTextField = "strDoctorsName"
        ddlDoctors.DataValueField = "nDoctorsID"
        ddlDoctors.DataSource = ds.Tables("Doctors_Tbl")
        ddlDoctors.DataBind()
        ddlDoctors.Items.Insert(0, "Select a Doctor")
    End Sub

    Sub FillBedDetails()
        con.Open()
        cmd = New SqlCommand("PMS_Bed_Details_Proc", con)
        cmd.CommandType = CommandType.StoredProcedure
        cmd.Parameters.Add("@sMode", "ViewFree")
        da.SelectCommand = cmd
        da.Fill(ds, "Bed_Tbl")
        con.Close()
        dllBed.DataTextField = "strBedName"
        dllBed.DataValueField = "nBedID"
        dllBed.DataSource = ds.Tables("Bed_Tbl")
        dllBed.DataBind()
        Dim lBed As New ListItem
        lBed.Text = "Select a Bed"
        lBed.Value = 0
        dllBed.Items.Insert(0, lBed)
    End Sub

    Sub GetDoctorsSpecial(ByVal DoctorID As Integer)
        con.Open()
        cmd = New SqlCommand("PMS_Doctors_Details_Proc", con)
        cmd.CommandType = CommandType.StoredProcedure
        cmd.Parameters.Add("@nDoctorsID", DoctorID)
        cmd.Parameters.Add("@sMode", "ViewByID")
        dr = cmd.ExecuteReader()
        While dr.Read
            txtDoctorSpecial.Text = dr("strDoctorsSpecial")
        End While
        con.Close()
    End Sub
#End Region
    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        If Not Page.IsPostBack Then
            If Request("PatientID") <> "" Then
                FillPatientDetails(Request("PatientID"))
                FillDoctorsDetails()
                FillBedDetails()
            End If
        End If
    End Sub

    Private Sub btnCancel_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnCancel.Click
        Response.Redirect("PMS-Staff-Patient-Visit-Details.aspx")
    End Sub

    Private Sub ddlDoctors_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ddlDoctors.SelectedIndexChanged
        If Not ddlDoctors.SelectedIndex = 0 Then
            GetDoctorsSpecial(ddlDoctors.SelectedValue)
        End If
    End Sub

    Private Sub btnAssign_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnAssign.Click
        If dllBed.SelectedIndex = 0 And dllPatientType.SelectedValue = 1 Then
            lblErrorMsg.Text = "Please select a bed for the Patient"
            Exit Sub
        End If
        Dim iresult As Integer
        con.Open()
        cmd = New SqlCommand("PMS_Patient_Visit_Details_Proc", con)
        cmd.CommandType = CommandType.StoredProcedure
        cmd.Parameters.Add("@sMode", "Create")
        cmd.Parameters.Add("@nPatientID", Request("PatientID"))
        cmd.Parameters.Add("@nPatientType", dllPatientType.SelectedValue)
        cmd.Parameters.Add("@nDoctorsID", ddlDoctors.SelectedValue)
        cmd.Parameters.Add("@nBedID", dllBed.SelectedValue)
        cmd.Parameters.Add("@strSymptoms", txtPatientSymptoms.Text)
        iresult = cmd.ExecuteNonQuery()
        con.Close()
        If iresult = 1 Then
            con.Open()
            cmd = New SqlCommand("PMS_Bed_Details_Proc", con)
            cmd.CommandType = CommandType.StoredProcedure
            cmd.Parameters.Add("@nBedID", dllBed.SelectedValue)
            cmd.Parameters.Add("@nBedBooked", "1")
            cmd.Parameters.Add("@sMode", "UpdateStatus")
            cmd.ExecuteNonQuery()
            con.Close()
            Response.Redirect("PMS-Staff-Patient-Visit-Details.aspx")
        Else
            lblErrorMsg.Text = "Patient Visit cannot be added successfully."
        End If
    End Sub

    Private Sub dllPatientType_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles dllPatientType.SelectedIndexChanged
        If dllPatientType.SelectedValue = 0 Then
            dllBed.Enabled = False
        Else
            dllBed.Enabled = True
        End If
    End Sub
End Class

Imports System.Data.SqlClient
Public Class _default
    Inherits System.Web.UI.Page

#Region " Web Form Designer Generated Code "

    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

    End Sub
    Protected WithEvents Label4 As System.Web.UI.WebControls.Label
    Protected WithEvents Label5 As System.Web.UI.WebControls.Label
    Protected WithEvents Label7 As System.Web.UI.WebControls.Label
    Protected WithEvents Table1 As System.Web.UI.HtmlControls.HtmlTable
    Protected WithEvents btnLogin As System.Web.UI.WebControls.Button
    Protected WithEvents txtPassword As System.Web.UI.WebControls.TextBox
    Protected WithEvents Label2 As System.Web.UI.WebControls.Label
    Protected WithEvents txtUserName As System.Web.UI.WebControls.TextBox
    Protected WithEvents Label1 As System.Web.UI.WebControls.Label
    Protected WithEvents lblErrorMsg As System.Web.UI.WebControls.Label
    Protected WithEvents Label3 As System.Web.UI.WebControls.Label
    Protected WithEvents tblAdministrator As System.Web.UI.HtmlControls.HtmlTable
    Protected WithEvents lblErrorMsg1 As System.Web.UI.WebControls.Label
    Protected WithEvents btnDoctorsLogin As System.Web.UI.WebControls.Button
    Protected WithEvents txtDUsername As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtDPassword As System.Web.UI.WebControls.TextBox
    Protected WithEvents btnView As System.Web.UI.WebControls.Button
    Protected WithEvents txtPatientID As System.Web.UI.WebControls.TextBox
    Protected WithEvents Label6 As System.Web.UI.WebControls.Label
    Protected WithEvents DLPatientHistory As System.Web.UI.WebControls.DataList
    Protected WithEvents lblError As System.Web.UI.WebControls.Label

    'NOTE: The following placeholder declaration is required by the Web Form Designer.
    'Do not delete or move it.
    Private designerPlaceholderDeclaration As System.Object

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: This method call is required by the Web Form Designer
        'Do not modify it using the code editor.
        InitializeComponent()
    End Sub

#End Region
#Region "ConnectionStrings Variables"
    Dim con As New SqlConnection(ConfigurationSettings.AppSettings("PMSconstr"))
    Dim cmd As New SqlCommand
    Dim dr As SqlDataReader
    Dim da As New SqlDataAdapter
    Dim ds As New DataSet
#End Region
    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        btnLogin.Attributes.Add("onclick", "javascript: return ValidateForm();")
        btnDoctorsLogin.Attributes.Add("onclick", "javascript: return ValidateFormDoctors();")
    End Sub

    Private Sub btnLogin_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnLogin.Click
        Dim chkFlag As Integer

        con.Open()
        cmd = New SqlCommand("PMS_Admin_Login_Details_Proc", con)
        cmd.CommandType = CommandType.StoredProcedure
        cmd.Parameters.Add("@sMode", "ChkLogin")
        cmd.Parameters.Add("@strUsername", txtUserName.Text)
        cmd.Parameters.Add("@strPassword", txtPassword.Text)
        dr = cmd.ExecuteReader
        If dr.HasRows Then
            chkFlag = 1
            While dr.Read
                Session("AdminID") = dr("nAdminID")
                Session("strUsername") = dr("strUsername")
                Session("AdminType") = dr("strAdminType")
            End While
        Else
            chkFlag = 0
        End If
        con.Close()
        If chkFlag = 0 Then
            lblErrorMsg.Text = "Login Failed. Please Try Again."
        Else
            If Session("AdminType") = "Admin" Then
                Response.Redirect("Admin/PMS-Admin-Home.aspx")
            ElseIf Session("AdminType") = "Staff" Then
                Response.Redirect("Staff/PMS-Staff-Home.aspx")
            End If

        End If
    End Sub

    Private Sub btnDoctorsLogin_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnDoctorsLogin.Click
        Dim chkFlag As Integer
        con.Open()
        cmd = New SqlCommand("PMS_Doctors_Details_Proc", con)
        cmd.CommandType = CommandType.StoredProcedure
        cmd.Parameters.Add("@sMode", "ChkLogin")
        cmd.Parameters.Add("@strDoctorsUsername", txtDUsername.Text)
        cmd.Parameters.Add("@strDoctorsPassword", txtDPassword.Text)
        dr = cmd.ExecuteReader
        If dr.HasRows Then
            chkFlag = 1
            While dr.Read
                Session("DoctorID") = dr("nDoctorsID")
                Session("strDoctorName") = dr("strDoctorsName")
            End While
        Else
            chkFlag = 0
        End If
        con.Close()
        If chkFlag = 0 Then
            lblErrorMsg1.Text = "Login Failed. Please Try Again."
        Else
            Response.Redirect("Doctors/PMS-Doctors-Home.aspx")
        End If
    End Sub

    Private Sub btnView_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnView.Click
        BindDataGrid()
    End Sub
    Sub BindDataGrid()
        con.Open()
        cmd = New SqlCommand("PMS_Patient_Visit_Details_Proc", con)
        cmd.CommandType = CommandType.StoredProcedure
        cmd.Parameters.Add("@sMode", "ViewByPatient")
        cmd.Parameters.Add("@nPatientID", Trim(txtPatientID.Text))
        da.SelectCommand = cmd
        da.Fill(ds, "Patient_Visit_Tbl")
        con.Close()
        DLPatientHistory.DataSource = ds.Tables("Patient_Visit_Tbl")
        DLPatientHistory.DataBind()
        If ds.Tables("Patient_Visit_Tbl").Rows.Count = 0 Then
            lblError.Text = "No Medical History Found"
        Else
            lblError.Text = ""
        End If
        
    End Sub

    Function getDoctorName(ByVal DoctorID As Integer)
        Dim strDoctorName As String
        con.Open()
        cmd = New SqlCommand("PMS_Doctors_Details_Proc", con)
        cmd.CommandType = CommandType.StoredProcedure
        cmd.Parameters.Add("@nDoctorsID", DoctorID)
        cmd.Parameters.Add("@sMode", "ViewByID")
        dr = cmd.ExecuteReader()
        While dr.Read
            strDoctorName = dr("strDoctorsName")
        End While
        con.Close()
        Return strDoctorName
    End Function
End Class

Title: Product Supplier Management System
Description: This system will teach you how to: Populate the DataSet programmatically instead of with a wizard, Using stored procedures, fill a DataSet with complete tables from the database and then create relationships between the tables, Write the business logic to dynamically build a SQL statement to fulfill the user's criteria given on the Search Screen, Fill a DataSet with the results of the SQL query, Verify in the Output window that the data in the DataSet correctly reflects the user criteria entered on the Search Screen, Simple and complex data binding, Building the Add/View/Edit Products and Suppliers Screens, Using the ErrorProvider control to validate user input, Using DataViews to filter and sort data in the DataSet, Using the DataReader to return a single record, Updating a DataSet based on user input, Allowing the user to add, edit, and delete data in the DataSet on the Add/Edit/View, Products and Suppliers screens, Creating a second dataset that contains all changes made by invoking the GetChanges method,
Checking for errors in the changed dataset by checking the HasErrors property, 
Saving the changes in the DataSet back to the database using Stored Procedures,
Accepting or rejecting the changes made based on whether the updates were successful and Handling any errors that occur. Using Northwind SQL database
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=2048&lngWId=10

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.

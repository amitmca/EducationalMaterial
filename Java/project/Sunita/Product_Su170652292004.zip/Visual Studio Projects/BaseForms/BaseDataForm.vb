Public Class BaseDataForm
    Inherits System.Windows.Forms.Form

    Protected Const PROD = "Products"
    Protected Const SUPP = "Supplier"
    Protected Const CONN = "Data Source=localhost;" & _
    "Initial Catalog=NorthWind;User Id=sa;Password=;"
   
    Protected dsSearchResults As DataSet
    Protected dsCodeTables As DataSet
    Protected intCurrentRec As Integer
    Protected myBindingManagerBase As BindingManagerBase
#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Protected WithEvents txtField1 As System.Windows.Forms.TextBox
    Protected WithEvents txtField2 As System.Windows.Forms.TextBox
    Protected WithEvents txtField3 As System.Windows.Forms.TextBox
    Protected WithEvents txtField4 As System.Windows.Forms.TextBox
    Protected WithEvents txtField5 As System.Windows.Forms.TextBox
    Protected WithEvents txtField6 As System.Windows.Forms.TextBox
    Protected WithEvents txtField7 As System.Windows.Forms.TextBox
    Protected WithEvents txtField8 As System.Windows.Forms.TextBox
    Protected WithEvents txtField9 As System.Windows.Forms.TextBox
    Protected WithEvents txtField10 As System.Windows.Forms.TextBox
    Protected WithEvents txtField11 As System.Windows.Forms.TextBox
    Protected WithEvents txtField12 As System.Windows.Forms.TextBox
    Protected WithEvents btnPrevious As System.Windows.Forms.Button
    Protected WithEvents btnNext As System.Windows.Forms.Button
    Protected WithEvents btnAdd As System.Windows.Forms.Button
    Protected WithEvents btnDelete As System.Windows.Forms.Button
    Protected WithEvents btnSave As System.Windows.Forms.Button
    Protected WithEvents lblField1 As System.Windows.Forms.Label
    Protected WithEvents lblField2 As System.Windows.Forms.Label
    Protected WithEvents lblField3 As System.Windows.Forms.Label
    Protected WithEvents lblField4 As System.Windows.Forms.Label
    Protected WithEvents lblField5 As System.Windows.Forms.Label
    Protected WithEvents lblField6 As System.Windows.Forms.Label
    Protected WithEvents lblField7 As System.Windows.Forms.Label
    Protected WithEvents lblField8 As System.Windows.Forms.Label
    Protected WithEvents lblField9 As System.Windows.Forms.Label
    Protected WithEvents lblField10 As System.Windows.Forms.Label
    Protected WithEvents lblField11 As System.Windows.Forms.Label
    Protected WithEvents lblField12 As System.Windows.Forms.Label
    Protected WithEvents ErrorProvider1 As System.Windows.Forms.ErrorProvider
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.lblField1 = New System.Windows.Forms.Label()
        Me.lblField2 = New System.Windows.Forms.Label()
        Me.lblField3 = New System.Windows.Forms.Label()
        Me.lblField4 = New System.Windows.Forms.Label()
        Me.lblField5 = New System.Windows.Forms.Label()
        Me.lblField6 = New System.Windows.Forms.Label()
        Me.lblField7 = New System.Windows.Forms.Label()
        Me.lblField8 = New System.Windows.Forms.Label()
        Me.lblField9 = New System.Windows.Forms.Label()
        Me.lblField10 = New System.Windows.Forms.Label()
        Me.lblField11 = New System.Windows.Forms.Label()
        Me.lblField12 = New System.Windows.Forms.Label()
        Me.txtField1 = New System.Windows.Forms.TextBox()
        Me.txtField2 = New System.Windows.Forms.TextBox()
        Me.txtField3 = New System.Windows.Forms.TextBox()
        Me.txtField4 = New System.Windows.Forms.TextBox()
        Me.txtField5 = New System.Windows.Forms.TextBox()
        Me.txtField6 = New System.Windows.Forms.TextBox()
        Me.txtField7 = New System.Windows.Forms.TextBox()
        Me.txtField8 = New System.Windows.Forms.TextBox()
        Me.txtField9 = New System.Windows.Forms.TextBox()
        Me.txtField10 = New System.Windows.Forms.TextBox()
        Me.txtField11 = New System.Windows.Forms.TextBox()
        Me.txtField12 = New System.Windows.Forms.TextBox()
        Me.btnPrevious = New System.Windows.Forms.Button()
        Me.btnNext = New System.Windows.Forms.Button()
        Me.btnAdd = New System.Windows.Forms.Button()
        Me.btnDelete = New System.Windows.Forms.Button()
        Me.btnSave = New System.Windows.Forms.Button()
        Me.ErrorProvider1 = New System.Windows.Forms.ErrorProvider()
        Me.SuspendLayout()
        '
        'lblField1
        '
        Me.lblField1.Location = New System.Drawing.Point(32, 32)
        Me.lblField1.Name = "lblField1"
        Me.lblField1.TabIndex = 0
        '
        'lblField2
        '
        Me.lblField2.Location = New System.Drawing.Point(32, 64)
        Me.lblField2.Name = "lblField2"
        Me.lblField2.TabIndex = 1
        '
        'lblField3
        '
        Me.lblField3.Location = New System.Drawing.Point(32, 96)
        Me.lblField3.Name = "lblField3"
        Me.lblField3.TabIndex = 2
        '
        'lblField4
        '
        Me.lblField4.Location = New System.Drawing.Point(32, 128)
        Me.lblField4.Name = "lblField4"
        Me.lblField4.TabIndex = 3
        '
        'lblField5
        '
        Me.lblField5.Location = New System.Drawing.Point(32, 160)
        Me.lblField5.Name = "lblField5"
        Me.lblField5.TabIndex = 4
        '
        'lblField6
        '
        Me.lblField6.Location = New System.Drawing.Point(32, 192)
        Me.lblField6.Name = "lblField6"
        Me.lblField6.TabIndex = 5
        '
        'lblField7
        '
        Me.lblField7.Location = New System.Drawing.Point(32, 224)
        Me.lblField7.Name = "lblField7"
        Me.lblField7.TabIndex = 6
        '
        'lblField8
        '
        Me.lblField8.Location = New System.Drawing.Point(32, 256)
        Me.lblField8.Name = "lblField8"
        Me.lblField8.TabIndex = 7
        '
        'lblField9
        '
        Me.lblField9.Location = New System.Drawing.Point(40, 288)
        Me.lblField9.Name = "lblField9"
        Me.lblField9.TabIndex = 8
        '
        'lblField10
        '
        Me.lblField10.Location = New System.Drawing.Point(32, 320)
        Me.lblField10.Name = "lblField10"
        Me.lblField10.TabIndex = 9
        '
        'lblField11
        '
        Me.lblField11.Location = New System.Drawing.Point(32, 352)
        Me.lblField11.Name = "lblField11"
        Me.lblField11.TabIndex = 10
        '
        'lblField12
        '
        Me.lblField12.Location = New System.Drawing.Point(32, 384)
        Me.lblField12.Name = "lblField12"
        Me.lblField12.TabIndex = 11
        '
        'txtField1
        '
        Me.txtField1.Location = New System.Drawing.Point(144, 32)
        Me.txtField1.Name = "txtField1"
        Me.txtField1.Size = New System.Drawing.Size(256, 20)
        Me.txtField1.TabIndex = 0
        Me.txtField1.Text = ""
        '
        'txtField2
        '
        Me.txtField2.Location = New System.Drawing.Point(144, 64)
        Me.txtField2.Name = "txtField2"
        Me.txtField2.Size = New System.Drawing.Size(440, 20)
        Me.txtField2.TabIndex = 1
        Me.txtField2.Text = ""
        '
        'txtField3
        '
        Me.txtField3.Location = New System.Drawing.Point(144, 96)
        Me.txtField3.Name = "txtField3"
        Me.txtField3.Size = New System.Drawing.Size(256, 20)
        Me.txtField3.TabIndex = 2
        Me.txtField3.Text = ""
        '
        'txtField4
        '
        Me.txtField4.Location = New System.Drawing.Point(144, 128)
        Me.txtField4.Name = "txtField4"
        Me.txtField4.Size = New System.Drawing.Size(256, 20)
        Me.txtField4.TabIndex = 3
        Me.txtField4.Text = ""
        '
        'txtField5
        '
        Me.txtField5.Location = New System.Drawing.Point(144, 160)
        Me.txtField5.Name = "txtField5"
        Me.txtField5.Size = New System.Drawing.Size(256, 20)
        Me.txtField5.TabIndex = 4
        Me.txtField5.Text = ""
        '
        'txtField6
        '
        Me.txtField6.Location = New System.Drawing.Point(144, 192)
        Me.txtField6.Name = "txtField6"
        Me.txtField6.Size = New System.Drawing.Size(256, 20)
        Me.txtField6.TabIndex = 5
        Me.txtField6.Text = ""
        '
        'txtField7
        '
        Me.txtField7.Location = New System.Drawing.Point(144, 224)
        Me.txtField7.Name = "txtField7"
        Me.txtField7.Size = New System.Drawing.Size(256, 20)
        Me.txtField7.TabIndex = 6
        Me.txtField7.Text = ""
        '
        'txtField8
        '
        Me.txtField8.Location = New System.Drawing.Point(144, 256)
        Me.txtField8.Name = "txtField8"
        Me.txtField8.Size = New System.Drawing.Size(256, 20)
        Me.txtField8.TabIndex = 7
        Me.txtField8.Text = ""
        '
        'txtField9
        '
        Me.txtField9.Location = New System.Drawing.Point(144, 288)
        Me.txtField9.Name = "txtField9"
        Me.txtField9.Size = New System.Drawing.Size(256, 20)
        Me.txtField9.TabIndex = 8
        Me.txtField9.Text = ""
        '
        'txtField10
        '
        Me.txtField10.Location = New System.Drawing.Point(144, 320)
        Me.txtField10.Name = "txtField10"
        Me.txtField10.Size = New System.Drawing.Size(256, 20)
        Me.txtField10.TabIndex = 9
        Me.txtField10.Text = ""
        '
        'txtField11
        '
        Me.txtField11.Location = New System.Drawing.Point(144, 352)
        Me.txtField11.Name = "txtField11"
        Me.txtField11.Size = New System.Drawing.Size(256, 20)
        Me.txtField11.TabIndex = 10
        Me.txtField11.Text = ""
        '
        'txtField12
        '
        Me.txtField12.Location = New System.Drawing.Point(144, 384)
        Me.txtField12.Name = "txtField12"
        Me.txtField12.Size = New System.Drawing.Size(256, 20)
        Me.txtField12.TabIndex = 11
        Me.txtField12.Text = ""
        '
        'btnPrevious
        '
        Me.btnPrevious.Location = New System.Drawing.Point(24, 432)
        Me.btnPrevious.Name = "btnPrevious"
        Me.btnPrevious.Size = New System.Drawing.Size(112, 23)
        Me.btnPrevious.TabIndex = 12
        Me.btnPrevious.Text = "Previous"
        '
        'btnNext
        '
        Me.btnNext.Location = New System.Drawing.Point(144, 432)
        Me.btnNext.Name = "btnNext"
        Me.btnNext.Size = New System.Drawing.Size(112, 23)
        Me.btnNext.TabIndex = 13
        Me.btnNext.Text = "Next"
        '
        'btnAdd
        '
        Me.btnAdd.Location = New System.Drawing.Point(264, 432)
        Me.btnAdd.Name = "btnAdd"
        Me.btnAdd.Size = New System.Drawing.Size(112, 23)
        Me.btnAdd.TabIndex = 14
        Me.btnAdd.Text = "Add"
        '
        'btnDelete
        '
        Me.btnDelete.Location = New System.Drawing.Point(384, 432)
        Me.btnDelete.Name = "btnDelete"
        Me.btnDelete.Size = New System.Drawing.Size(112, 23)
        Me.btnDelete.TabIndex = 15
        Me.btnDelete.Text = "Delete"
        '
        'btnSave
        '
        Me.btnSave.Location = New System.Drawing.Point(512, 432)
        Me.btnSave.Name = "btnSave"
        Me.btnSave.Size = New System.Drawing.Size(112, 23)
        Me.btnSave.TabIndex = 16
        Me.btnSave.Text = "Save All"
        '
        'BaseDataForm
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(640, 477)
        Me.Controls.AddRange(New System.Windows.Forms.Control() {Me.btnSave, Me.btnDelete, Me.btnAdd, Me.btnNext, Me.btnPrevious, Me.txtField12, Me.txtField11, Me.txtField10, Me.txtField9, Me.txtField8, Me.txtField7, Me.txtField6, Me.txtField5, Me.txtField4, Me.txtField3, Me.txtField2, Me.txtField1, Me.lblField12, Me.lblField11, Me.lblField10, Me.lblField9, Me.lblField8, Me.lblField7, Me.lblField6, Me.lblField5, Me.lblField4, Me.lblField3, Me.lblField2, Me.lblField1})
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "BaseDataForm"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "BaseDataForm"
        Me.ResumeLayout(False)

    End Sub

#End Region

    Public Sub UnhandledExceptionHandler()
        MsgBox("An error occured. Error Number: " & Err.Number & _
        " Description: " & Err.Description)

    End Sub

    Sub AssignDataSet(ByVal dsResults As DataSet, ByVal dsData As DataSet, _
    ByVal intCurrRow As Integer)
        Try
            'Assign the data sets and current row values passed into the
            'local variables.
            dsSearchResults = dsResults
            dsCodeTables = dsData
            intCurrentRec = intCurrRow
        Catch
            'Handle errors.
            UnhandledExceptionHandler()
        End Try
    End Sub
    Sub MoveNext()
        Try
            'Increment the Position property value by one.
            myBindingManagerBase.Position += 1
        Catch
            'Handle errors.
            UnhandledExceptionHandler()
        End Try
    End Sub
    Sub MovePrevious()
        Try
            'Decrement the Position property value by one.
            myBindingManagerBase.Position -= 1
        Catch
            'Handle errors.
            UnhandledExceptionHandler()
      
        End Try
    End Sub
    Sub MoveFirst()
        Try
            'Go to the first item in the list.
            myBindingManagerBase.Position = 0
        Catch
            'Handle errors.
            UnhandledExceptionHandler()
        End Try
    End Sub
    Sub MoveLast()
        Try
            'Go to the last row in the list.
            myBindingManagerBase.Position = myBindingManagerBase.Count - 1
        Catch
            'Handle errors.
            UnhandledExceptionHandler()
        End Try
    End Sub
    Private Sub btnNext_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnNext.Click
        Try
            'Run the MoveNext procedure to move to the next record.
            MoveNext()
        Catch
            'Handle errors.
            UnhandledExceptionHandler()
        End Try
    End Sub
    Private Sub btnPrevious_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnPrevious.Click
        Try
            MovePrevious()
        Catch
            'Handle errors.
            UnhandledExceptionHandler()
        End Try
    End Sub

    Sub ReplaceControl(ByVal ctlControl1 As Control, ByVal ctlControl2 As _
    Control)
        'The purpose of this procedure is to replace one control at the
        'location of another control. Control 2 is the new control that you
        'want to replace Control 1. This is useful in instances such as
        'visual inheritance where you have a base form and need to slightly
        'customize it for only a few fields.
        Try
            Dim ptLocation As Point
            Dim szSize As Size
            'Place Control 2 in the exact location where Control 1 exists.
            ptLocation = ctlControl1.Location
            szSize = ctlControl1.Size
            ctlControl2.Location = ptLocation
            ctlControl2.Size = szSize
            ctlControl2.TabIndex = ctlControl1.TabIndex
            'Disable Control 1 since it is being replaced by Control 2.
            EnableDisable(ctlControl1, False)
        Catch
            'Handle errors.
            UnhandledExceptionHandler()
        End Try
    End Sub

    Sub EnableDisable(ByVal ctlControl As Control, ByVal blnEnable As _
    Boolean)
        Try
            'Hide/disable fields or enable/make them visible based on
            'the parameters passed in.
            If blnEnable Then
                ctlControl.Visible = True
                ctlControl.Enabled = True
            Else
                ctlControl.Visible = False
                ctlControl.Enabled = False
            End If
        Catch
            'Handle errors.
            UnhandledExceptionHandler()
        End Try
    End Sub
    Sub ValidateNumeric(ByVal ctlControl As Control)
        Try

            ErrorProvider1.SetError(ctlControl, "")

        Catch
            'Handle errors.
            UnhandledExceptionHandler()
        End Try
    End Sub
    Sub ValidateNotBlank(ByVal ctlControl As Control)
        Try
            If ctlControl.Text = "" Then
                'Set the error.
                ErrorProvider1.SetError(ctlControl, _
                "Please enter a value for this required field.")
            Else
                'Clear the error.
                ErrorProvider1.SetError(ctlControl, "")
            End If
        Catch
            'Handle errors.
            UnhandledExceptionHandler()
        End Try
    End Sub

    Private Sub txtProductName_Validating(ByVal sender As Object, ByVal e _
    As System.ComponentModel.CancelEventArgs) Handles _
    txtField2.Validating
        Try
            ValidateNotBlank(txtField2)
        Catch
            'Error handling goes here.
            UnhandledExceptionHandler()
        End Try
    End Sub


    Private Sub txtUnitPrice_Validating(ByVal sender As Object, ByVal e As _
    System.ComponentModel.CancelEventArgs) Handles _
    txtField6.Validating
        Try
            ValidateNumeric(txtField6)
        Catch
            'Error handling goes here.
            UnhandledExceptionHandler()
        End Try
    End Sub


    Private Sub txtUnitsInStock_Validating(ByVal sender As Object, ByVal e _
    As System.ComponentModel.CancelEventArgs) Handles _
    txtField7.Validating
        Try
            ValidateNumeric(txtField7)
        Catch
            'Error handling goes here.
            UnhandledExceptionHandler()
        End Try
    End Sub

    Private Sub txtUnitsOnOrder_Validating(ByVal sender As Object, ByVal _
    e As System.ComponentModel.CancelEventArgs) Handles _
    txtField8.Validating
        Try
            ValidateNumeric(txtField8)
        Catch
            'Error handling goes here.
            UnhandledExceptionHandler()
        End Try
    End Sub

    Private Sub txtReorderLevel_Validating(ByVal sender As Object, ByVal _
    e As System.ComponentModel.CancelEventArgs) Handles _
    txtField9.Validating
        Try
            ValidateNumeric(txtField9)
        Catch
            'Error handling goes here.
            UnhandledExceptionHandler()
        End Try
    End Sub

    Private Sub txtCompanyName_Validating(ByVal sender As Object, ByVal e _
    As System.ComponentModel.CancelEventArgs) Handles _
    txtField2.Validating
        Try
            ValidateNotBlank(txtField2)
        Catch
            'Error handling goes here.
            UnhandledExceptionHandler()
        End Try
    End Sub
End Class

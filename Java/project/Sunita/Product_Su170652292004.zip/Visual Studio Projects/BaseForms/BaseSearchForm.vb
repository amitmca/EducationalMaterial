Public Class BaseSearchForm
    Inherits System.Windows.Forms.Form
    Protected Const PROD = "Products"
    Protected Const SUPP = "Supplier"
    Protected Const CONN = "Data Source=localhost;" & _
    "Initial Catalog=NorthWind;User Id=sa;Password=;"
    '"user id=sa;password=;initial " & _
    '"catalog=NorthWind;Server=AUBREY"

    Protected dsData As DataSet
    Protected dsResult As DataSet
    Protected adapterResults As New SqlClient.SqlDataAdapter()


#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents lblSearchMethod As System.Windows.Forms.Label
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Protected WithEvents cboSearchMethod As System.Windows.Forms.ComboBox
    Protected WithEvents txtCriteria1 As System.Windows.Forms.TextBox
    Protected WithEvents txtCriteria2 As System.Windows.Forms.TextBox
    Protected WithEvents txtCriteria3 As System.Windows.Forms.TextBox
    Protected WithEvents txtCriteria4 As System.Windows.Forms.TextBox
    Protected WithEvents txtCriteria5 As System.Windows.Forms.TextBox
    Protected WithEvents txtCriteria6 As System.Windows.Forms.TextBox
    Protected WithEvents btnSearch As System.Windows.Forms.Button
    Protected WithEvents lblCriteria1 As System.Windows.Forms.Label
    Protected WithEvents lblCriteria3 As System.Windows.Forms.Label
    Protected WithEvents lblCriteria4 As System.Windows.Forms.Label
    Protected WithEvents lblCriteria5 As System.Windows.Forms.Label
    Protected WithEvents lblCriteria6 As System.Windows.Forms.Label
    Protected WithEvents cboCriteria6 As System.Windows.Forms.ComboBox
    Protected WithEvents cboCriteria5 As System.Windows.Forms.ComboBox
    Protected WithEvents cboCriteria4 As System.Windows.Forms.ComboBox
    Protected WithEvents cboCriteria3 As System.Windows.Forms.ComboBox
    Protected WithEvents cboCriteria2 As System.Windows.Forms.ComboBox
    Protected WithEvents cboCriteria1 As System.Windows.Forms.ComboBox
    Protected WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Protected WithEvents btnClear As System.Windows.Forms.Button
    Public WithEvents lblCriteria2 As System.Windows.Forms.Label
    Protected WithEvents dgdResults As System.Windows.Forms.DataGrid
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.lblSearchMethod = New System.Windows.Forms.Label()
        Me.cboSearchMethod = New System.Windows.Forms.ComboBox()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.txtCriteria6 = New System.Windows.Forms.TextBox()
        Me.txtCriteria5 = New System.Windows.Forms.TextBox()
        Me.txtCriteria4 = New System.Windows.Forms.TextBox()
        Me.txtCriteria3 = New System.Windows.Forms.TextBox()
        Me.txtCriteria2 = New System.Windows.Forms.TextBox()
        Me.txtCriteria1 = New System.Windows.Forms.TextBox()
        Me.cboCriteria6 = New System.Windows.Forms.ComboBox()
        Me.cboCriteria5 = New System.Windows.Forms.ComboBox()
        Me.cboCriteria4 = New System.Windows.Forms.ComboBox()
        Me.cboCriteria3 = New System.Windows.Forms.ComboBox()
        Me.cboCriteria2 = New System.Windows.Forms.ComboBox()
        Me.cboCriteria1 = New System.Windows.Forms.ComboBox()
        Me.lblCriteria6 = New System.Windows.Forms.Label()
        Me.lblCriteria5 = New System.Windows.Forms.Label()
        Me.lblCriteria4 = New System.Windows.Forms.Label()
        Me.lblCriteria3 = New System.Windows.Forms.Label()
        Me.lblCriteria2 = New System.Windows.Forms.Label()
        Me.lblCriteria1 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.btnClear = New System.Windows.Forms.Button()
        Me.btnSearch = New System.Windows.Forms.Button()
        Me.dgdResults = New System.Windows.Forms.DataGrid()
        Me.GroupBox1.SuspendLayout()
        CType(Me.dgdResults, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'lblSearchMethod
        '
        Me.lblSearchMethod.Location = New System.Drawing.Point(32, 40)
        Me.lblSearchMethod.Name = "lblSearchMethod"
        Me.lblSearchMethod.Size = New System.Drawing.Size(248, 16)
        Me.lblSearchMethod.TabIndex = 0
        Me.lblSearchMethod.Text = "Please Choose  what you would like to search for"
        '
        'cboSearchMethod
        '
        Me.cboSearchMethod.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboSearchMethod.Location = New System.Drawing.Point(296, 32)
        Me.cboSearchMethod.Name = "cboSearchMethod"
        Me.cboSearchMethod.Size = New System.Drawing.Size(336, 21)
        Me.cboSearchMethod.TabIndex = 1
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.AddRange(New System.Windows.Forms.Control() {Me.txtCriteria6, Me.txtCriteria5, Me.txtCriteria4, Me.txtCriteria3, Me.txtCriteria2, Me.txtCriteria1, Me.cboCriteria6, Me.cboCriteria5, Me.cboCriteria4, Me.cboCriteria3, Me.cboCriteria2, Me.cboCriteria1, Me.lblCriteria6, Me.lblCriteria5, Me.lblCriteria4, Me.lblCriteria3, Me.lblCriteria2, Me.lblCriteria1, Me.Label1})
        Me.GroupBox1.Location = New System.Drawing.Point(32, 80)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(672, 208)
        Me.GroupBox1.TabIndex = 2
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Serch Criteria"
        '
        'txtCriteria6
        '
        Me.txtCriteria6.Location = New System.Drawing.Point(384, 176)
        Me.txtCriteria6.Name = "txtCriteria6"
        Me.txtCriteria6.Size = New System.Drawing.Size(216, 20)
        Me.txtCriteria6.TabIndex = 18
        Me.txtCriteria6.Text = ""
        '
        'txtCriteria5
        '
        Me.txtCriteria5.Location = New System.Drawing.Point(384, 152)
        Me.txtCriteria5.Name = "txtCriteria5"
        Me.txtCriteria5.Size = New System.Drawing.Size(216, 20)
        Me.txtCriteria5.TabIndex = 15
        Me.txtCriteria5.Text = ""
        '
        'txtCriteria4
        '
        Me.txtCriteria4.Location = New System.Drawing.Point(384, 128)
        Me.txtCriteria4.Name = "txtCriteria4"
        Me.txtCriteria4.Size = New System.Drawing.Size(216, 20)
        Me.txtCriteria4.TabIndex = 12
        Me.txtCriteria4.Text = ""
        '
        'txtCriteria3
        '
        Me.txtCriteria3.Location = New System.Drawing.Point(384, 104)
        Me.txtCriteria3.Name = "txtCriteria3"
        Me.txtCriteria3.Size = New System.Drawing.Size(216, 20)
        Me.txtCriteria3.TabIndex = 9
        Me.txtCriteria3.Text = ""
        '
        'txtCriteria2
        '
        Me.txtCriteria2.Location = New System.Drawing.Point(384, 80)
        Me.txtCriteria2.Name = "txtCriteria2"
        Me.txtCriteria2.Size = New System.Drawing.Size(216, 20)
        Me.txtCriteria2.TabIndex = 6
        Me.txtCriteria2.Text = ""
        '
        'txtCriteria1
        '
        Me.txtCriteria1.Location = New System.Drawing.Point(384, 56)
        Me.txtCriteria1.Name = "txtCriteria1"
        Me.txtCriteria1.Size = New System.Drawing.Size(216, 20)
        Me.txtCriteria1.TabIndex = 3
        Me.txtCriteria1.Text = ""
        '
        'cboCriteria6
        '
        Me.cboCriteria6.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboCriteria6.Location = New System.Drawing.Point(200, 176)
        Me.cboCriteria6.Name = "cboCriteria6"
        Me.cboCriteria6.Size = New System.Drawing.Size(176, 21)
        Me.cboCriteria6.TabIndex = 17
        '
        'cboCriteria5
        '
        Me.cboCriteria5.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboCriteria5.Location = New System.Drawing.Point(200, 152)
        Me.cboCriteria5.Name = "cboCriteria5"
        Me.cboCriteria5.Size = New System.Drawing.Size(176, 21)
        Me.cboCriteria5.TabIndex = 14
        '
        'cboCriteria4
        '
        Me.cboCriteria4.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboCriteria4.Location = New System.Drawing.Point(200, 128)
        Me.cboCriteria4.Name = "cboCriteria4"
        Me.cboCriteria4.Size = New System.Drawing.Size(176, 21)
        Me.cboCriteria4.TabIndex = 11
        '
        'cboCriteria3
        '
        Me.cboCriteria3.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboCriteria3.Location = New System.Drawing.Point(200, 104)
        Me.cboCriteria3.Name = "cboCriteria3"
        Me.cboCriteria3.Size = New System.Drawing.Size(176, 21)
        Me.cboCriteria3.TabIndex = 8
        '
        'cboCriteria2
        '
        Me.cboCriteria2.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboCriteria2.Location = New System.Drawing.Point(200, 80)
        Me.cboCriteria2.Name = "cboCriteria2"
        Me.cboCriteria2.Size = New System.Drawing.Size(176, 21)
        Me.cboCriteria2.TabIndex = 5
        '
        'cboCriteria1
        '
        Me.cboCriteria1.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboCriteria1.Location = New System.Drawing.Point(200, 56)
        Me.cboCriteria1.Name = "cboCriteria1"
        Me.cboCriteria1.Size = New System.Drawing.Size(176, 21)
        Me.cboCriteria1.TabIndex = 2
        '
        'lblCriteria6
        '
        Me.lblCriteria6.Location = New System.Drawing.Point(16, 176)
        Me.lblCriteria6.Name = "lblCriteria6"
        Me.lblCriteria6.Size = New System.Drawing.Size(176, 16)
        Me.lblCriteria6.TabIndex = 16
        '
        'lblCriteria5
        '
        Me.lblCriteria5.Location = New System.Drawing.Point(16, 152)
        Me.lblCriteria5.Name = "lblCriteria5"
        Me.lblCriteria5.Size = New System.Drawing.Size(176, 16)
        Me.lblCriteria5.TabIndex = 13
        '
        'lblCriteria4
        '
        Me.lblCriteria4.Location = New System.Drawing.Point(16, 128)
        Me.lblCriteria4.Name = "lblCriteria4"
        Me.lblCriteria4.Size = New System.Drawing.Size(176, 16)
        Me.lblCriteria4.TabIndex = 10
        '
        'lblCriteria3
        '
        Me.lblCriteria3.Location = New System.Drawing.Point(16, 104)
        Me.lblCriteria3.Name = "lblCriteria3"
        Me.lblCriteria3.Size = New System.Drawing.Size(176, 16)
        Me.lblCriteria3.TabIndex = 7
        '
        'lblCriteria2
        '
        Me.lblCriteria2.Location = New System.Drawing.Point(16, 80)
        Me.lblCriteria2.Name = "lblCriteria2"
        Me.lblCriteria2.Size = New System.Drawing.Size(176, 16)
        Me.lblCriteria2.TabIndex = 4
        '
        'lblCriteria1
        '
        Me.lblCriteria1.Location = New System.Drawing.Point(16, 56)
        Me.lblCriteria1.Name = "lblCriteria1"
        Me.lblCriteria1.Size = New System.Drawing.Size(176, 16)
        Me.lblCriteria1.TabIndex = 1
        '
        'Label1
        '
        Me.Label1.Location = New System.Drawing.Point(16, 32)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(240, 16)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Please specify one or more criteria"
        '
        'btnClear
        '
        Me.btnClear.Location = New System.Drawing.Point(424, 312)
        Me.btnClear.Name = "btnClear"
        Me.btnClear.TabIndex = 4
        Me.btnClear.Text = "Clear"
        '
        'btnSearch
        '
        Me.btnSearch.Location = New System.Drawing.Point(328, 312)
        Me.btnSearch.Name = "btnSearch"
        Me.btnSearch.TabIndex = 3
        Me.btnSearch.Text = "Search"
        '
        'dgdResults
        '
        Me.dgdResults.DataMember = ""
        Me.dgdResults.HeaderForeColor = System.Drawing.SystemColors.ControlText
        Me.dgdResults.Location = New System.Drawing.Point(40, 352)
        Me.dgdResults.Name = "dgdResults"
        Me.dgdResults.ReadOnly = True
        Me.dgdResults.Size = New System.Drawing.Size(664, 200)
        Me.dgdResults.TabIndex = 5
        '
        'BaseSearchForm
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(738, 573)
        Me.Controls.AddRange(New System.Windows.Forms.Control() {Me.cboSearchMethod, Me.dgdResults, Me.btnSearch, Me.btnClear, Me.GroupBox1, Me.lblSearchMethod})
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "BaseSearchForm"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Product / Supplier Search"
        Me.GroupBox1.ResumeLayout(False)
        CType(Me.dgdResults, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub

#End Region
    Public Sub UnhandledExceptionHandler()
        MsgBox("An error occured. Error Number: " & Err.Number & _
        " Description: " & Err.Description)

    End Sub
    Sub AddSearchMethod()
        Try
            If cboSearchMethod.Items.Count = 0 Then
                cboSearchMethod.Items.Add(PROD)
                cboSearchMethod.Items.Add(SUPP)
            End If
        Catch
            UnhandledExceptionHandler()
        End Try


    End Sub
    Sub AddCharDropDownCriteria(ByVal cboIn As ComboBox)
        Try
            cboIn.Items.Add("Equals")
            cboIn.Items.Add("Start With")
            cboIn.Items.Add("Ends With")
            cboIn.Items.Add("Contains")
        Catch
            UnhandledExceptionHandler()
        End Try

    End Sub
    Sub AddNumericDropDownCriteria(ByVal cboIn As ComboBox)
        Try
            cboIn.Items.Add("Equals")
            cboIn.Items.Add("Greater Than")
            cboIn.Items.Add("Less Than")

        Catch
            UnhandledExceptionHandler()
        End Try
    End Sub

    Private Sub btnClear_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnClear.Click
        Try
            txtCriteria1.Text = ""
            txtCriteria2.Text = ""
            txtCriteria3.Text = ""
            txtCriteria4.Text = ""
            txtCriteria5.Text = ""
            txtCriteria6.Text = ""
            dgdResults.DataSource = Nothing
            dsResult = Nothing
        Catch
            UnhandledExceptionHandler()
        End Try


    End Sub

    Delegate Function WhereClauseDelagate(ByVal strFieldName As String, _
                        ByVal strMatchCriteria As String, _
                        ByVal strFilterCriteria As String, _
                        ByVal blnPriorWhere As Boolean, _
                        ByVal strWhereCriteria As String, _
                        ByVal blnNumberField As Boolean) As String

    Sub CheckSearchCriteria(ByVal strMatchCriteria As String, ByVal _
                    strFilterCriteria As String, _
                    ByVal strFieldName As String, ByRef strWhereCriteria _
                    As String, ByRef blnPriorWhere As Boolean, ByVal _
                    blnNumberField As Boolean, ByVal buildWhere As WhereClauseDelagate)

        If strMatchCriteria <> "" And strFilterCriteria <> "" Then
            strWhereCriteria = buildWhere.Invoke _
            (strFieldName, strMatchCriteria, strFilterCriteria, _
                blnPriorWhere, strWhereCriteria, blnNumberField)
            blnPriorWhere = True
        End If

    End Sub

End Class

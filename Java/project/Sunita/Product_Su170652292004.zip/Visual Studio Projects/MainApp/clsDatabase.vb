Imports System.Data
Imports System.Data.SqlClient

Public Class clsDatabase
    Function PopulateDataSetTable(ByVal strConnection As String, ByVal _
                strTableName As String, ByVal strSQLorStoredProc As String, _
                ByVal blnStoredProcedure As Boolean, _
                ByRef dsDataSet As DataSet) As DataSet
        Try
            Dim sqlConn As New SqlClient.SqlConnection(strConnection)
            sqlConn.Open()

            Dim adapterProducts As New SqlClient.SqlDataAdapter()

            adapterProducts.TableMappings.Add("Table", strTableName)
            Dim cmdTable As SqlClient.SqlCommand = New _
                SqlClient.SqlCommand(strSQLorStoredProc, sqlConn)

            If blnStoredProcedure Then
                cmdTable.CommandType = CommandType.StoredProcedure
            Else
                cmdTable.CommandType = CommandType.Text
            End If
            adapterProducts.SelectCommand = cmdTable
            adapterProducts.Fill(dsDataSet)

            sqlConn.Close()
            Return dsDataSet
        Catch
            UnhandledExceptionHandler()
        End Try
    End Function

    Function PopulateDataSetRelation(ByVal strTable1 As String, _
            ByVal strTable2 As String, ByVal strColumTable1 As String, _
            ByVal strColumTable2 As String, ByVal strRelationshipName As String, ByRef dsDataSet As DataSet) As DataSet
        Try
            Dim drRelation As DataRelation
            Dim dcCol1 As DataColumn
            Dim dcCol2 As DataColumn

            dcCol1 = dsDataSet.Tables(strTable1).Columns(strColumTable1)
            dcCol2 = dsDataSet.Tables(strTable2).Columns(strColumTable2)
            drRelation = New System.Data.DataRelation(strRelationshipName, dcCol1, dcCol2)
            dsDataSet.Relations.Add(drRelation)

            Return dsDataSet
        Catch
            UnhandledExceptionHandler()
        End Try

    End Function

    Function LoadCompleteDataSet(ByVal strConnection As String) As DataSet
        Try
            Dim dsData As New DataSet()
            Dim blnRunStoredProc As Boolean = True
            dsData = PopulateDataSetTable(strConnection, "Products", "spRetrieveProducts", blnRunStoredProc, dsData)
            dsData = PopulateDataSetTable(strConnection, "Suppliers", "spRetrieveSuppliers", blnRunStoredProc, dsData)
            dsData = PopulateDataSetTable(strConnection, "Categories", "spRetrieveCategories", blnRunStoredProc, dsData)
            dsData = PopulateDataSetRelation("Suppliers", "Products", "SupplierId", "SupplierID", "ProductsVsSuppliers", dsData)
            dsData = PopulateDataSetRelation("Categories", "Products", "CategoryID", "CategoryID", "ProductsVsCategories", dsData)
            WriteCompleteDataSetToOutputWindow(dsData)
            Return dsData
        Catch
            UnhandledExceptionHandler()
        End Try
    End Function


    Sub UnhandledExceptionHandler()
        MsgBox("An error occured. Error Number: " & Err.Number & _
        " Description: " & Err.Description)

    End Sub

    Sub WriteCompleteDataSetToOutputWindow(ByVal dsData As DataSet)
        Try
            Dim oRow As DataRow
            Dim strRecord As String
            For Each oRow In dsData.Tables("Products").Rows
                strRecord = "Product Id:" & oRow("ProductID").ToString()
                strRecord = strRecord & " Product Name: "
                strRecord = strRecord & oRow("ProductName").ToString()
                strRecord = strRecord & " Supplier Id: "
                strRecord = strRecord & oRow("SupplierID").ToString()
                Console.WriteLine(strRecord)
            Next
            For Each oRow In dsData.Tables("Suppliers").Rows
                strRecord = "Product Id:" & oRow("SupplierID").ToString()
                strRecord = strRecord & " Comapany Name: "
                strRecord = strRecord & oRow("CompanyName").ToString()
                strRecord = strRecord & " Contact Name: "
                strRecord = strRecord & oRow("ContactName").ToString()
                Console.WriteLine(strRecord)
            Next
            For Each oRow In dsData.Tables("Categories").Rows
                strRecord = "Product Id:" & oRow("CategoryID").ToString()
                strRecord = strRecord & " Category Name: "
                strRecord = strRecord & oRow("CategoryName").ToString()
                strRecord = strRecord & " Description: "
                strRecord = strRecord & oRow("Description").ToString()
                Console.WriteLine(strRecord)
            Next
        Catch
            UnhandledExceptionHandler()
        End Try
    End Sub


    Function LoadSearchDataSet(ByVal strConnection As String, ByVal strSQL _
            As String) As DataSet

        Try
            Dim dsData As New DataSet()

            Dim strTableName As String = "Results"

            Dim blnRunStoredProc As Boolean = False

            dsData = PopulateDataSetTable(strConnection, strTableName, _
            strSQL, blnRunStoredProc, dsData)

            WriteSampleDataToOutputWindow(dsData)

            Return dsData

        Catch
            UnhandledExceptionHandler()
        End Try

    End Function

    Sub WriteSampleDataToOutputWindow(ByVal dsData As DataSet)
        Try
            Dim oRow As DataRow
            Dim oColumn As DataColumn

            Dim strRecord As String
            For Each oRow In dsData.Tables("Results").Rows
                strRecord = oRow(0).ToString()
                strRecord = strRecord & "    " & oRow(1).ToString
                strRecord = strRecord & "    " & oRow(2).ToString
                strRecord = strRecord & "    " & oRow(3).ToString
                strRecord = strRecord & "    " & oRow(4).ToString
                Console.WriteLine(strRecord)

            Next

        Catch
            UnhandledExceptionHandler()
        End Try
    End Sub

    Function PadQuotes(ByVal strIn As String) As String
        Try
            PadQuotes = strIn.Replace("'", "''")

        Catch
            UnhandledExceptionHandler()
        End Try
    End Function

    Function BuildSQLWhereClause(ByVal strTableName As String, ByVal _
        strQueryOperator As String, ByVal strSearchValue As String, _
        ByVal blnPriorWhereClause As Boolean, ByVal strWhereClause As _
        String, ByVal blnNumberField As Boolean) As String

        Try
            Dim strWhere As String = strWhereClause
            Dim strDelimiter1 As String
            Dim strDelimiter2 As String

            If blnPriorWhereClause = False Then
                strWhere = " WHERE "
            Else
                strWhere = strWhere & " AND "
            End If

            Select Case strQueryOperator
                Case "Equals"
                    If blnNumberField Then
                        strDelimiter1 = " = "
                        strDelimiter2 = ""
                    Else
                        strDelimiter1 = " = '"
                        strDelimiter2 = "' "
                    End If
                Case "Start With"
                    strDelimiter1 = " LIKE '"
                    strDelimiter2 = "%' "
                Case "Ends With"
                    strDelimiter1 = " LIKE '%"
                    strDelimiter2 = "' "
                Case "Contains"
                    strDelimiter1 = " LIKE '%"
                    strDelimiter2 = "%'"
                Case "Greater Than"
                    strDelimiter1 = " > "
                    strDelimiter2 = ""
                Case "Less Than"
                    strDelimiter1 = " < "
                    strDelimiter2 = ""

            End Select
            strWhere = strWhere & strTableName & strDelimiter1 & _
                                PadQuotes(strSearchValue) & strDelimiter2
            Return strWhere
        Catch
            UnhandledExceptionHandler()
        End Try
    End Function

    Function BuildSQLSelectFromClause(ByVal strSearchMethod As String) As String
        Try
            Dim strSelectFrom As String
            Select Case strSearchMethod
                Case "Products"

                    strSelectFrom = "SELECT p.ProductID as  ProductId, " & _
                    "p.ProductName " & _
                    "as ProductName, p.SupplierId as SupplierId, " & _
                    "s.CompanyName as CompanyName, p.CategoryId " & _
                    "as CategoryId, c.CategoryName as CategoryName, " & _
                    "p.QuantityPerUnit as QuantityPerUnit, " & _
                    "p.UnitPrice as UnitPrice, p.UnitsInStock " & _
                    "as UnitsInStock, p.UnitsOnOrder as  " & _
                    "UnitsOnOrder, p.ReorderLevel as " & _
                    "ReorderLevel, p.Discontinued as " & _
                    "Discontinued " & _
                    "FROM Products p " & _
                    "INNER JOIN Suppliers s ON p.SupplierId = " & _
                    "s.SupplierId " & _
                    "INNER JOIN Categories c ON p.CategoryId = " & _
                    "c.CategoryID"
                Case "Suppliers"
                    strSelectFrom = "SELECT * FROM Suppliers"
            End Select
            Return strSelectFrom
        Catch
        End Try
    End Function


    Sub ProcessUpdates(ByVal strConnection As String, ByVal strUpdateTable _
    As String, ByRef dsdata As DataSet)
        '********************************************************************
        'The purpose of this procedure is to call the database updates for
        'Products or Suppliers based on the changes in the dataset.
        'The strUpdateTable variable passed in should be either "Products" or
        '"Suppliers" for the value and depending on the value of it, the
        'appropriate database updates will be called. This is a
        'generic routine to keep code duplication to a minimum.
        '********************************************************************
        Try
            'Handle any changed records.
            If dsdata.HasChanges(DataRowState.Modified) Then
                Dim dsChangedDataSet As DataSet
                dsChangedDataSet = dsdata.GetChanges(DataRowState.Modified)
                If dsChangedDataSet.HasErrors Then
                    HandleDataSetErrors(dsChangedDataSet)
                Else
                    'Update the changes in the database.
                    If strUpdateTable = "Products" Then
                        UpdateProductsInDb(strConnection, dsChangedDataSet)
                    ElseIf strUpdateTable = "Suppliers" Then
                        UpdateSuppliersInDb(strConnection, dsChangedDataSet)
                    End If
                End If
            End If
            'Handle any deleted records.
            If dsdata.HasChanges(DataRowState.Deleted) Then
                Dim dsDeletedDataSet As DataSet
                dsDeletedDataSet = dsdata.GetChanges(DataRowState.Deleted)
                If dsDeletedDataSet.HasErrors Then
                    HandleDataSetErrors(dsDeletedDataSet)
                Else
                    DeleteRecordsInDb(strConnection, dsDeletedDataSet, _
                    strUpdateTable)
                End If
            End If
            'Handle any new records.
            If dsdata.HasChanges(DataRowState.Added) Then
                Dim dsAddedDataSet As DataSet
                dsAddedDataSet = dsdata.GetChanges(DataRowState.Added)
                If dsAddedDataSet.HasErrors Then
                    HandleDataSetErrors(dsAddedDataSet)
                Else
                    'Update the database with the new records.
                    If strUpdateTable = "Products" Then
                        InsertProductsInDb(strConnection, dsAddedDataSet)
                    ElseIf strUpdateTable = "Suppliers" Then
                        InsertSuppliersInDb(strConnection, dsAddedDataSet)
                    End If
                    'If the dsAddedDataSet was changed in the InsertXXXXInDb
                    'method (because a new ProductId or SupplierId was
                    'auto-generated by the database), then will need to
                    'update the Id for each record that was added.
                    If dsAddedDataSet.HasChanges Then
                        Dim dsChangedAddedDataSet As DataSet
                        dsChangedAddedDataSet = _
                        dsAddedDataSet.GetChanges(DataRowState.Added)
                        'merge the dsChangedAddedDataSet with the
                        'dsSearchResults
                        dsdata.Merge(dsChangedAddedDataSet.GetChanges)
                        dsdata.AcceptChanges()
                        'Get rid of the duplicates that got created on merge
                        'because the primary key wasn't set yet (i.e. delete
                        'the records that have a ProductId = 0 that are now
                        'in duplicate of the ones with the newly assigned
                        'ProductId.
                        Dim oRow As DataRow
                        For Each oRow In dsdata.Tables("results").Rows
                            If strUpdateTable = "Products" Then
                                If oRow("ProductId") = 0 Then
                                    oRow.Delete()
                                End If
                            ElseIf strUpdateTable = "Suppliers" Then
                                If oRow("SupplierId") = 0 Then
                                    oRow.Delete()
                                End If
                            End If
                        Next
                    End If
                End If
            End If
            dsdata.AcceptChanges()
        Catch
            'Error handling goes here.
            dsdata.RejectChanges()
            UnhandledExceptionHandler()
        End Try
    End Sub
    Sub InsertProductsInDb(ByVal strConnection As String, ByVal _
    dsInsertedDataSet As DataSet)
        '****************************************************************
        'The purpose of this function is to insert data into the Products
        'table based on information in a DataSet that changed.
        '****************************************************************
        Try
            Dim oRow As DataRow
            Dim intRowsAffected As Integer
            Dim SmallIntDiscontinued As Int16
            For Each oRow In dsInsertedDataSet.Tables("Results").Rows
                Dim cmdCommand As New SqlClient.SqlCommand()
                SmallIntDiscontinued = oRow("Discontinued")
                'Format to the format that SQL Server expects.
                'The equivalent to Boolean in SQL Server is BIT.
                'A bit can have 1 for True or 0 for False.
                'A boolean in VB can have -1 for True or 0 for False.
                If SmallIntDiscontinued = vbYes Then
                    SmallIntDiscontinued = -1
                End If
                AddProductsInsertUpdateParameters(cmdCommand, oRow, _
                SmallIntDiscontinued, False)
                intRowsAffected = ExecuteSPWithParameters(strConnection, _
                "spInsertProducts", cmdCommand)
                cmdCommand.Parameters.Clear()
                'Now need to retrieve the ProductId that was auto-generated
                'by the database and include it in our DataSet.
                AddProductNameParameters(cmdCommand, oRow("ProductName"))
                intRowsAffected = ExecuteSPWithParameters(strConnection, _
                "spGetProductIdByProductName", cmdCommand)
                'Retrieve the ProductId from the value returned by the
                'stored procedure and put it into our DataSet.
                oRow("ProductId") = _
                cmdCommand.Parameters.Item("@ProductId").Value
            Next
        Catch
            'Rrror handling goes here.
            UnhandledExceptionHandler()
        End Try
    End Sub

    Sub AddProductNameParameters(ByRef cmdCommand As SqlClient.SqlCommand, _
    ByVal strProductName As String)
        'The purpose of this procedure is to add the parameters to the
        'command object that will be passed to the stored procedure for
        'retrieving the ProductId that was just assigned.
        Try
            Dim sqlparm As New SqlClient.SqlParameter()
            sqlparm = cmdCommand.Parameters.Add("@ProductName", _
            SqlDbType.NVarChar, 40)
            sqlparm.Value = strProductName
            sqlparm = cmdCommand.Parameters.Add("@ProductId", SqlDbType.Int)
            sqlparm.Direction = ParameterDirection.Output
        Catch
            'Error handling goes here.
            UnhandledExceptionHandler()
        End Try
    End Sub

    Sub InsertSuppliersInDb(ByVal strConnection As String, ByVal _
    dsInsertedDataSet As DataSet)
        '****************************************************************
        'The purpose of this function is to insert data into the Suppliers
        'table based on information in a DataSet that changed.
        '****************************************************************
        Try
            Dim oRow As DataRow
            Dim intRowsAffected As Integer
            For Each oRow In dsInsertedDataSet.Tables("Results").Rows
                Dim cmdCommand As New SqlClient.SqlCommand()
                AddSuppliersInsertUpdateParameters(cmdCommand, oRow, _
                False)
                intRowsAffected = ExecuteSPWithParameters(strConnection, _
                "spInsertSuppliers", cmdCommand)
                cmdCommand.Parameters.Clear()
                'Now need to retrieve the SupplierId that was auto-generated
                'by the database and include it in our DataSet.
                AddSupplierCompanyNameParameters(cmdCommand, _
                oRow("CompanyName"))
                intRowsAffected = ExecuteSPWithParameters(strConnection, _
                "spGetSupplierIdByCompanyName", cmdCommand)
                'Retrieve the SupplierId from the value returned by the
                'stored procedure and put it into our DataSet.
                oRow("SupplierId") = _
                cmdCommand.Parameters.Item("@SupplierId").Value
            Next
        Catch
            'Error handling goes here.
            UnhandledExceptionHandler()
        End Try
    End Sub

    Sub AddSupplierCompanyNameParameters(ByRef cmdCommand As _
    SqlClient.SqlCommand, ByVal strCompanyName As String)
        'The purpose of this procedure is to add the parameters to the
        'command object that will be passed to the stored procedure for
        'retrieving the SupplierId that was just assigned.
        Try
            Dim sqlparm As New SqlClient.SqlParameter()
            sqlparm = cmdCommand.Parameters.Add("@CompanyName", _
            SqlDbType.NVarChar, 40)
            sqlparm.Value = strCompanyName
            sqlparm = cmdCommand.Parameters.Add("@SupplierId", _
            SqlDbType.Int)
            sqlparm.Direction = ParameterDirection.Output
        Catch
            'Error handling goes here.
            UnhandledExceptionHandler()
        End Try
    End Sub

    Sub DeleteRecordsInDb(ByVal strConnection As String, ByVal _
    dsDeletedDataSet As DataSet, ByVal strTableName As String)
        '****************************************************************
        'The purpose of this function is to delete data in the Products
        'table based on information in a DataSet that was deleted.
        '****************************************************************
        Try
            Dim oRow As DataRow
            Dim intRowsAffected As Integer
            For Each oRow In dsDeletedDataSet.Tables("Results").Rows
                Dim cmdCommand As New SqlClient.SqlCommand()
                'Reject changes so it will allow access to the ProductId.
                oRow.RejectChanges()
                If strTableName = "Products" Then
                    AddDeleteParameters(cmdCommand, "@ProductId", _
                    oRow("ProductId"))
                    intRowsAffected = _
                    ExecuteSPWithParameters(strConnection, _
                    "spDeleteProducts", cmdCommand)
                Else
                    AddDeleteParameters(cmdCommand, "@SupplierId", _
                    oRow("SupplierId"))
                    intRowsAffected = _
                    ExecuteSPWithParameters(strConnection, _
                    "spDeleteSuppliers", cmdCommand)
                End If
                'Turn around and delete it again.
                oRow.Delete()
            Next
        Catch
            'Error handling goes here.
            UnhandledExceptionHandler()
        End Try
    End Sub

    Sub AddDeleteParameters(ByRef cmdCommand As SqlClient.SqlCommand, _
    ByVal strVarName As String, ByVal intId As Integer)
        'The purpose of this procedure is to add the parameters to the
        'command object that will be passed to the stored procedure for
        'deleting Products or Suppliers. strVarname should be passed in as
        'the name of the parameter (e.g. @ProductId or @SupplierId) and
        'intId should be the unique ID to designate which record gets
        'deleted (e.g. ProductId or SupplierId).
        Try
            Dim sqlparm As New SqlClient.SqlParameter()
            sqlparm = cmdCommand.Parameters.Add(strVarName, SqlDbType.Int)
            sqlparm.Value = intId
        Catch
            'Error handling goes here.
            UnhandledExceptionHandler()
        End Try
    End Sub

    Sub HandleDataSetErrors(ByVal dsChanged As DataSet)
        Try
            'Invoke the geterrors method to return an array of DataRow
            'objects with errors.
            Dim ErrorRows() As DataRow
            Dim oRow As DataRow
            ErrorRows = GetAllErrors(dsChanged)
            'On each DataRow, examine the RowError property.
            Dim i As Integer
            Dim strError As String
            strError = "The following errors occurred - "
            For i = 0 To ErrorRows.GetUpperBound(0)
                strError = strError & " Row Error: " & _
                ErrorRows(i).RowError()
            Next
            Err.Raise(-5000, , strError)
        Catch
            'Error handling goes here.
            UnhandledExceptionHandler()
        End Try

    End Sub
    Function GetAllErrors(ByVal rsChanges As DataSet) As DataRow()
        Try
            Dim rowsInError() As DataRow
            Dim myTable As DataTable
            Dim i As Integer
            Dim myCol As DataColumn
            For Each myTable In rsChanges.Tables
                ' See if the table has errors. If not, skip it.
                If myTable.HasErrors Then
                    ' Get an array of all rows with errors.
                    rowsInError = myTable.GetErrors()
                End If
            Next
            Return rowsInError
        Catch
            'Error handling goes here.
            UnhandledExceptionHandler()
        End Try
    End Function
    Sub UpdateProductsInDb(ByVal strConnection As String, ByVal _
    dsChangedDataSet As DataSet)
        '****************************************************************
        'The purpose of this function is to update data in the Products
        'table based on information in a DataSet that changed.
        '****************************************************************
        Try
            Dim oRow As DataRow
            Dim smallintDiscontinued As Int16
            Dim intRowsAffected As Integer
            For Each oRow In dsChangedDataSet.Tables("Results").Rows
                smallintDiscontinued = oRow("Discontinued")
                'Format to the format that SQL Server expects.
                'The equivalent to Boolean in SQL Server is BIT.
                'A Bit can have 1 for True or 0 for False.
                'A Boolean in VB can have -1 for True or 0 for False.
                If smallintDiscontinued = vbYes Then
                    smallintDiscontinued = -1
                End If
                Dim cmdCommand As New SqlClient.SqlCommand()
                AddProductsInsertUpdateParameters(cmdCommand, oRow, _
                smallintDiscontinued, True)
                intRowsAffected = ExecuteSPWithParameters(strConnection, _
                "spUpdateProducts", cmdCommand)
            Next
        Catch
            'Error handling goes here.
            UnhandledExceptionHandler()
        End Try
    End Sub


    Sub AddProductsInsertUpdateParameters(ByRef cmdCommand As _
    SqlClient.SqlCommand, ByVal oRow As DataRow, ByVal _
    smallintdiscontinued As Int16, ByVal blnAddProductId As _
    Boolean)
        'The purpose of this procedure is to add the parameters to the
        'command object that will be passed to the stored procedure for
        'Updating OR Inserting Products.
        Try
            Dim sqlparm As New SqlClient.SqlParameter()
            'If updating a record, then will need to specify the ProductId.
            'If inserting, then one will not have been assigned yet (and
            'thus the insert stored procedure doesn't expect it as a '
            'parameter).
            If blnAddProductId Then
                sqlparm = cmdCommand.Parameters.Add("@ProductId", _
                SqlDbType.Int)
                sqlparm.Value = oRow("ProductId")
            End If
            sqlparm = cmdCommand.Parameters.Add("@ProductName", _
            SqlDbType.NVarChar, 40)
            sqlparm.Value = oRow("ProductName")
            sqlparm = cmdCommand.Parameters.Add("@SupplierId", _
            SqlDbType.Int)
            sqlparm.Value = oRow("SupplierId")
            sqlparm = cmdCommand.Parameters.Add("@CategoryId", _
            SqlDbType.Int)
            sqlparm.Value = oRow("CategoryId")
            sqlparm = cmdCommand.Parameters.Add("@QuantityPerUnit", _
            SqlDbType.NVarChar, 20)
            sqlparm.Value = oRow("QuantityPerUnit")
            sqlparm = cmdCommand.Parameters.Add("@UnitPrice", _
            SqlDbType.Money)
            sqlparm.Value = oRow("UnitPrice")
            sqlparm = cmdCommand.Parameters.Add("@UnitsInStock", _
            SqlDbType.SmallInt)
            sqlparm.Value = oRow("UnitsInStock")
            sqlparm = cmdCommand.Parameters.Add("@UnitsOnOrder", _
            SqlDbType.SmallInt)
            sqlparm.Value = oRow("UnitsOnOrder")
            sqlparm = cmdCommand.Parameters.Add("@ReorderLevel", _
            SqlDbType.SmallInt)
            sqlparm.Value = oRow("ReorderLevel")
            sqlparm = cmdCommand.Parameters.Add("@Discontinued", _
            SqlDbType.Bit)
            sqlparm.Value = smallintdiscontinued
        Catch
            'Error handling goes here.
            UnhandledExceptionHandler()
        End Try
    End Sub

    Function ExecuteSPWithParameters(ByVal strConnection As String, ByVal _
    strSPName As String, ByVal cmdCommand As SqlCommand) As Integer
        'The purpose of this function is to execute a stored procedure with
        'parameters as passed in with the command object. The number of
        'rows affected is returned.
        Try
            Dim intRowsAffected As Integer
            Dim sqlConn As New SqlClient.SqlConnection(strConnection)
            sqlConn.Open()
            Dim cmdParms As SqlClient.SqlCommand = cmdCommand
            cmdParms.Connection = sqlConn
            cmdParms.CommandType = CommandType.StoredProcedure
            cmdParms.CommandText = strSPName
            'execute the stored procedure
            intRowsAffected = cmdParms.ExecuteNonQuery()
            sqlConn.Close()
            Return intRowsAffected
        Catch
            'Error handling goes here.
            UnhandledExceptionHandler()
        End Try
    End Function

    Sub UpdateSuppliersInDb(ByVal strConnection As String, ByVal _
    dsChangedDataSet As DataSet)
        '****************************************************************
        'The purpose of this function is to update data in the Suppliers
        'table based on information in a DataSet that changed.
        '****************************************************************
        Try
            Dim oRow As DataRow
            Dim intRowsAffected As Integer
            For Each oRow In dsChangedDataSet.Tables("Results").Rows
                Dim cmdCommand As New SqlClient.SqlCommand()
                AddSuppliersInsertUpdateParameters(cmdCommand, oRow, _
                True)
                intRowsAffected = ExecuteSPWithParameters(strConnection, _
                "spUpdateSuppliers", cmdCommand)
            Next
        Catch
            'Error handling goes here.
            UnhandledExceptionHandler()
        End Try
    End Sub

    Sub AddSuppliersInsertUpdateParameters(ByRef cmdCommand As _
    SqlClient.SqlCommand, ByVal oRow As DataRow, ByVal _
    blnAddSupplierId As Boolean)
        'The purpose of this procedure is to add the parameters to the
        'command object that will be passed to the stored procedure for
        'updating or inserting Suppliers.
        Try
            Dim sqlparm As New SqlClient.SqlParameter()
            'If updating a record, then will need to specify the SupplierId.
            'If inserting, then one will not have been assigned yet (and
            'thus the insert stored procedure doesn't expect it as a
            'parameter).
            If blnAddSupplierId Then
                sqlparm = cmdCommand.Parameters.Add("@SupplierId", _
                SqlDbType.Int)
                sqlparm.Value = oRow("SupplierId")
            End If
            sqlparm = cmdCommand.Parameters.Add("@CompanyName", _
            SqlDbType.NVarChar, 40)
            sqlparm.Value = oRow("CompanyName")
            sqlparm = cmdCommand.Parameters.Add("@ContactName", _
            SqlDbType.NVarChar, 30)
            sqlparm.Value = oRow("ContactName")
            sqlparm = cmdCommand.Parameters.Add("@ContactTitle", _
            SqlDbType.NVarChar, 30)
            sqlparm.Value = oRow("ContactTitle")
            sqlparm = cmdCommand.Parameters.Add("@Address", _
            SqlDbType.NVarChar, 60)
            sqlparm.Value = oRow("Address")
            sqlparm = cmdCommand.Parameters.Add("@City", _
            SqlDbType.NVarChar, 15)
            sqlparm.Value = oRow("City")
            sqlparm = cmdCommand.Parameters.Add("@Region", _
            SqlDbType.NVarChar, 15)
            sqlparm.Value = oRow("Region")
            sqlparm = cmdCommand.Parameters.Add("@PostalCode", _
            SqlDbType.NVarChar, 10)
            sqlparm.Value = oRow("PostalCode")
            sqlparm = cmdCommand.Parameters.Add("@Country", _
            SqlDbType.NVarChar, 15)
            sqlparm.Value = oRow("Country")
            sqlparm = cmdCommand.Parameters.Add("@Phone", _
            SqlDbType.NVarChar, 24)
            sqlparm.Value = oRow("Phone")
            sqlparm = cmdCommand.Parameters.Add("@Fax", _
            SqlDbType.NVarChar, 24)
            sqlparm.Value = oRow("Fax")
            sqlparm = cmdCommand.Parameters.Add("@HomePage", _
            SqlDbType.NText)
            sqlparm.Value = oRow("HomePage")
        Catch
            'Error handling goes here.
            UnhandledExceptionHandler()
        End Try
    End Sub
End Class



Public Class frmManageProduct
    Inherits BaseForms.BaseDataForm
    Dim cboField3 As New ComboBox()
    Dim cboField4 As New ComboBox()
    Dim chkField10 As New CheckBox()
#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.SuspendLayout()
        '
        'lblField12
        '
        Me.lblField12.Visible = True
        '
        'lblField11
        '
        Me.lblField11.Visible = True
        '
        'lblField10
        '
        Me.lblField10.Visible = True
        '
        'lblField9
        '
        Me.lblField9.Visible = True
        '
        'lblField8
        '
        Me.lblField8.Visible = True
        '
        'lblField7
        '
        Me.lblField7.Visible = True
        '
        'txtField1
        '
        Me.txtField1.Visible = True
        '
        'lblField6
        '
        Me.lblField6.Visible = True
        '
        'lblField5
        '
        Me.lblField5.Visible = True
        '
        'txtField2
        '
        Me.txtField2.Visible = True
        '
        'txtField3
        '
        Me.txtField3.Visible = True
        '
        'txtField4
        '
        Me.txtField4.Visible = True
        '
        'lblField4
        '
        Me.lblField4.Visible = True
        '
        'txtField5
        '
        Me.txtField5.Visible = True
        '
        'txtField6
        '
        Me.txtField6.Visible = True
        '
        'txtField7
        '
        Me.txtField7.Visible = True
        '
        'txtField8
        '
        Me.txtField8.Visible = True
        '
        'lblField3
        '
        Me.lblField3.Visible = True
        '
        'lblField2
        '
        Me.lblField2.Visible = True
        '
        'txtField9
        '
        Me.txtField9.Visible = True
        '
        'lblField1
        '
        Me.lblField1.Visible = True
        '
        'btnSave
        '
        Me.btnSave.Visible = True
        '
        'btnDelete
        '
        Me.btnDelete.Visible = True
        '
        'txtField10
        '
        Me.txtField10.Visible = True
        '
        'btnAdd
        '
        Me.btnAdd.Visible = True
        '
        'btnNext
        '
        Me.btnNext.Visible = True
        '
        'btnPrevious
        '
        Me.btnPrevious.Visible = True
        '
        'txtField12
        '
        Me.txtField12.Visible = True
        '
        'txtField11
        '
        Me.txtField11.Visible = True
        '
        'frmManageProduct
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(650, 479)
        Me.Controls.AddRange(New System.Windows.Forms.Control() {Me.btnSave, Me.btnDelete, Me.btnAdd, Me.btnNext, Me.btnPrevious, Me.txtField12, Me.txtField11, Me.txtField10, Me.txtField9, Me.txtField8, Me.txtField7, Me.txtField6, Me.txtField5, Me.txtField4, Me.txtField3, Me.txtField2, Me.txtField1, Me.lblField12, Me.lblField11, Me.lblField10, Me.lblField9, Me.lblField8, Me.lblField7, Me.lblField6, Me.lblField5, Me.lblField4, Me.lblField3, Me.lblField2, Me.lblField1})
        Me.Name = "frmManageProduct"
        Me.ResumeLayout(False)

    End Sub

#End Region

    Sub SetControls()
        Try
        
            'This procedure makes minor changes to customize the base
            'form to meet the specific needs of the Add/View/Update
            'Products form.
            'Assign the title to the form.
            Me.Text = "Add/View/Edit Products"
            'Assign the labels for the fields.
            lblField1.Text = "Product Id:"
            lblField2.Text = "Product Name:"
            lblField3.Text = "Supplier Id:"
            lblField4.Text = "Category Id:"
            lblField5.Text = "Quantity Per Unit:"
            lblField6.Text = "Unit Price:"
            lblField7.Text = "Units In Stock:"
            lblField8.Text = "Units On Order:"
            lblField9.Text = "Reorder Level:"
            lblField10.Text = "Discontinued:"
            'Hide/disable the labels and textboxes for fields 11 and 12
            'since we only need 10 fields on the Products Add/View/Update
            'form.
            EnableDisable(lblfield11, False)
            EnableDisable(txtfield11, False)
            EnableDisable(lblfield12, False)
            EnableDisable(txtfield12, False)
            'Field3 is the Supplier Id field and should be a combobox
            'instead of the default textbox. Put a combobox in the
            'exact location as the textbox and disable the textbox.
            ReplaceControl(txtfield3, cboField3)
            'Field4 is the Category Id field and should be a combobox
            'instead of the default textbox. Put a combobox in the
            'exact location as the textbox and disable the textbox.
            ReplaceControl(txtfield4, cboField4)
            'Field10 is the Discontinued indicator and should be a checkbox
            'instead of the default textbox. Put a checkbox in the exact
            'location as the textbox and disable the textbox.
            ReplaceControl(txtfield10, chkField10)
            'Add the 3 new fields to the form controls so they will be
            'displayed.
            Me.Controls.Add(cboField3)
            Me.Controls.Add(cboField4)
            Me.Controls.Add(chkField10)
        Catch
            'Error handling goes here.
            UnhandledExceptionHandler()
        End Try
    End Sub

    Sub frmManageProducts_Load(ByVal sender As System.Object, ByVal e As _
       System.EventArgs) Handles MyBase.Load
        Try
            'Customize the form to the specific needs of the Products
            'Add/View/Edit screen.
            SetControls()
            Dim oRow As DataRow
            'Loop through the CodeTables DataSet and populate the choices
            'in the SupplierId drop-down.
            For Each oRow In dsCodeTables.Tables("Suppliers").Rows
                cboField3.Items.Add(oRow("SupplierId").ToString())
            Next
            'Loop through the CodeTables DataSet and populate the choices
            'in the CategoryId drop-down.
            For Each oRow In dsCodeTables.Tables("Categories").Rows
                cboField4.Items.Add(oRow("CategoryId").ToString())
            Next
            'Bind each input field on the form to the corresponding item in
            'the search results dataset.
            txtfield1.DataBindings.Add(New Binding("Text", _
            dsSearchResults, "results.ProductId"))
            txtField2.DataBindings.Add(New Binding("Text", _
            dsSearchResults, "results.ProductName"))
            cboField3.DataBindings.Add(New Binding("Text", _
            dsSearchResults, "results.SupplierId"))
            cboField4.DataBindings.Add(New Binding("Text", _
            dsSearchResults, "results.CategoryId"))
            txtfield5.DataBindings.Add(New Binding("Text", _
            dsSearchResults, "results.QuantityPerUnit"))
            txtField6.DataBindings.Add(New Binding("Text", _
            dsSearchResults, "results.UnitPrice"))
            txtField7.DataBindings.Add(New Binding("Text", _
            dsSearchResults, "results.UnitsInStock"))
            txtField8.DataBindings.Add(New Binding("Text", _
            dsSearchResults, "results.unitsonorder"))
            txtField9.DataBindings.Add(New Binding("Text", _
            dsSearchResults, "results.ReorderLevel"))
            chkField10.DataBindings.Add(New Binding("Checked", _
            dsSearchResults, "results.Discontinued"))
            'Set the ProductId to readonly since it is the key and should
            'not be changed.
            txtField1.ReadOnly = True
            'Use the binding manager to manipulate the records in the
            'DataSet such as moving around the DataSet. In this case we're
            'setting the position to the selected record from the Search
            'Screen.
            myBindingManagerBase = BindingContext(dsSearchResults, _
            "Results")
            myBindingManagerBase.Position = intCurrentRec
        Catch
            'Error handling goes here.
            UnhandledExceptionHandler()
        End Try
    End Sub

    Private Sub btnAdd_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnAdd.Click
        Try
            'Use the NewRow to create a DataRow in the DataSet.
            Dim myRow As DataRow
            myRow = dsSearchResults.Tables("results").NewRow()
            myRow("ProductId") = "0"
            myRow("ProductName") = ""
            myRow("SupplierId") = "0"
            myRow("CategoryId") = "0"
            myRow("QuantityPerUnit") = ""
            myRow("UnitPrice") = "0"
            myRow("UnitsInStock") = "0"
            myRow("UnitsOnOrder") = "0"
            myRow("ReorderLevel") = "0"
            myRow("Discontinued") = "false"
            'Add the row with default values.
            dsSearchResults.Tables("results").Rows.Add(myRow)
            'Move to the newly added row so the user can fill in the new
            'information.
            MoveLast()
            'Make sure the frmManageProducts form stays on top.
            frmManageProduct.ActiveForm.TopMost = True
            'Set focus to the ProductName field on the form.
            txtField2.Focus()
        Catch
            'Error handling goes here.
            UnhandledExceptionHandler()
        End Try
    End Sub

    Private Sub btnDelete_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnDelete.Click
        Try
            'Delete the current row from the DataSet.
            Dim oRow As DataRow
            Dim oTable As DataTable
            Dim intResponse As Integer
            intResponse = MsgBox("Are you sure you want to delete the " & _
            "current record from the DataSet?", _
            MsgBoxStyle.YesNo, "Confirm Delete")
            'If they confirm they want to delete, then go ahead and remove
            'the record from the DataSet. Reminder that this still doesn't
            'delete it from the database. That occurs under the SaveAll
            'when all changes in the DataSet are updated in the database.
            If intResponse = vbYes Then

                oTable = dsSearchResults.Tables("results")
                oRow = oTable.Rows(myBindingManagerBase.Position)
                If Not oRow.RowState = DataRowState.Deleted Then _
                oRow.Delete()
                'Make sure the frmManageXXX form stays on top.
                Me.ActiveForm.TopMost = True
                MovePrevious()
            End If
        Catch
            'Handle errors.
            UnhandledExceptionHandler()
        End Try

    End Sub

  
    Private Sub btnSave_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSave.Click
        Try
            MoveFirst()
            Dim clsDb As New clsDatabase()
            clsDb.ProcessUpdates(CONN, PROD, dsSearchResults)
            clsDb = Nothing
            MsgBox("Save Completed. If no other messages appeared " & _
            "indicating any errors, then all changes were successful.")
        Catch
            'Error handling goes here.
            UnhandledExceptionHandler()
        End Try
    End Sub

End Class

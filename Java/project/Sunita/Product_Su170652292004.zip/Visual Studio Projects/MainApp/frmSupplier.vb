

Public Class frmSupplier
    Inherits BaseForms.BaseSearchForm

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        CType(Me.dgdResults, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox1.SuspendLayout()
        Me.SuspendLayout()
        '
        'cboCriteria1
        '
        Me.cboCriteria1.ItemHeight = 13
        Me.cboCriteria1.Size = New System.Drawing.Size(176, 21)
        Me.cboCriteria1.Visible = True
        '
        'btnClear
        '
        Me.btnClear.Visible = True
        '
        'cboCriteria2
        '
        Me.cboCriteria2.ItemHeight = 13
        Me.cboCriteria2.Size = New System.Drawing.Size(176, 21)
        Me.cboCriteria2.Visible = True
        '
        'cboCriteria3
        '
        Me.cboCriteria3.ItemHeight = 13
        Me.cboCriteria3.Size = New System.Drawing.Size(176, 21)
        Me.cboCriteria3.Visible = True
        '
        'cboCriteria4
        '
        Me.cboCriteria4.ItemHeight = 13
        Me.cboCriteria4.Size = New System.Drawing.Size(176, 21)
        Me.cboCriteria4.Visible = True
        '
        'cboCriteria5
        '
        Me.cboCriteria5.ItemHeight = 13
        Me.cboCriteria5.Size = New System.Drawing.Size(176, 21)
        Me.cboCriteria5.Visible = True
        '
        'cboCriteria6
        '
        Me.cboCriteria6.ItemHeight = 13
        Me.cboCriteria6.Size = New System.Drawing.Size(176, 21)
        Me.cboCriteria6.Visible = True
        '
        'lblCriteria2
        '
        Me.lblCriteria2.Visible = True
        '
        'lblCriteria6
        '
        Me.lblCriteria6.Visible = True
        '
        'dgdResults
        '
        Me.dgdResults.AccessibleName = "DataGrid"
        Me.dgdResults.AccessibleRole = System.Windows.Forms.AccessibleRole.Table
        Me.dgdResults.Visible = True
        '
        'lblCriteria5
        '
        Me.lblCriteria5.Visible = True
        '
        'lblCriteria4
        '
        Me.lblCriteria4.Visible = True
        '
        'lblCriteria3
        '
        Me.lblCriteria3.Visible = True
        '
        'lblCriteria1
        '
        Me.lblCriteria1.Visible = True
        '
        'cboSearchMethod
        '
        Me.cboSearchMethod.ItemHeight = 13
        Me.cboSearchMethod.Visible = True
        '
        'btnSearch
        '
        Me.btnSearch.Visible = True
        '
        'txtCriteria6
        '
        Me.txtCriteria6.Visible = True
        '
        'txtCriteria1
        '
        Me.txtCriteria1.Visible = True
        '
        'txtCriteria5
        '
        Me.txtCriteria5.Visible = True
        '
        'txtCriteria4
        '
        Me.txtCriteria4.Visible = True
        '
        'txtCriteria3
        '
        Me.txtCriteria3.Visible = True
        '
        'txtCriteria2
        '
        Me.txtCriteria2.Visible = True
        '
        'GroupBox1
        '
        Me.GroupBox1.Visible = True
        '
        'frmSupplier
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(738, 573)
        Me.Controls.AddRange(New System.Windows.Forms.Control() {Me.dgdResults, Me.btnClear, Me.GroupBox1, Me.cboSearchMethod, Me.btnSearch})
        Me.Name = "frmSupplier"
        CType(Me.dgdResults, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox1.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub

#End Region
    Private Sub cboSearchMethod_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cboSearchMethod.SelectedIndexChanged


        Try
            If cboSearchMethod.Text = PROD Then
                Dim frmSuppliers As New frmProduct()
                frmSuppliers.Show()
            End If

        Catch
            UnhandledExceptionHandler()
        End Try
    End Sub

    Private Sub frmSupplier_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Try

            Me.Text = "Product Search Utility"
            AddSearchMethod()
            cboSearchMethod.Text = SUPP
            AddNumericDropDownCriteria(cbocriteria1)
            AddCharDropDownCriteria(cbocriteria2)
            AddCharDropDownCriteria(cbocriteria3)
            AddCharDropDownCriteria(cbocriteria4)
            AddNumericDropDownCriteria(cbocriteria5)
            AddNumericDropDownCriteria(cbocriteria6)
        Catch
            UnhandledExceptionHandler()
        End Try
    End Sub
    Function BuildSQLStatement() As String
        Try
            Dim strSQL As String
            Dim strSelectFromCriteria As String
            Dim strWhereCriteria As String
            Dim blnPriorWhere As Boolean = False
            Dim blnNumericField As Boolean = False
            Dim clsDb As New clsDatabase()
            strSelectFromCriteria = clsDb.BuildSQLSelectFromClause("Suppliers")

            CheckSearchCriteria(cbocriteria1.Text, txtCriteria1.Text, _
                        "SupplierId", strWhereCriteria, blnPriorWhere, "true", _
                        AddressOf clsDb.BuildSQLWhereClause)

            CheckSearchCriteria(cbocriteria2.Text, txtCriteria2.Text, _
                        "CompanyName", strWhereCriteria, blnPriorWhere, "false", _
                        AddressOf clsDb.BuildSQLWhereClause)
            CheckSearchCriteria(cbocriteria3.Text, txtCriteria3.Text, _
                        "ContactName", strWhereCriteria, blnPriorWhere, "false", _
                        AddressOf clsDb.BuildSQLWhereClause)
            CheckSearchCriteria(cbocriteria4.Text, txtCriteria4.Text, _
                        "City", strWhereCriteria, blnPriorWhere, "false", _
                        AddressOf clsDb.BuildSQLWhereClause)
            CheckSearchCriteria(cbocriteria5.Text, txtCriteria5.Text, _
                        "Region", strWhereCriteria, blnPriorWhere, "false", _
                        AddressOf clsDb.BuildSQLWhereClause)
            CheckSearchCriteria(cbocriteria6.Text, txtCriteria6.Text, _
                        "PostalCode", strWhereCriteria, blnPriorWhere, "false", _
                        AddressOf clsDb.BuildSQLWhereClause)

            strSQL = strSelectFromCriteria & strWhereCriteria
            MsgBox("The SQL Statement is : " & strSQL)
            clsDb = Nothing
            Return strSQL
        Catch
            UnhandledExceptionHandler()
        End Try
    End Function

    Private Sub btnSearch_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSearch.Click
        Try
            Dim custCB As SqlClient.SqlCommandBuilder = New _
            SqlClient.SqlCommandBuilder(adapterResults)
            Dim clsdatabase As New clsDatabase()
            Dim strSQL As String = ""

            dsdata = clsdatabase.LoadCompleteDataSet(CONN)
            strSQL = BuildSQLStatement()
            dsresult = clsdatabase.LoadSearchDataSet(CONN, strSQL)
            dgdresults.DataSource = dsdata
        Catch
            UnhandledExceptionHandler()
        End Try
    End Sub
    Private Sub dgdResults_DoubleClick(ByVal sender As Object, ByVal e As _
    System.EventArgs) Handles dgdResults.DoubleClick
        Try
            'Use the BindingManagerBase to determine the current position of
            'the selected record.
            Dim bmGrid As BindingManagerBase
            bmGrid = BindingContext(dsResult, "Results")
            'Load Add/View/Update Suppliers screen.
            Dim frmSuppliers As New frmManageSupplier()
            frmSuppliers.AssignDataSet(dsResult, dsData, _
            bmGrid.Position)
            frmSuppliers.Show()
        Catch
            'Error handling goes here.
            UnhandledExceptionHandler()
        End Try
    End Sub
End Class

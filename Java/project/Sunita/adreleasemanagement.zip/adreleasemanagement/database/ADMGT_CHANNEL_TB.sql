CREATE TABLE ADMGT_CHANNEL_TB(PK_CH_ID VARCHAR(10) PRIMARY KEY,CHANNEL_NAME VARCHAR(20) )
delete from ADMGT_CHANNEL_TB
insert into ADMGT_CHANNEL_TB values('ch001','starplus')
insert into ADMGT_CHANNEL_TB values('ch002','sonymax')
insert into ADMGT_CHANNEL_TB values('ch003','gemini')
insert into ADMGT_CHANNEL_TB values('ch004','starmovies')
insert into ADMGT_CHANNEL_TB values('ch005','zee')
insert into ADMGT_CHANNEL_TB values('ch006','hbo')

create table ADMGT_LOGIN_TB (PK_LOGIN_USER_NAME VARCHAR(20) PRIMARY KEY,PASS_WORD VARCHAR(20),ROLE VARCHAR(15))

insert into  ADMGT_LOGIN_TB values ('133737','titan123','staff')
insert into ADMGT_LOGIN_TB values ('133744','timex123','staff')
insert into ADMGT_LOGIN_TB values ('133723','pass123','mgr')
insert into ADMGT_LOGIN_TB values ('133730','sonata','mgr')
insert into ADMGT_LOGIN_TB values ('133732','wipro123','staff')
vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|12 Feb 2007 11:10:16 -0000
vti_extenderversion:SR|4.0.2.7802

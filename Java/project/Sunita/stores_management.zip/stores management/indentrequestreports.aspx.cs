using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;
namespace group_16
{
	/// <summary>
	/// Summary description for WebForm8.
	/// </summary>
	public class WebForm8 : System.Web.UI.Page
	{
		protected System.Web.UI.WebControls.DataGrid dg1;
		protected System.Web.UI.WebControls.Label Label1;
		
		protected System.Data.SqlClient.SqlDataAdapter sda1;
		protected System.Data.SqlClient.SqlCommand sqlSelectCommand1;
		protected System.Data.SqlClient.SqlCommand sqlInsertCommand1;
		protected System.Data.SqlClient.SqlConnection sqlConnection1;
		protected group16.ds8 ds81;
		//connecting to database	
		SqlDataAdapter Sqlda;
		DataSet DS;
		string conStr="server=.;database=stores;uid=sa;pwd=sa";
	
		private void Page_Load(object sender, System.EventArgs e)
		{
			if(!Page.IsPostBack)
			{
				//storing Session userid into uid type integer
				int uid=Convert.ToInt32(Session["uid"]);
				Sqlda=new SqlDataAdapter("SELECT req_id,fk_request_login_emp_id,fk_request_login_mat_name,req_quant,req_date FROM stores_request_tb where fk_request_login_emp_id="+uid+" ",conStr);
				//creating new dataset
				DS=new DataSet();
				Sqlda.Fill(DS,"tmptable");
				dg1.DataSource=DS.Tables[0];
				//binding the data into datagrid
				dg1.DataBind();
			}
		}
		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.sda1 = new System.Data.SqlClient.SqlDataAdapter();
			this.sqlInsertCommand1 = new System.Data.SqlClient.SqlCommand();
			this.sqlConnection1 = new System.Data.SqlClient.SqlConnection();
			this.sqlSelectCommand1 = new System.Data.SqlClient.SqlCommand();
			this.ds81 = new group16.ds8();
			((System.ComponentModel.ISupportInitialize)(this.ds81)).BeginInit();
			this.dg1.PageIndexChanged += new System.Web.UI.WebControls.DataGridPageChangedEventHandler(this.dg1_PageIndexChanged);
			// 
			// sda1
			// 
			this.sda1.InsertCommand = this.sqlInsertCommand1;
			this.sda1.SelectCommand = this.sqlSelectCommand1;
			this.sda1.TableMappings.AddRange(new System.Data.Common.DataTableMapping[] {
																						   new System.Data.Common.DataTableMapping("Table", "stores_request_tb", new System.Data.Common.DataColumnMapping[] {
																																																				new System.Data.Common.DataColumnMapping("req_id", "req_id"),
																																																				new System.Data.Common.DataColumnMapping("fk_request_login_emp_id", "fk_request_login_emp_id"),
																																																				new System.Data.Common.DataColumnMapping("fk_request_login_mat_name", "fk_request_login_mat_name"),
																																																				new System.Data.Common.DataColumnMapping("req_quant", "req_quant"),
																																																				new System.Data.Common.DataColumnMapping("req_date", "req_date"),
																																																				new System.Data.Common.DataColumnMapping("req_status", "req_status")})});
			// 
			// sqlInsertCommand1
			// 
			this.sqlInsertCommand1.CommandText = @"INSERT INTO stores_request_tb(fk_request_login_emp_id, fk_request_login_mat_name, req_quant, req_date, req_status) VALUES (@fk_request_login_emp_id, @fk_request_login_mat_name, @req_quant, @req_date, @req_status); SELECT req_id, fk_request_login_emp_id, fk_request_login_mat_name, req_quant, req_date, req_status FROM stores_request_tb";
			this.sqlInsertCommand1.Connection = this.sqlConnection1;
			this.sqlInsertCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@fk_request_login_emp_id", System.Data.SqlDbType.Int, 4, "fk_request_login_emp_id"));
			this.sqlInsertCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@fk_request_login_mat_name", System.Data.SqlDbType.VarChar, 20, "fk_request_login_mat_name"));
			this.sqlInsertCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@req_quant", System.Data.SqlDbType.Int, 4, "req_quant"));
			this.sqlInsertCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@req_date", System.Data.SqlDbType.DateTime, 8, "req_date"));
			this.sqlInsertCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@req_status", System.Data.SqlDbType.VarChar, 20, "req_status"));
			// 
			// sqlConnection1
			// 
			this.sqlConnection1.ConnectionString = "workstation id=GUL11;packet size=4096;user id=sa;data source=\".\";persist security" +
				" info=False;initial catalog=stores";
			// 
			// sqlSelectCommand1
			// 
			this.sqlSelectCommand1.CommandText = "SELECT req_id, fk_request_login_emp_id, fk_request_login_mat_name, req_quant, req" +
				"_date, req_status FROM stores_request_tb";
			this.sqlSelectCommand1.Connection = this.sqlConnection1;
			// 
			// ds81
			// 
			this.ds81.DataSetName = "ds8";
			this.ds81.Locale = new System.Globalization.CultureInfo("en-US");
			this.Load += new System.EventHandler(this.Page_Load);
			((System.ComponentModel.ISupportInitialize)(this.ds81)).EndInit();

		}
		#endregion

		private void dg1_PageIndexChanged(object source, System.Web.UI.WebControls.DataGridPageChangedEventArgs e)
		{
			//appearing details page by page
			dg1.CurrentPageIndex=e.NewPageIndex;
			int uid=Convert.ToInt32(Session["uid"]);
			Sqlda=new SqlDataAdapter("SELECT req_id,fk_request_login_emp_id,fk_request_login_mat_name,req_quant,req_date FROM stores_request_tb where fk_request_login_emp_id="+uid+" ",conStr);
			DS=new DataSet();
			Sqlda.Fill(DS,"tmptable");
			dg1.DataSource=DS.Tables[0];
			dg1.DataSource=DS;
			dg1.DataBind();
		}
	}
}

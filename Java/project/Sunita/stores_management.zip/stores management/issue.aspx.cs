using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;

namespace group_16
{
	/// <summary>
	/// Summary description for WebForm11.
	/// </summary>
	public class WebForm11 : System.Web.UI.Page
	{
		protected System.Web.UI.WebControls.DataGrid dg1;
		protected System.Data.SqlClient.SqlDataAdapter sda1;
		protected System.Data.SqlClient.SqlCommand sqlSelectCommand1;
		protected System.Data.SqlClient.SqlConnection sqlConnection1;
		protected group16.ds3 ds31;
		protected System.Web.UI.WebControls.Label Label1;
		
		protected System.Web.UI.WebControls.Button Button1;
		protected System.Web.UI.WebControls.Button Button2;
		protected System.Web.UI.WebControls.Label Lblmsg;
		protected System.Web.UI.WebControls.Label Label2;
		protected System.Web.UI.WebControls.Label Lblmsg2;
		protected System.Web.UI.WebControls.Label lblErrorMessage;
		//connecting to database	
		string conStr="server=.;database=stores;uid=sa;pwd=sa";
		SqlDataAdapter Sqlda;
		DataSet DS;
		
		private void Page_Load(object sender, System.EventArgs e)
		{
			if(!Page.IsPostBack)
			{
				//storing Session userid into uid type integer
				int id=Convert.ToInt32(Request.QueryString["id"]);
				//Getting Different colums from different tables
			    Sqlda=new SqlDataAdapter("SELECT stores_request_tb.req_id, stores_request_tb.fk_request_login_emp_id, stores_request_tb.fk_request_login_mat_name, stores_request_tb.req_quant,stores_request_tb.req_date, stores_stock_tb.quant_available, stores_suppliers_tb.sup_name FROM stores_request_tb INNER JOIN  stores_stock_tb ON stores_request_tb.fk_request_login_mat_name = stores_stock_tb.pk_stock_mat_name INNER JOIN stores_suppliers_tb ON stores_stock_tb.pk_stock_mat_name = stores_suppliers_tb.fk_suppliers_stock_mat_name where stores_request_tb.req_id="+id+"",conStr);
				DS=new DataSet();
				Sqlda.Fill(DS,"tmptable");
				dg1.DataSource=DS.Tables[0];
				dg1.DataBind();
			}
			}

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.sda1 = new System.Data.SqlClient.SqlDataAdapter();
			this.sqlSelectCommand1 = new System.Data.SqlClient.SqlCommand();
			this.sqlConnection1 = new System.Data.SqlClient.SqlConnection();
			this.ds31 = new group16.ds3();
			((System.ComponentModel.ISupportInitialize)(this.ds31)).BeginInit();
			this.Button1.Click += new System.EventHandler(this.Button1_Click);
			this.Button2.Click += new System.EventHandler(this.Button2_Click);
			// 
			// sda1
			// 
			this.sda1.SelectCommand = this.sqlSelectCommand1;
			this.sda1.TableMappings.AddRange(new System.Data.Common.DataTableMapping[] {
																						   new System.Data.Common.DataTableMapping("Table", "stores_request_tb", new System.Data.Common.DataColumnMapping[] {
																																																				new System.Data.Common.DataColumnMapping("req_id", "req_id"),
																																																				new System.Data.Common.DataColumnMapping("fk_request_login_emp_id", "fk_request_login_emp_id"),
																																																				new System.Data.Common.DataColumnMapping("fk_request_login_mat_name", "fk_request_login_mat_name"),
																																																				new System.Data.Common.DataColumnMapping("req_quant", "req_quant"),
																																																				new System.Data.Common.DataColumnMapping("req_date", "req_date"),
																																																				new System.Data.Common.DataColumnMapping("quant_available", "quant_available"),
																																																				new System.Data.Common.DataColumnMapping("sup_name", "sup_name"),
																																																				new System.Data.Common.DataColumnMapping("pk_stock_mat_name", "pk_stock_mat_name"),
																																																				new System.Data.Common.DataColumnMapping("pk_suppliers_sup_id", "pk_suppliers_sup_id")})});
			// 
			// sqlSelectCommand1
			// 
			this.sqlSelectCommand1.CommandText = @"SELECT stores_request_tb.req_id, stores_request_tb.fk_request_login_emp_id, stores_request_tb.fk_request_login_mat_name, stores_request_tb.req_quant, stores_request_tb.req_date, stores_stock_tb.quant_available, stores_suppliers_tb.sup_name, stores_stock_tb.pk_stock_mat_name, stores_suppliers_tb.pk_suppliers_sup_id FROM stores_request_tb INNER JOIN stores_stock_tb ON stores_request_tb.fk_request_login_mat_name = stores_stock_tb.pk_stock_mat_name INNER JOIN stores_suppliers_tb ON stores_stock_tb.pk_stock_mat_name = stores_suppliers_tb.fk_suppliers_stock_mat_name";
			this.sqlSelectCommand1.Connection = this.sqlConnection1;
			// 
			// sqlConnection1
			// 
			this.sqlConnection1.ConnectionString = "workstation id=GUL11;packet size=4096;user id=sa;data source=\".\";persist security" +
				" info=True;initial catalog=stores;password=sa";
			// 
			// ds31
			// 
			this.ds31.DataSetName = "ds3";
			this.ds31.Locale = new System.Globalization.CultureInfo("en-US");
			this.Load += new System.EventHandler(this.Page_Load);
			((System.ComponentModel.ISupportInitialize)(this.ds31)).EndInit();

		}
		#endregion

		private void Button1_Click(object sender, System.EventArgs e)
		{
			//connecting to database
			SqlConnection con=new SqlConnection("server=.;uid=sa;pwd=sa;database=stores");
			SqlCommand cmd=new SqlCommand();
			cmd.Connection=con;
			//storing particular requested id into id variable
			int id=Convert.ToInt32(Request.QueryString["id"]);
		    //storing Session userid into uid type integer
			int uid=Convert.ToInt32(Session["uid"]);
			cmd.CommandText="select req_quant from stores_request_tb  where req_id="+id+"";
			con.Open();
			//storing requested quantity into quant_request variable
			int quant_request=Convert.ToInt32(cmd.ExecuteScalar());

			
			
			cmd.CommandText="select quant_available from stores_stock_tb where pk_stock_mat_name in (select fk_request_login_mat_name from stores_request_tb where req_id="+id+")";
			cmd.Connection=con;
				//storing available quantity into quant_available variable
			int quant_available=Convert.ToInt32(cmd.ExecuteScalar());
			
			string accept;
			//string accepted stored into accept variable
			accept=Convert.ToString("accepted");
			
			string reject;
			//string Rejected  stored into reject variable
			reject=Convert.ToString("rejected");
			
			if(quant_request<quant_available)
			{
				
				cmd.CommandText="update stores_request_tb set req_status='"+accept+"',issued_date=getdate() where req_id="+id+"";
				cmd.ExecuteNonQuery();
			
				cmd.CommandText="update stores_stock_tb set quant_available=(select quant_available from stores_stock_tb where pk_stock_mat_name in (select fk_request_login_mat_name from stores_request_tb where req_id="+id+"))-(select req_quant from stores_request_tb where req_id="+id+") where pk_stock_mat_name=(select fk_request_login_mat_name from stores_request_tb where req_id="+id+")";
				cmd.ExecuteNonQuery();
				
				dg1.Visible=false;
				Button1.Visible=false;
				Button2.Visible=false;
				Lblmsg.Visible=true;
			}
			else
			{
				lblErrorMessage.Text="Requested Quantity is Graeter than the Available Quantity";
				return;
			}

		}

		private void Button2_Click(object sender, System.EventArgs e)
		{
			SqlConnection con=new SqlConnection("server=.;uid=sa;pwd=sa;database=stores");
			SqlCommand cmd=new SqlCommand();
			cmd.Connection=con;
			string accept;
			con.Open();
			accept=Convert.ToString("Accepted");
			con.Close();
			string reject;
			con.Open();
			//string Rejected  stored into reject variable
			reject=Convert.ToString("Rejected");
			con.Close();
			int id=Convert.ToInt32(Request.QueryString["id"]);
			int uid=Convert.ToInt32(Session["uid"]);
			con.Open();
			cmd.CommandText="update stores_request_tb set req_status='"+reject+"' where req_id="+id+"";
			cmd.ExecuteNonQuery();
			con.Close();
			dg1.Visible=false;
			Button1.Visible=false;
			Button2.Visible=false;
			Lblmsg.Visible=true;
		}
	}
}

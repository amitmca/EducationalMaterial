using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;
namespace group_16
{
	/// <summary>
	/// Summary description for WebForm9.
	/// </summary>
	public class WebForm9 : System.Web.UI.Page
	{
		protected System.Web.UI.WebControls.DataGrid dg1;
		protected System.Web.UI.WebControls.Label Label1;
	
		protected System.Data.SqlClient.SqlDataAdapter ada1;
		protected System.Data.SqlClient.SqlCommand sqlSelectCommand1;
		protected System.Data.SqlClient.SqlConnection sqlConnection1;
		protected group16.ds11 ds111;
		protected System.Web.UI.WebControls.Label Label2;
		//connecting to database
		string conStr="server=.;database=stores;uid=sa;pwd=sa";
		SqlDataAdapter Sqlda;
		DataSet DS;
	
		private void Page_Load(object sender, System.EventArgs e)
		{
			if(!Page.IsPostBack)
			{
				//storing Session userid into uid type integer
				int uid=Convert.ToInt32(Session["uid"]);
				Sqlda=new SqlDataAdapter("SELECT stores_request_tb.req_id As RequestId, stores_request_tb.fk_request_login_mat_name As Material_Name, stores_request_tb.req_quant As Issued_Quantity, stores_request_tb.req_date As Request_date, stores_request_tb.req_status As Req_Status, stores_request_tb.issued_date as Issued_Date, stores_suppliers_tb.sup_name As Supplier FROM    stores_request_tb CROSS JOIN   stores_suppliers_tb where fk_request_login_emp_id="+uid+" and stores_request_tb.fk_request_login_mat_name= stores_suppliers_tb.fk_suppliers_stock_mat_name and req_status='accepted' or req_status='Rejected'",conStr);
				DS=new DataSet();
				Sqlda.Fill(DS,"tmptable");
				dg1.DataSource=DS.Tables[0];
				dg1.DataBind();
			}// Put user code to initialize the page here
		}

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.ada1 = new System.Data.SqlClient.SqlDataAdapter();
			this.sqlSelectCommand1 = new System.Data.SqlClient.SqlCommand();
			this.sqlConnection1 = new System.Data.SqlClient.SqlConnection();
			this.ds111 = new group16.ds11();
			((System.ComponentModel.ISupportInitialize)(this.ds111)).BeginInit();
			this.dg1.PageIndexChanged += new System.Web.UI.WebControls.DataGridPageChangedEventHandler(this.dg1_PageIndexChanged);
			// 
			// ada1
			// 
			this.ada1.SelectCommand = this.sqlSelectCommand1;
			this.ada1.TableMappings.AddRange(new System.Data.Common.DataTableMapping[] {
																						   new System.Data.Common.DataTableMapping("Table", "stores_suppliers_tb", new System.Data.Common.DataColumnMapping[] {
																																																				  new System.Data.Common.DataColumnMapping("req_id", "req_id"),
																																																				  new System.Data.Common.DataColumnMapping("fk_request_login_mat_name", "fk_request_login_mat_name"),
																																																				  new System.Data.Common.DataColumnMapping("req_quant", "req_quant"),
																																																				  new System.Data.Common.DataColumnMapping("req_date", "req_date"),
																																																				  new System.Data.Common.DataColumnMapping("req_status", "req_status"),
																																																				  new System.Data.Common.DataColumnMapping("issued_date", "issued_date"),
																																																				  new System.Data.Common.DataColumnMapping("sup_name", "sup_name"),
																																																				  new System.Data.Common.DataColumnMapping("pk_suppliers_sup_id", "pk_suppliers_sup_id")})});
			// 
			// sqlSelectCommand1
			// 
			this.sqlSelectCommand1.CommandText = @"SELECT stores_request_tb.req_id, stores_request_tb.fk_request_login_mat_name, stores_request_tb.req_quant, stores_request_tb.req_date, stores_request_tb.req_status, stores_request_tb.issued_date, stores_suppliers_tb.sup_name, stores_suppliers_tb.pk_suppliers_sup_id FROM stores_suppliers_tb CROSS JOIN stores_request_tb";
			this.sqlSelectCommand1.Connection = this.sqlConnection1;
			// 
			// sqlConnection1
			// 
			this.sqlConnection1.ConnectionString = "workstation id=GUL11;packet size=4096;user id=sa;data source=\".\";persist security" +
				" info=True;initial catalog=stores;password=sa";
			// 
			// ds111
			// 
			this.ds111.DataSetName = "ds11";
			this.ds111.Locale = new System.Globalization.CultureInfo("en-US");
			this.Load += new System.EventHandler(this.Page_Load);
			((System.ComponentModel.ISupportInitialize)(this.ds111)).EndInit();

		}
		#endregion

		private void dg1_PageIndexChanged(object source, System.Web.UI.WebControls.DataGridPageChangedEventArgs e)
		{
			//appearing details page by page
			dg1.CurrentPageIndex=e.NewPageIndex;
			int uid=Convert.ToInt32(Session["uid"]);
			Sqlda=new SqlDataAdapter("SELECT stores_request_tb.req_id As RequestId, stores_request_tb.fk_request_login_mat_name As Material_Name, stores_request_tb.req_quant As Issued_Quantity, stores_request_tb.req_date As Request_date, stores_request_tb.req_status As Req_Status, stores_request_tb.issued_date as Issued_Date, stores_suppliers_tb.sup_name As Supplier FROM    stores_request_tb CROSS JOIN   stores_suppliers_tb where fk_request_login_emp_id="+uid+" and stores_request_tb.fk_request_login_mat_name= stores_suppliers_tb.fk_suppliers_stock_mat_name and req_status='accepted' or req_status='Rejected'",conStr);
			DS=new DataSet();
			Sqlda.Fill(DS,"tmptable");
			dg1.DataSource=DS.Tables[0];
			dg1.DataSource=DS;
			//binding the data into datagrid
			dg1.DataBind();
		}
	}
}

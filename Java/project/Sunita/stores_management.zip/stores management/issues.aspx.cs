using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;

namespace group16
{
	/// <summary>
	/// Summary description for issues.
	/// </summary>
	public class issues : System.Web.UI.Page
	{
		protected System.Data.SqlClient.SqlCommand sqlSelectCommand1;
		protected System.Data.SqlClient.SqlCommand sqlInsertCommand1;
		protected System.Data.SqlClient.SqlConnection sqlConnection1;
		protected System.Web.UI.WebControls.DataGrid dg1;
		protected System.Data.SqlClient.SqlDataAdapter sda1;
		protected group16.ds6 ds61;
		protected System.Web.UI.WebControls.Label Label1;
		SqlDataAdapter Sqlda;
		DataSet DS;
		string conStr="server=.;database=stores;uid=sa;pwd=sa";
	
		private void Page_Load(object sender, System.EventArgs e)
		{
			if(!Page.IsPostBack)
			{
				
				Sqlda=new SqlDataAdapter("SELECT fk_request_login_mat_name AS Material_Name,req_quant AS Quantity_Req,req_status AS Requested_Status,issued_date AS Issued_Date, req_date AS Requested_Date, fk_request_login_emp_id AS Employee_Id,req_id AS Request_ID FROM stores_request_tb where req_status='accepted'",conStr);
				DS=new DataSet();
				Sqlda.Fill(DS,"tmptable");
				dg1.DataSource=DS.Tables[0];
				dg1.DataBind();
			}
		}

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.sda1 = new System.Data.SqlClient.SqlDataAdapter();
			this.sqlInsertCommand1 = new System.Data.SqlClient.SqlCommand();
			this.sqlConnection1 = new System.Data.SqlClient.SqlConnection();
			this.sqlSelectCommand1 = new System.Data.SqlClient.SqlCommand();
			this.ds61 = new group16.ds6();
			((System.ComponentModel.ISupportInitialize)(this.ds61)).BeginInit();
			this.dg1.PageIndexChanged += new System.Web.UI.WebControls.DataGridPageChangedEventHandler(this.dg1_PageIndexChanged);
			// 
			// sda1
			// 
			this.sda1.InsertCommand = this.sqlInsertCommand1;
			this.sda1.SelectCommand = this.sqlSelectCommand1;
			this.sda1.TableMappings.AddRange(new System.Data.Common.DataTableMapping[] {
																						   new System.Data.Common.DataTableMapping("Table", "stores_request_tb", new System.Data.Common.DataColumnMapping[] {
																																																				new System.Data.Common.DataColumnMapping("Expr2", "Expr2"),
																																																				new System.Data.Common.DataColumnMapping("Expr3", "Expr3"),
																																																				new System.Data.Common.DataColumnMapping("Expr4", "Expr4"),
																																																				new System.Data.Common.DataColumnMapping("Expr5", "Expr5"),
																																																				new System.Data.Common.DataColumnMapping("Expr6", "Expr6"),
																																																				new System.Data.Common.DataColumnMapping("Expr7", "Expr7"),
																																																				new System.Data.Common.DataColumnMapping("Expr1", "Expr1")})});
			// 
			// sqlInsertCommand1
			// 
			this.sqlInsertCommand1.CommandText = @"INSERT INTO stores_request_tb(fk_request_login_mat_name, req_quant, req_status, issued_date, req_date, fk_request_login_emp_id) VALUES (@fk_request_login_mat_name, @req_quant, @req_status, @issued_date, @req_date, @fk_request_login_emp_id); SELECT fk_request_login_mat_name AS Expr2, req_quant AS Expr3, req_status AS Expr4, issued_date AS Expr5, req_date AS Expr6, fk_request_login_emp_id AS Expr7, req_id AS Expr1 FROM stores_request_tb";
			this.sqlInsertCommand1.Connection = this.sqlConnection1;
			this.sqlInsertCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@fk_request_login_mat_name", System.Data.SqlDbType.VarChar, 20, "Expr2"));
			this.sqlInsertCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@req_quant", System.Data.SqlDbType.Int, 4, "Expr3"));
			this.sqlInsertCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@req_status", System.Data.SqlDbType.VarChar, 20, "Expr4"));
			this.sqlInsertCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@issued_date", System.Data.SqlDbType.DateTime, 8, "Expr5"));
			this.sqlInsertCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@req_date", System.Data.SqlDbType.DateTime, 8, "Expr6"));
			this.sqlInsertCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@fk_request_login_emp_id", System.Data.SqlDbType.Int, 4, "Expr7"));
			// 
			// sqlConnection1
			// 
			this.sqlConnection1.ConnectionString = "workstation id=GUL11;packet size=4096;user id=sa;data source=\".\";persist security" +
				" info=True;initial catalog=stores;password=sa";
			// 
			// sqlSelectCommand1
			// 
			this.sqlSelectCommand1.CommandText = "SELECT fk_request_login_mat_name AS Expr2, req_quant AS Expr3, req_status AS Expr" +
				"4, issued_date AS Expr5, req_date AS Expr6, fk_request_login_emp_id AS Expr7, re" +
				"q_id AS Expr1 FROM stores_request_tb";
			this.sqlSelectCommand1.Connection = this.sqlConnection1;
			// 
			// ds61
			// 
			this.ds61.DataSetName = "ds6";
			this.ds61.Locale = new System.Globalization.CultureInfo("en-US");
			this.Load += new System.EventHandler(this.Page_Load);
			((System.ComponentModel.ISupportInitialize)(this.ds61)).EndInit();

		}
		#endregion

		private void dg1_PageIndexChanged(object source, System.Web.UI.WebControls.DataGridPageChangedEventArgs e)
		{
			dg1.CurrentPageIndex=e.NewPageIndex;
			Sqlda=new SqlDataAdapter("SELECT fk_request_login_mat_name AS Material_Name,req_quant AS Quantity_Req,req_status AS Requested_Status,issued_date AS Issued_Date, req_date AS Requested_Date, fk_request_login_emp_id AS Employee_Id,req_id AS Request_ID FROM stores_request_tb where req_status='accepted'",conStr);
			DS=new DataSet();
			Sqlda.Fill(DS,"tmptable");
			dg1.DataSource=DS.Tables[0];
			dg1.DataSource=DS;
			dg1.DataBind();
		}
	}
}

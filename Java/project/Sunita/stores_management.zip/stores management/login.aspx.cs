using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;

namespace group_16
{
	/// <summary>
	/// Summary description for WebForm1.
	/// </summary>
	public class WebForm1 : System.Web.UI.Page
	{
		protected System.Web.UI.WebControls.Label Label1;
		protected System.Web.UI.WebControls.TextBox TextBox1;
		protected System.Web.UI.WebControls.Label Label2;
		protected System.Web.UI.WebControls.TextBox TextBox2;
		protected System.Web.UI.WebControls.Label Label3;
		
		protected System.Web.UI.WebControls.RequiredFieldValidator RequiredFieldValidator1;
		protected System.Web.UI.WebControls.RequiredFieldValidator RequiredFieldValidator2;
		protected System.Web.UI.WebControls.Button Button1;
		string cmdText="select * from stores_login_tb";
		protected System.Web.UI.WebControls.Label lblmsg;
		protected System.Web.UI.WebControls.RegularExpressionValidator RegularExpressionValidator1;
		//connecting to database
		string conStr="server=.;database=stores;uid=sa;pwd=sa";
		SqlConnection SqlCon;
		SqlCommand SqlCmd;
		SqlDataReader sdr;
	     
		private void Page_Load(object sender, System.EventArgs e)
		{
			SqlCon = new SqlConnection(conStr);
			SqlCmd = new SqlCommand(cmdText,SqlCon);
			// Put user code to initialize the page here
		}
		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.Button1.Click += new System.EventHandler(this.Button1_Click);
			this.TextBox1.TextChanged += new System.EventHandler(this.TextBox1_TextChanged);
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion
		

		private void Button1_Click(object sender, System.EventArgs e)
		{
			SqlCon.Open();
			sdr=SqlCmd.ExecuteReader();
			//two types of users staff and adminstrator
			while(sdr.Read())
			{


				//if admin userid and password correct then enter into this loop
				if((Convert.ToInt32(TextBox1.Text))==1010 && TextBox2.Text.Equals("wipro"))
				{
					//opening new page it contains all staff requests made by staff
					Response.Redirect("frameset2.htm");
				}


				//if staff userid and password correct staff enter into frame1.htm page here he can send his requests
				else if(Convert.ToInt32(TextBox1.Text)==sdr.GetInt32(0) && TextBox2.Text.Equals(sdr[1]))
				{
					Session["uid"]=Convert.ToInt32(TextBox1.Text);
					Response.Redirect("Frameset1.htm");
					
				}				
				
			}
			//if userid/password or both incorrect then shows the following messege
			SqlCon.Close();						
					lblmsg.Text="Invalid UserId or Password";
					lblmsg.Visible=true;				
				
		}

		private void TextBox1_TextChanged(object sender, System.EventArgs e)
		{
		
		}

		private void TextBox2_TextChanged(object sender, System.EventArgs e)
		{
		
		}

		private void btnSubmit_Click(object sender, System.EventArgs e)
		{
			SqlCon.Open();
			sdr=SqlCmd.ExecuteReader();
			while(sdr.Read())
			{
				if((Convert.ToInt32(TextBox1.Text))==1010 && TextBox2.Text.Equals("wipro"))
				{
					Response.Redirect("frameset2.htm");
				}

				else if(Convert.ToInt32(TextBox1.Text)==sdr.GetInt32(0) && TextBox2.Text.Equals(sdr[1]))
				{
					Response.Redirect("Frameset1.htm");
				}
				else
					Label1.Text="Invalid UserName and Password";
			}
			SqlCon.Close();
		}
	}
}

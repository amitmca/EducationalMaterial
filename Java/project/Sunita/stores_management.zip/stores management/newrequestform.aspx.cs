using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;
namespace group_16
{
	
	public class WebForm3 : System.Web.UI.Page
	{
		protected System.Web.UI.WebControls.Button Button1;
		
		protected System.Web.UI.WebControls.DropDownList ddlmatname;
		protected System.Data.SqlClient.SqlCommand sqlSelectCommand1;
		protected System.Data.SqlClient.SqlCommand sqlInsertCommand1;
		protected System.Data.SqlClient.SqlCommand sqlUpdateCommand1;
		protected System.Data.SqlClient.SqlCommand sqlDeleteCommand1;
		protected System.Data.SqlClient.SqlConnection sqlConnection1;
		protected group16.ds ds1;
		protected System.Web.UI.WebControls.Label lblquant;
		protected System.Web.UI.WebControls.TextBox txtquant;
		protected System.Web.UI.WebControls.Label Lblmsg1;
		protected System.Web.UI.WebControls.Label Lblmsg3;
		protected System.Web.UI.WebControls.Label Lblmsg2;
		protected System.Web.UI.WebControls.RegularExpressionValidator rev1;
		protected System.Web.UI.WebControls.RequiredFieldValidator RequiredFieldValidator1;
		protected System.Data.SqlClient.SqlDataAdapter da1;
		SqlCommand cmd;
		SqlDataAdapter da;
		//connecting to database
		private void Page_Load(object sender, System.EventArgs e)
		{
			da1.Fill(ds1);
			if(!Page.IsPostBack)
			{
				//binding all dropdownlist elements
				ddlmatname.DataBind();
			}
		}

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.da1 = new System.Data.SqlClient.SqlDataAdapter();
			this.sqlDeleteCommand1 = new System.Data.SqlClient.SqlCommand();
			this.sqlConnection1 = new System.Data.SqlClient.SqlConnection();
			this.sqlInsertCommand1 = new System.Data.SqlClient.SqlCommand();
			this.sqlSelectCommand1 = new System.Data.SqlClient.SqlCommand();
			this.sqlUpdateCommand1 = new System.Data.SqlClient.SqlCommand();
			this.ds1 = new group16.ds();
			((System.ComponentModel.ISupportInitialize)(this.ds1)).BeginInit();
			this.ddlmatname.SelectedIndexChanged += new System.EventHandler(this.DropDownList1_SelectedIndexChanged);
			this.Button1.Click += new System.EventHandler(this.Button1_Click);
			// 
			// da1
			// 
			this.da1.DeleteCommand = this.sqlDeleteCommand1;
			this.da1.InsertCommand = this.sqlInsertCommand1;
			this.da1.SelectCommand = this.sqlSelectCommand1;
			this.da1.TableMappings.AddRange(new System.Data.Common.DataTableMapping[] {
																						  new System.Data.Common.DataTableMapping("Table", "stores_stock_tb", new System.Data.Common.DataColumnMapping[] {
																																																			 new System.Data.Common.DataColumnMapping("pk_stock_mat_name", "pk_stock_mat_name")})});
			this.da1.UpdateCommand = this.sqlUpdateCommand1;
			// 
			// sqlDeleteCommand1
			// 
			this.sqlDeleteCommand1.CommandText = "DELETE FROM stores_stock_tb WHERE (pk_stock_mat_name = @Original_pk_stock_mat_nam" +
				"e)";
			this.sqlDeleteCommand1.Connection = this.sqlConnection1;
			this.sqlDeleteCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Original_pk_stock_mat_name", System.Data.SqlDbType.VarChar, 20, System.Data.ParameterDirection.Input, false, ((System.Byte)(0)), ((System.Byte)(0)), "pk_stock_mat_name", System.Data.DataRowVersion.Original, null));
			// 
			// sqlConnection1
			// 
			this.sqlConnection1.ConnectionString = "workstation id=GUL11;packet size=4096;user id=sa;data source=\".\";persist security" +
				" info=True;initial catalog=stores;password=sa";
			// 
			// sqlInsertCommand1
			// 
			this.sqlInsertCommand1.CommandText = "INSERT INTO stores_stock_tb(pk_stock_mat_name) VALUES (@pk_stock_mat_name); SELEC" +
				"T pk_stock_mat_name FROM stores_stock_tb WHERE (pk_stock_mat_name = @pk_stock_ma" +
				"t_name)";
			this.sqlInsertCommand1.Connection = this.sqlConnection1;
			this.sqlInsertCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@pk_stock_mat_name", System.Data.SqlDbType.VarChar, 20, "pk_stock_mat_name"));
			// 
			// sqlSelectCommand1
			// 
			this.sqlSelectCommand1.CommandText = "SELECT pk_stock_mat_name FROM stores_stock_tb";
			this.sqlSelectCommand1.Connection = this.sqlConnection1;
			// 
			// sqlUpdateCommand1
			// 
			this.sqlUpdateCommand1.CommandText = "UPDATE stores_stock_tb SET pk_stock_mat_name = @pk_stock_mat_name WHERE (pk_stock" +
				"_mat_name = @Original_pk_stock_mat_name); SELECT pk_stock_mat_name FROM stores_s" +
				"tock_tb WHERE (pk_stock_mat_name = @pk_stock_mat_name)";
			this.sqlUpdateCommand1.Connection = this.sqlConnection1;
			this.sqlUpdateCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@pk_stock_mat_name", System.Data.SqlDbType.VarChar, 20, "pk_stock_mat_name"));
			this.sqlUpdateCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Original_pk_stock_mat_name", System.Data.SqlDbType.VarChar, 20, System.Data.ParameterDirection.Input, false, ((System.Byte)(0)), ((System.Byte)(0)), "pk_stock_mat_name", System.Data.DataRowVersion.Original, null));
			// 
			// ds1
			// 
			this.ds1.DataSetName = "ds";
			this.ds1.Locale = new System.Globalization.CultureInfo("en-US");
			this.Load += new System.EventHandler(this.Page_Load);
			((System.ComponentModel.ISupportInitialize)(this.ds1)).EndInit();

		}
		#endregion
				
		private void Button1_Click(object sender, System.EventArgs e)
		{
			SqlConnection con=new SqlConnection("server=.;uid=sa;pwd=sa;database=stores");
			//putting selected dropdownlist value into matname
			string matname=Convert.ToString(ddlmatname.SelectedValue);
			SqlCommand cmd=new SqlCommand();
			cmd.Connection=con;
			int quantity;
			//putting your entered textbox quantity into quantity variable
			quantity=Convert.ToInt32(txtquant.Text);
			//storing Session userid into uid type integer
			int uid=Convert.ToInt32(Session["uid"]);
			//putting the string name into reqstatus variable
			string reqstatus=Convert.ToString("requested");
			con.Open();
			cmd.CommandText="insert into stores_request_tb values("+uid+",'"+matname+"',"+quantity+",'"+System.DateTime.Now +"','"+reqstatus+"','"+ "')";
			int q=cmd.ExecuteNonQuery();
			con.Close();
			//after  button  clicking labelmessge appeared on the present screen and remaining components visibility false
			Button1.Visible=false;
			Lblmsg1.Visible=true;
			Lblmsg2.Visible=false;
			Lblmsg3.Visible=false;
			ddlmatname.Visible=false;
			txtquant.Visible=false;
			lblquant.Visible=false;
		}

		private void DropDownList1_SelectedIndexChanged(object sender, System.EventArgs e)
		{
				string matname=Convert.ToString(ddlmatname.SelectedValue);
		}

	

		private void Button2_Click(object sender, System.EventArgs e)
		{
			//Calendar.Visible=true;
		}
	}
}

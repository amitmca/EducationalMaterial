using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;

namespace group16
{
	/// <summary>
	/// Summary description for reject.
	/// </summary>
	public class reject : System.Web.UI.Page
	{
		protected System.Web.UI.WebControls.DataGrid dg1;
		protected System.Data.SqlClient.SqlDataAdapter sda1;
		protected System.Data.SqlClient.SqlCommand sqlSelectCommand1;
		protected System.Data.SqlClient.SqlCommand sqlInsertCommand1;
		protected System.Data.SqlClient.SqlConnection sqlConnection1;
		protected group16.ds12 ds121;
		protected System.Web.UI.WebControls.Label Label1;
		//connecting to database
		SqlDataAdapter Sqlda;
		DataSet DS;
		string conStr="server=.;database=stores;uid=sa;pwd=sa";
		
	
		private void Page_Load(object sender, System.EventArgs e)
		{
			// Put user code to initialize the page here
			if(!Page.IsPostBack)
			{
				//getting values from tables and bind into datagrid
				Sqlda=new SqlDataAdapter("SELECT fk_request_login_mat_name AS Material_Name,req_quant AS Quantity_Req,req_status AS Requested_Status,issued_date AS Issued_Date, req_date AS Requested_Date, fk_request_login_emp_id AS Employee_Id,req_id AS Request_ID FROM stores_request_tb where req_status='Rejected'",conStr);
				DS=new DataSet();
				Sqlda.Fill(DS,"tmptable");
				dg1.DataSource=DS.Tables[0];
				dg1.DataBind();
			}
		}

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.sda1 = new System.Data.SqlClient.SqlDataAdapter();
			this.sqlSelectCommand1 = new System.Data.SqlClient.SqlCommand();
			this.sqlInsertCommand1 = new System.Data.SqlClient.SqlCommand();
			this.sqlConnection1 = new System.Data.SqlClient.SqlConnection();
			this.ds121 = new group16.ds12();
			((System.ComponentModel.ISupportInitialize)(this.ds121)).BeginInit();
			this.dg1.PageIndexChanged += new System.Web.UI.WebControls.DataGridPageChangedEventHandler(this.dg1_PageIndexChanged);
			this.dg1.SelectedIndexChanged += new System.EventHandler(this.DataGrid1_SelectedIndexChanged);
			// 
			// sda1
			// 
			this.sda1.InsertCommand = this.sqlInsertCommand1;
			this.sda1.SelectCommand = this.sqlSelectCommand1;
			this.sda1.TableMappings.AddRange(new System.Data.Common.DataTableMapping[] {
																						   new System.Data.Common.DataTableMapping("Table", "stores_request_tb", new System.Data.Common.DataColumnMapping[] {
																																																				new System.Data.Common.DataColumnMapping("Material_Name", "Material_Name"),
																																																				new System.Data.Common.DataColumnMapping("Quantity_Req", "Quantity_Req"),
																																																				new System.Data.Common.DataColumnMapping("Requested_Status", "Requested_Status"),
																																																				new System.Data.Common.DataColumnMapping("Issued_Date", "Issued_Date"),
																																																				new System.Data.Common.DataColumnMapping("Requested_Date", "Requested_Date"),
																																																				new System.Data.Common.DataColumnMapping("Employee_Id", "Employee_Id"),
																																																				new System.Data.Common.DataColumnMapping("Request_ID", "Request_ID")})});
			// 
			// sqlSelectCommand1
			// 
			this.sqlSelectCommand1.CommandText = "SELECT fk_request_login_mat_name AS Material_Name, req_quant AS Quantity_Req, req" +
				"_status AS Requested_Status, issued_date AS Issued_Date, req_date AS Requested_D" +
				"ate, fk_request_login_emp_id AS Employee_Id, req_id AS Request_ID FROM stores_re" +
				"quest_tb";
			this.sqlSelectCommand1.Connection = this.sqlConnection1;
			// 
			// sqlInsertCommand1
			// 
			this.sqlInsertCommand1.CommandText = @"INSERT INTO stores_request_tb(fk_request_login_mat_name, req_quant, req_status, issued_date, req_date, fk_request_login_emp_id) VALUES (@fk_request_login_mat_name, @req_quant, @req_status, @issued_date, @req_date, @fk_request_login_emp_id); SELECT fk_request_login_mat_name AS Material_Name, req_quant AS Quantity_Req, req_status AS Requested_Status, issued_date AS Issued_Date, req_date AS Requested_Date, fk_request_login_emp_id AS Employee_Id, req_id AS Request_ID FROM stores_request_tb";
			this.sqlInsertCommand1.Connection = this.sqlConnection1;
			this.sqlInsertCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@fk_request_login_mat_name", System.Data.SqlDbType.VarChar, 20, "Material_Name"));
			this.sqlInsertCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@req_quant", System.Data.SqlDbType.Int, 4, "Quantity_Req"));
			this.sqlInsertCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@req_status", System.Data.SqlDbType.VarChar, 20, "Requested_Status"));
			this.sqlInsertCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@issued_date", System.Data.SqlDbType.DateTime, 8, "Issued_Date"));
			this.sqlInsertCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@req_date", System.Data.SqlDbType.DateTime, 8, "Requested_Date"));
			this.sqlInsertCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@fk_request_login_emp_id", System.Data.SqlDbType.Int, 4, "Employee_Id"));
			// 
			// sqlConnection1
			// 
			this.sqlConnection1.ConnectionString = "workstation id=GUL11;packet size=4096;user id=sa;data source=\".\";persist security" +
				" info=True;initial catalog=stores;password=sa";
			// 
			// ds121
			// 
			this.ds121.DataSetName = "ds12";
			this.ds121.Locale = new System.Globalization.CultureInfo("en-US");
			this.Load += new System.EventHandler(this.Page_Load);
			((System.ComponentModel.ISupportInitialize)(this.ds121)).EndInit();

		}
		#endregion

		private void DataGrid1_SelectedIndexChanged(object sender, System.EventArgs e)
		{
		
		}

		private void dg1_PageIndexChanged(object source, System.Web.UI.WebControls.DataGridPageChangedEventArgs e)
		{
			//appearing data page by page
			dg1.CurrentPageIndex=e.NewPageIndex;
			Sqlda=new SqlDataAdapter("SELECT fk_request_login_mat_name AS Material_Name,req_quant AS Quantity_Req,req_status AS Requested_Status,issued_date AS Issued_Date, req_date AS Requested_Date, fk_request_login_emp_id AS Employee_Id,req_id AS Request_ID FROM stores_request_tb where req_status='Rejected'",conStr);
			DS=new DataSet();
			Sqlda.Fill(DS,"tmptable");
			dg1.DataSource=DS.Tables[0];
			dg1.DataSource=DS;
			//binding the data into datagrid
			dg1.DataBind();
		}
	}
}

using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;

namespace group16
{
	/// <summary>
	/// Summary description for supply2.
	/// </summary>
	public class supply2 : System.Web.UI.Page
	{
		protected System.Web.UI.WebControls.Button Button1;
		SqlCommand cmd;
		protected System.Data.SqlClient.SqlCommand sqlSelectCommand1;
		protected System.Data.SqlClient.SqlCommand sqlInsertCommand1;
		protected System.Data.SqlClient.SqlCommand sqlUpdateCommand1;
		protected System.Data.SqlClient.SqlCommand sqlDeleteCommand1;
		protected System.Data.SqlClient.SqlConnection sqlConnection1;
		protected System.Web.UI.WebControls.DropDownList Ddlsuppliers;
		protected System.Web.UI.WebControls.DataGrid dg1;
		protected System.Data.SqlClient.SqlDataAdapter da2;
		protected System.Web.UI.WebControls.TextBox Txtreqquant;
		protected System.Web.UI.WebControls.RegularExpressionValidator RegularExpressionValidator1;
		protected System.Web.UI.WebControls.Label Lblmsg;
		protected System.Web.UI.WebControls.Label Lbl1;
		protected System.Web.UI.WebControls.Label Lbl2;
		protected System.Web.UI.WebControls.RequiredFieldValidator RequiredFieldValidator1;
		protected group16.Ds5 ds51;
	
		private void Page_Load(object sender, System.EventArgs e)
		{
			da2.Fill(ds51);
			if(!Page.IsPostBack)
			{
				//binding the dropdownlist suppliers values
				Ddlsuppliers.DataBind();
			}
		}

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.da2 = new System.Data.SqlClient.SqlDataAdapter();
			this.sqlDeleteCommand1 = new System.Data.SqlClient.SqlCommand();
			this.sqlConnection1 = new System.Data.SqlClient.SqlConnection();
			this.sqlInsertCommand1 = new System.Data.SqlClient.SqlCommand();
			this.sqlSelectCommand1 = new System.Data.SqlClient.SqlCommand();
			this.sqlUpdateCommand1 = new System.Data.SqlClient.SqlCommand();
			this.ds51 = new group16.Ds5();
			((System.ComponentModel.ISupportInitialize)(this.ds51)).BeginInit();
			this.Ddlsuppliers.SelectedIndexChanged += new System.EventHandler(this.Ddlsuppliers_SelectedIndexChanged);
			this.Txtreqquant.TextChanged += new System.EventHandler(this.Txtreqruant_TextChanged);
			this.Button1.Click += new System.EventHandler(this.Button1_Click);
			this.dg1.SelectedIndexChanged += new System.EventHandler(this.DataGrid1_SelectedIndexChanged);
			// 
			// da2
			// 
			this.da2.DeleteCommand = this.sqlDeleteCommand1;
			this.da2.InsertCommand = this.sqlInsertCommand1;
			this.da2.SelectCommand = this.sqlSelectCommand1;
			this.da2.TableMappings.AddRange(new System.Data.Common.DataTableMapping[] {
																						  new System.Data.Common.DataTableMapping("Table", "stores_suppliers_tb", new System.Data.Common.DataColumnMapping[] {
																																																				 new System.Data.Common.DataColumnMapping("sup_name", "sup_name"),
																																																				 new System.Data.Common.DataColumnMapping("fk_suppliers_stock_mat_name", "fk_suppliers_stock_mat_name"),
																																																				 new System.Data.Common.DataColumnMapping("rate_per_unit", "rate_per_unit"),
																																																				 new System.Data.Common.DataColumnMapping("quant_avail", "quant_avail"),
																																																				 new System.Data.Common.DataColumnMapping("pk_suppliers_sup_id", "pk_suppliers_sup_id")})});
			this.da2.UpdateCommand = this.sqlUpdateCommand1;
			// 
			// sqlDeleteCommand1
			// 
			this.sqlDeleteCommand1.CommandText = @"DELETE FROM stores_suppliers_tb WHERE (pk_suppliers_sup_id = @Original_pk_suppliers_sup_id) AND (fk_suppliers_stock_mat_name = @Original_fk_suppliers_stock_mat_name OR @Original_fk_suppliers_stock_mat_name IS NULL AND fk_suppliers_stock_mat_name IS NULL) AND (quant_avail = @Original_quant_avail OR @Original_quant_avail IS NULL AND quant_avail IS NULL) AND (rate_per_unit = @Original_rate_per_unit OR @Original_rate_per_unit IS NULL AND rate_per_unit IS NULL) AND (sup_name = @Original_sup_name OR @Original_sup_name IS NULL AND sup_name IS NULL)";
			this.sqlDeleteCommand1.Connection = this.sqlConnection1;
			this.sqlDeleteCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Original_pk_suppliers_sup_id", System.Data.SqlDbType.Int, 4, System.Data.ParameterDirection.Input, false, ((System.Byte)(0)), ((System.Byte)(0)), "pk_suppliers_sup_id", System.Data.DataRowVersion.Original, null));
			this.sqlDeleteCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Original_fk_suppliers_stock_mat_name", System.Data.SqlDbType.VarChar, 20, System.Data.ParameterDirection.Input, false, ((System.Byte)(0)), ((System.Byte)(0)), "fk_suppliers_stock_mat_name", System.Data.DataRowVersion.Original, null));
			this.sqlDeleteCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Original_quant_avail", System.Data.SqlDbType.Int, 4, System.Data.ParameterDirection.Input, false, ((System.Byte)(0)), ((System.Byte)(0)), "quant_avail", System.Data.DataRowVersion.Original, null));
			this.sqlDeleteCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Original_rate_per_unit", System.Data.SqlDbType.Int, 4, System.Data.ParameterDirection.Input, false, ((System.Byte)(0)), ((System.Byte)(0)), "rate_per_unit", System.Data.DataRowVersion.Original, null));
			this.sqlDeleteCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Original_sup_name", System.Data.SqlDbType.VarChar, 20, System.Data.ParameterDirection.Input, false, ((System.Byte)(0)), ((System.Byte)(0)), "sup_name", System.Data.DataRowVersion.Original, null));
			// 
			// sqlConnection1
			// 
			this.sqlConnection1.ConnectionString = "workstation id=GUL11;packet size=4096;user id=sa;data source=\".\";persist security" +
				" info=True;initial catalog=stores;password=sa";
			// 
			// sqlInsertCommand1
			// 
			this.sqlInsertCommand1.CommandText = @"INSERT INTO stores_suppliers_tb(sup_name, fk_suppliers_stock_mat_name, rate_per_unit, quant_avail, pk_suppliers_sup_id) VALUES (@sup_name, @fk_suppliers_stock_mat_name, @rate_per_unit, @quant_avail, @pk_suppliers_sup_id); SELECT sup_name, fk_suppliers_stock_mat_name, rate_per_unit, quant_avail, pk_suppliers_sup_id FROM stores_suppliers_tb WHERE (pk_suppliers_sup_id = @pk_suppliers_sup_id)";
			this.sqlInsertCommand1.Connection = this.sqlConnection1;
			this.sqlInsertCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@sup_name", System.Data.SqlDbType.VarChar, 20, "sup_name"));
			this.sqlInsertCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@fk_suppliers_stock_mat_name", System.Data.SqlDbType.VarChar, 20, "fk_suppliers_stock_mat_name"));
			this.sqlInsertCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@rate_per_unit", System.Data.SqlDbType.Int, 4, "rate_per_unit"));
			this.sqlInsertCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@quant_avail", System.Data.SqlDbType.Int, 4, "quant_avail"));
			this.sqlInsertCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@pk_suppliers_sup_id", System.Data.SqlDbType.Int, 4, "pk_suppliers_sup_id"));
			// 
			// sqlSelectCommand1
			// 
			this.sqlSelectCommand1.CommandText = "SELECT sup_name, fk_suppliers_stock_mat_name, rate_per_unit, quant_avail, pk_supp" +
				"liers_sup_id FROM stores_suppliers_tb";
			this.sqlSelectCommand1.Connection = this.sqlConnection1;
			// 
			// sqlUpdateCommand1
			// 
			this.sqlUpdateCommand1.CommandText = @"UPDATE stores_suppliers_tb SET sup_name = @sup_name, fk_suppliers_stock_mat_name = @fk_suppliers_stock_mat_name, rate_per_unit = @rate_per_unit, quant_avail = @quant_avail, pk_suppliers_sup_id = @pk_suppliers_sup_id WHERE (pk_suppliers_sup_id = @Original_pk_suppliers_sup_id) AND (fk_suppliers_stock_mat_name = @Original_fk_suppliers_stock_mat_name OR @Original_fk_suppliers_stock_mat_name IS NULL AND fk_suppliers_stock_mat_name IS NULL) AND (quant_avail = @Original_quant_avail OR @Original_quant_avail IS NULL AND quant_avail IS NULL) AND (rate_per_unit = @Original_rate_per_unit OR @Original_rate_per_unit IS NULL AND rate_per_unit IS NULL) AND (sup_name = @Original_sup_name OR @Original_sup_name IS NULL AND sup_name IS NULL); SELECT sup_name, fk_suppliers_stock_mat_name, rate_per_unit, quant_avail, pk_suppliers_sup_id FROM stores_suppliers_tb WHERE (pk_suppliers_sup_id = @pk_suppliers_sup_id)";
			this.sqlUpdateCommand1.Connection = this.sqlConnection1;
			this.sqlUpdateCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@sup_name", System.Data.SqlDbType.VarChar, 20, "sup_name"));
			this.sqlUpdateCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@fk_suppliers_stock_mat_name", System.Data.SqlDbType.VarChar, 20, "fk_suppliers_stock_mat_name"));
			this.sqlUpdateCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@rate_per_unit", System.Data.SqlDbType.Int, 4, "rate_per_unit"));
			this.sqlUpdateCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@quant_avail", System.Data.SqlDbType.Int, 4, "quant_avail"));
			this.sqlUpdateCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@pk_suppliers_sup_id", System.Data.SqlDbType.Int, 4, "pk_suppliers_sup_id"));
			this.sqlUpdateCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Original_pk_suppliers_sup_id", System.Data.SqlDbType.Int, 4, System.Data.ParameterDirection.Input, false, ((System.Byte)(0)), ((System.Byte)(0)), "pk_suppliers_sup_id", System.Data.DataRowVersion.Original, null));
			this.sqlUpdateCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Original_fk_suppliers_stock_mat_name", System.Data.SqlDbType.VarChar, 20, System.Data.ParameterDirection.Input, false, ((System.Byte)(0)), ((System.Byte)(0)), "fk_suppliers_stock_mat_name", System.Data.DataRowVersion.Original, null));
			this.sqlUpdateCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Original_quant_avail", System.Data.SqlDbType.Int, 4, System.Data.ParameterDirection.Input, false, ((System.Byte)(0)), ((System.Byte)(0)), "quant_avail", System.Data.DataRowVersion.Original, null));
			this.sqlUpdateCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Original_rate_per_unit", System.Data.SqlDbType.Int, 4, System.Data.ParameterDirection.Input, false, ((System.Byte)(0)), ((System.Byte)(0)), "rate_per_unit", System.Data.DataRowVersion.Original, null));
			this.sqlUpdateCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Original_sup_name", System.Data.SqlDbType.VarChar, 20, System.Data.ParameterDirection.Input, false, ((System.Byte)(0)), ((System.Byte)(0)), "sup_name", System.Data.DataRowVersion.Original, null));
			// 
			// ds51
			// 
			this.ds51.DataSetName = "Ds5";
			this.ds51.Locale = new System.Globalization.CultureInfo("en-US");
			this.Load += new System.EventHandler(this.Page_Load);
			((System.ComponentModel.ISupportInitialize)(this.ds51)).EndInit();

		}
		#endregion

		private void Button1_Click(object sender, System.EventArgs e)
		{
			
			//connecting to database
			SqlConnection con=new SqlConnection("server=.;uid=sa;pwd=sa;database=stores");
			//putting the dropdownlistsuppliers selectd value into suppliers variable
			string suppliers=Convert.ToString(Ddlsuppliers.SelectedValue);
			SqlCommand cmd=new SqlCommand();
			cmd.Connection=con;
			int quantity;
			string matname;
			con.Open();
			cmd.CommandText="select fk_suppliers_stock_mat_name from stores_suppliers_tb where sup_name='"+suppliers+"'";
			//putting returned object of above query into matname variable
			matname=Convert.ToString(cmd.ExecuteScalar());
			con.Close();
			
			quantity=Convert.ToInt32(Txtreqquant.Text);
			int uid=Convert.ToInt32(Session["uid"]);
			con.Open();
			cmd.CommandText="update stores_stock_tb set quant_available=quant_available+"+quantity+" where pk_stock_mat_name='"+matname+"'";
			cmd.ExecuteNonQuery();
			con.Close();
			//after  button  clicking labelmessge appeared on the present screen and remaining components visibility false
			dg1.Visible=false;
			Button1.Visible=false;
			Lblmsg.Visible=true;
			Txtreqquant.Visible=false;
			Ddlsuppliers.Visible=false;
			Lbl1.Visible=false;
			Lbl2.Visible=false;

		}

		private void DataGrid1_SelectedIndexChanged(object sender, System.EventArgs e)
		{
			
		}

		private void Ddlsuppliers_SelectedIndexChanged(object sender, System.EventArgs e)
		{
			int uid;
			string mode;
			mode=Ddlsuppliers.SelectedItem.ToString();
			uid=Convert.ToInt32(Session["uid"]);
			SqlDataAdapter da1;
			SqlConnection con=new SqlConnection("server=.;uid=sa;pwd=sa;database=stores");
			DataSet ds1;
				
            	da1=new SqlDataAdapter( "select fk_suppliers_stock_mat_name,rate_per_unit,quant_avail from stores_suppliers_tb where sup_name='"+mode+"'",con);
				ds1=new DataSet();
				da1.Fill(ds1,"stores_suppliers_tb");
				dg1.DataSource=ds1;
				dg1.DataMember="stores_suppliers_tb";
				dg1.DataBind();
				dg1.Visible=true;
		   }

		private void Txtreqruant_TextChanged(object sender, System.EventArgs e)
		{
		
		}
	}
}

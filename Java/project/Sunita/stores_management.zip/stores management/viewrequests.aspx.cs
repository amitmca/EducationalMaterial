using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;

namespace group_16
{
	
	public class WebForm10 : System.Web.UI.Page
	{
		protected System.Web.UI.WebControls.DataGrid dg1;
		protected System.Data.SqlClient.SqlConnection sqlConnection1;
		protected System.Data.SqlClient.SqlDataAdapter da3;
		protected System.Data.SqlClient.SqlCommand sqlSelectCommand1;
		protected System.Data.SqlClient.SqlCommand sqlInsertCommand1;
		protected group16.ds1 ds11;
		protected System.Web.UI.WebControls.Label Label1;
        
		SqlDataAdapter Sqlda;
		DataSet DS;
     
	 

		private void Page_Load(object sender, System.EventArgs e)
		{

			if(!Page.IsPostBack)
			{
				string conStr="server=.;database=stores;uid=sa;pwd=sa";
				string request="requested";
				 //string request="requested";
		       string comStr="select req_id,fk_request_login_emp_id AS EmployeeID,fk_request_login_mat_name As MaterialName,req_quant As RequestedQuantity,req_date AS RequestedDate from stores_request_tb where req_status='"+request+"'";
				Sqlda=new SqlDataAdapter(comStr,conStr);
				DS=new DataSet();
				Sqlda.Fill(DS);
				dg1.DataSource=DS.Tables[0];
				dg1.DataBind();
				
			}
					
		}


		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.da3 = new System.Data.SqlClient.SqlDataAdapter();
			this.sqlInsertCommand1 = new System.Data.SqlClient.SqlCommand();
			this.sqlConnection1 = new System.Data.SqlClient.SqlConnection();
			this.sqlSelectCommand1 = new System.Data.SqlClient.SqlCommand();
			this.ds11 = new group16.ds1();
			((System.ComponentModel.ISupportInitialize)(this.ds11)).BeginInit();
			this.dg1.SelectedIndexChanged += new System.EventHandler(this.dg1_SelectedIndexChanged);
			// 
			// da3
			// 
			this.da3.InsertCommand = this.sqlInsertCommand1;
			this.da3.SelectCommand = this.sqlSelectCommand1;
			this.da3.TableMappings.AddRange(new System.Data.Common.DataTableMapping[] {
																						  new System.Data.Common.DataTableMapping("Table", "stores_request_tb", new System.Data.Common.DataColumnMapping[] {
																																																			   new System.Data.Common.DataColumnMapping("req_id", "req_id"),
																																																			   new System.Data.Common.DataColumnMapping("fk_request_login_emp_id", "fk_request_login_emp_id"),
																																																			   new System.Data.Common.DataColumnMapping("fk_request_login_mat_name", "fk_request_login_mat_name"),
																																																			   new System.Data.Common.DataColumnMapping("req_quant", "req_quant"),
																																																			   new System.Data.Common.DataColumnMapping("req_date", "req_date")})});
			// 
			// sqlInsertCommand1
			// 
			this.sqlInsertCommand1.CommandText = @"INSERT INTO stores_request_tb(fk_request_login_emp_id, fk_request_login_mat_name, req_quant, req_date) VALUES (@fk_request_login_emp_id, @fk_request_login_mat_name, @req_quant, @req_date); SELECT req_id, fk_request_login_emp_id, fk_request_login_mat_name, req_quant, req_date FROM stores_request_tb";
			this.sqlInsertCommand1.Connection = this.sqlConnection1;
			this.sqlInsertCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@fk_request_login_emp_id", System.Data.SqlDbType.Int, 4, "fk_request_login_emp_id"));
			this.sqlInsertCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@fk_request_login_mat_name", System.Data.SqlDbType.VarChar, 20, "fk_request_login_mat_name"));
			this.sqlInsertCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@req_quant", System.Data.SqlDbType.Int, 4, "req_quant"));
			this.sqlInsertCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@req_date", System.Data.SqlDbType.DateTime, 8, "req_date"));
			// 
			// sqlConnection1
			// 
			this.sqlConnection1.ConnectionString = "workstation id=GUL11;packet size=4096;user id=sa;data source=\".\";persist security" +
				" info=False;initial catalog=stores";
			// 
			// sqlSelectCommand1
			// 
			this.sqlSelectCommand1.CommandText = "SELECT req_id, fk_request_login_emp_id, fk_request_login_mat_name, req_quant, req" +
				"_date FROM stores_request_tb";
			this.sqlSelectCommand1.Connection = this.sqlConnection1;
			// 
			// ds11
			// 
			this.ds11.DataSetName = "ds1";
			this.ds11.Locale = new System.Globalization.CultureInfo("en-US");
			this.Load += new System.EventHandler(this.Page_Load);
			((System.ComponentModel.ISupportInitialize)(this.ds11)).EndInit();

		}
		#endregion

		private void dg1_SelectedIndexChanged(object sender, System.EventArgs e)
		{
		
		}
	}
}

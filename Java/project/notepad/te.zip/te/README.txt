This software has been made by Anuj Agrawal and has been redistributed for public benefit.
Any modification to the code is user's own risk. By downloading or installing the product you 
agree that any advantage or disadvantage, profit or loss from this code or the software is 
all your's and concerns nothing to me.
--------------------------------------------------------------------------------------------
Installation instructions:

(step 1 and 2 might already be done on your machine)

Step 1: Download and install the Java development kit (jdk1.5.0 or later).

step 2: Make jar files recognizable by the Operating System you use
	For windows:
		a) go to tools --> folder options -->file types.
		b) if jar files are not already listed create one.
		c) edit/change/create the open action of this file with the javaw.exe file 
	present in the jdk\bin directory.

	The open action would look something like this:
	"C:\Java\jdk1.4.0\bin\javaw.exe" -jar "%1"
	Of course, you will replace "C:\Java\jdk1.4.0\bin\javaw.exe" with whatever path is
 	correct on your machine.

Step 3: Download the necessary portion of the software(recommended) and unzip it to any 	
	suitable location on your machine.

Step 4: Double click on the RunEditor.jar file and there you go with happy Text Editing.
 
--------------------------------------------------------------------------------------------

Anuj Agrawal

for troubleshooting or feedback:

anuj@anujag.tk 
or
www.anujag.tk	



Thank you
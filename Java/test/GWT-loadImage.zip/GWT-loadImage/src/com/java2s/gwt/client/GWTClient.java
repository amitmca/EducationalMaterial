package com.java2s.gwt.client;

import com.google.gwt.core.client.EntryPoint;
import com.google.gwt.user.client.Window;
import com.google.gwt.user.client.ui.Button;
import com.google.gwt.user.client.ui.ClickListener;
import com.google.gwt.user.client.ui.RootPanel;
import com.google.gwt.user.client.ui.Widget;
import com.google.gwt.user.client.ui.DialogBox;
import com.google.gwt.user.client.ui.DockPanel;
import com.google.gwt.user.client.ui.HTML;
import com.google.gwt.user.client.ui.Image;

public class GWTClient implements EntryPoint {

  public void onModuleLoad() {
    Button b = new Button("Click me", new ClickListener() {
      public void onClick(Widget sender) {
         DialogBox dlg = new MyDialog();
         dlg.center();
      }
    });

    RootPanel.get().add(b);
  }
}

class MyDialog extends DialogBox implements ClickListener {
  public MyDialog() {
    setText("Sample DialogBox");

    Button closeButton = new Button("Close", this);
    HTML msg = new HTML("<center>A standard dialog box component.</center>",true);

    DockPanel dock = new DockPanel();
    dock.setSpacing(4);

    dock.add(closeButton, DockPanel.SOUTH);
    dock.add(msg, DockPanel.NORTH);
    dock.add(new Image("images/yourImage.jpg"), DockPanel.CENTER);

    dock.setCellHorizontalAlignment(closeButton, DockPanel.ALIGN_RIGHT);
    dock.setWidth("100%");
    setWidget(dock);
  }

  public void onClick(Widget sender) {
    hide();
  }
}
Imports System.Data
Imports System.Data.SqlClient
Imports CrystalDecisions.CrystalReports.Engine

Public Class Ched
    Inherits System.Windows.Forms.Form

    Private ServerName As String = "localhost"

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents CrystalReportViewer1 As CrystalDecisions.Windows.Forms.CrystalReportViewer
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.CrystalReportViewer1 = New CrystalDecisions.Windows.Forms.CrystalReportViewer
        Me.SuspendLayout()
        '
        'CrystalReportViewer1
        '
        Me.CrystalReportViewer1.ActiveViewIndex = -1
        Me.CrystalReportViewer1.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.CrystalReportViewer1.DisplayGroupTree = False
        Me.CrystalReportViewer1.Location = New System.Drawing.Point(0, 0)
        Me.CrystalReportViewer1.Name = "CrystalReportViewer1"
        Me.CrystalReportViewer1.ReportSource = Nothing
        Me.CrystalReportViewer1.ShowGroupTreeButton = False
        Me.CrystalReportViewer1.Size = New System.Drawing.Size(968, 600)
        Me.CrystalReportViewer1.TabIndex = 6
        '
        'Ched
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(968, 598)
        Me.Controls.Add(Me.CrystalReportViewer1)
        Me.Name = "Ched"
        Me.Text = "Ched Report"
        Me.WindowState = System.Windows.Forms.FormWindowState.Maximized
        Me.ResumeLayout(False)

    End Sub

#End Region

    Public Sub New(ByVal frmDialog As ChedDialog)
        Me.New()

        Dim rptChed As New ReportDocument

        Dim pvCollection As New CrystalDecisions.Shared.ParameterValues
        Dim pdvProgramID As New CrystalDecisions.Shared.ParameterDiscreteValue
        Dim pdvSchYr As New CrystalDecisions.Shared.ParameterDiscreteValue
        Dim pdvYear As New CrystalDecisions.Shared.ParameterDiscreteValue
        Dim pdvSection As New CrystalDecisions.Shared.ParameterDiscreteValue

        Dim tbCurrent As CrystalDecisions.CrystalReports.Engine.Table
        Dim tliCurrent As CrystalDecisions.Shared.TableLogOnInfo

        Try
            rptChed.Load("..\..\Reports\rptChed.rpt")

            For Each tbCurrent In rptChed.Database.Tables
                tliCurrent = tbCurrent.LogOnInfo
                With tliCurrent.ConnectionInfo
                    .ServerName = ServerName
                    .UserID = ""
                    .Password = ""
                    .DatabaseName = "EnrollSystem"
                End With
                tbCurrent.ApplyLogOnInfo(tliCurrent)
            Next tbCurrent

            pdvProgramID.Value = frmDialog.cboProgramID.SelectedValue.ToString
            pdvSchYr.Value = frmDialog.txtSchYr.Text
            pdvYear.Value = frmDialog.txtYear.Text
            pdvSection.Value = frmDialog.txtSection.Text

            pvCollection.Add(pdvProgramID)
            rptChed.DataDefinition.ParameterFields("@ProgramID").ApplyCurrentValues(pvCollection)

            pvCollection.Clear()
            pvCollection.Add(pdvSchYr)
            rptChed.DataDefinition.ParameterFields("@SchYr").ApplyCurrentValues(pvCollection)

            pvCollection.Clear()
            pvCollection.Add(pdvYear)
            rptChed.DataDefinition.ParameterFields("@Year").ApplyCurrentValues(pvCollection)


            pvCollection.Clear()
            pvCollection.Add(pdvSection)
            rptChed.DataDefinition.ParameterFields("@Section").ApplyCurrentValues(pvCollection)

            CrystalReportViewer1.ReportSource = rptChed

        Catch Exp As LoadSaveReportException
            MsgBox("Incorrect path for loading report.", _
                    MsgBoxStyle.Critical, "Load Report Error")

        Catch Exp As Exception
            MsgBox(Exp.Message, MsgBoxStyle.Critical, "General Error")
        End Try
    End Sub
End Class

﻿Public Class Courses

    Private Sub CourseBindingNavigatorSaveItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CourseBindingNavigatorSaveItem.Click
        Me.Validate()
        Me.CourseBindingSource.EndEdit()
        Me.TableAdapterManager.UpdateAll(Me.EnrollSystemDataSet)

    End Sub

    Private Sub Courses_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'TODO: This line of code loads data into the 'EnrollSystemDataSet.Course' table. You can move, or remove it, as needed.
        Me.CourseTableAdapter.Fill(Me.EnrollSystemDataSet.Course)

    End Sub
End Class
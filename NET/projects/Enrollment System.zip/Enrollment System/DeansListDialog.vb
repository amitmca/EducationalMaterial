Imports System.Data.SqlClient

Public Class DeansListDialog
    Inherits System.Windows.Forms.Form

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents txtPreview As System.Windows.Forms.Button
    Friend WithEvents btnCancel As System.Windows.Forms.Button
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents Panel2 As System.Windows.Forms.Panel
    Friend WithEvents cboSem As System.Windows.Forms.ComboBox
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents txtSchYr As System.Windows.Forms.TextBox
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.txtPreview = New System.Windows.Forms.Button
        Me.btnCancel = New System.Windows.Forms.Button
        Me.Panel1 = New System.Windows.Forms.Panel
        Me.Label6 = New System.Windows.Forms.Label
        Me.Panel2 = New System.Windows.Forms.Panel
        Me.Label3 = New System.Windows.Forms.Label
        Me.Label2 = New System.Windows.Forms.Label
        Me.txtSchYr = New System.Windows.Forms.TextBox
        Me.cboSem = New System.Windows.Forms.ComboBox
        Me.Panel1.SuspendLayout()
        Me.Panel2.SuspendLayout()
        Me.SuspendLayout()
        '
        'txtPreview
        '
        Me.txtPreview.Location = New System.Drawing.Point(104, 128)
        Me.txtPreview.Name = "txtPreview"
        Me.txtPreview.Size = New System.Drawing.Size(75, 23)
        Me.txtPreview.TabIndex = 10
        Me.txtPreview.Text = "Preview"
        '
        'btnCancel
        '
        Me.btnCancel.Location = New System.Drawing.Point(192, 128)
        Me.btnCancel.Name = "btnCancel"
        Me.btnCancel.Size = New System.Drawing.Size(75, 23)
        Me.btnCancel.TabIndex = 16
        Me.btnCancel.Text = "Cancel"
        '
        'Panel1
        '
        Me.Panel1.BackColor = System.Drawing.SystemColors.ControlDark
        Me.Panel1.Controls.Add(Me.Label6)
        Me.Panel1.Location = New System.Drawing.Point(16, 16)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(368, 40)
        Me.Panel1.TabIndex = 18
        '
        'Label6
        '
        Me.Label6.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label6.Location = New System.Drawing.Point(8, 8)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(312, 24)
        Me.Label6.TabIndex = 18
        Me.Label6.Text = "Dean's List Report"
        '
        'Panel2
        '
        Me.Panel2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Panel2.Controls.Add(Me.Label3)
        Me.Panel2.Controls.Add(Me.Label2)
        Me.Panel2.Controls.Add(Me.txtSchYr)
        Me.Panel2.Controls.Add(Me.cboSem)
        Me.Panel2.Controls.Add(Me.btnCancel)
        Me.Panel2.Controls.Add(Me.txtPreview)
        Me.Panel2.Location = New System.Drawing.Point(8, 8)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(384, 176)
        Me.Panel2.TabIndex = 19
        '
        'Label3
        '
        Me.Label3.Location = New System.Drawing.Point(72, 88)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(100, 23)
        Me.Label3.TabIndex = 99
        Me.Label3.Text = "Semester:"
        '
        'Label2
        '
        Me.Label2.Location = New System.Drawing.Point(72, 64)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(100, 23)
        Me.Label2.TabIndex = 98
        Me.Label2.Text = "School Year:"
        '
        'txtSchYr
        '
        Me.txtSchYr.Location = New System.Drawing.Point(184, 64)
        Me.txtSchYr.Name = "txtSchYr"
        Me.txtSchYr.Size = New System.Drawing.Size(104, 20)
        Me.txtSchYr.TabIndex = 97
        Me.txtSchYr.Text = "2008-2009"
        '
        'cboSem
        '
        Me.cboSem.Location = New System.Drawing.Point(184, 88)
        Me.cboSem.Name = "cboSem"
        Me.cboSem.Size = New System.Drawing.Size(104, 21)
        Me.cboSem.TabIndex = 95
        '
        'DeansListDialog
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(400, 192)
        Me.Controls.Add(Me.Panel1)
        Me.Controls.Add(Me.Panel2)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.Name = "DeansListDialog"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "EnrollListPerSectionDialog"
        Me.Panel1.ResumeLayout(False)
        Me.Panel2.ResumeLayout(False)
        Me.Panel2.PerformLayout()
        Me.ResumeLayout(False)

    End Sub

#End Region

    Private Sub txtPreview_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txtPreview.Click
        Dim frmReport As New DeansList(Me)

        If txtSchYr.Text = "" Or _
            cboSem.Text = "" Then

            MessageBox.Show("Please don't leave other field blank", "Error", MessageBoxButtons.OK, MessageBoxIcon.Information)
        Else
            frmReport.Show()
        End If
    End Sub

    Private Sub btnCancel_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnCancel.Click
        Me.Close()
    End Sub

    Private Sub EnrollListPerSectionDialog_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.Load
        With cboSem
            .Items.Add("1st")
            .Items.Add("2nd")
            .Items.Add("Summer")
        End With
    End Sub

    Private Sub NSTPEnrollmentDialog_Resize(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.Resize
        Me.WindowState = FormWindowState.Normal
    End Sub
End Class

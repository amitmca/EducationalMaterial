Imports System.Data.SqlClient

Public Class EnrollListPerSectionDialog
    Inherits System.Windows.Forms.Form

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents txtSection As System.Windows.Forms.TextBox
    Friend WithEvents txtYear As System.Windows.Forms.TextBox
    Friend WithEvents txtSchYr As System.Windows.Forms.TextBox
    Friend WithEvents txtPreview As System.Windows.Forms.Button
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents btnCancel As System.Windows.Forms.Button
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents Panel2 As System.Windows.Forms.Panel
    Friend WithEvents cboProgramID As System.Windows.Forms.ComboBox
    Friend WithEvents EnrollSystemDataSetBindingSource As System.Windows.Forms.BindingSource
    Friend WithEvents EnrollSystemDataSet As Enrollment_System.EnrollSystemDataSet
    Friend WithEvents ProgramBindingSource As System.Windows.Forms.BindingSource
    Friend WithEvents ProgramTableAdapter As Enrollment_System.EnrollSystemDataSetTableAdapters.ProgramTableAdapter
    Friend WithEvents cboSem As System.Windows.Forms.ComboBox
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container
        Me.txtSection = New System.Windows.Forms.TextBox
        Me.txtYear = New System.Windows.Forms.TextBox
        Me.txtSchYr = New System.Windows.Forms.TextBox
        Me.txtPreview = New System.Windows.Forms.Button
        Me.Label1 = New System.Windows.Forms.Label
        Me.Label2 = New System.Windows.Forms.Label
        Me.Label3 = New System.Windows.Forms.Label
        Me.Label4 = New System.Windows.Forms.Label
        Me.Label5 = New System.Windows.Forms.Label
        Me.btnCancel = New System.Windows.Forms.Button
        Me.Panel1 = New System.Windows.Forms.Panel
        Me.Label6 = New System.Windows.Forms.Label
        Me.Panel2 = New System.Windows.Forms.Panel
        Me.cboSem = New System.Windows.Forms.ComboBox
        Me.cboProgramID = New System.Windows.Forms.ComboBox
        Me.EnrollSystemDataSet = New Enrollment_System.EnrollSystemDataSet
        Me.EnrollSystemDataSetBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.ProgramBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.ProgramTableAdapter = New Enrollment_System.EnrollSystemDataSetTableAdapters.ProgramTableAdapter
        Me.Panel1.SuspendLayout()
        Me.Panel2.SuspendLayout()
        CType(Me.EnrollSystemDataSet, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.EnrollSystemDataSetBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.ProgramBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'txtSection
        '
        Me.txtSection.Location = New System.Drawing.Point(192, 160)
        Me.txtSection.Name = "txtSection"
        Me.txtSection.Size = New System.Drawing.Size(104, 20)
        Me.txtSection.TabIndex = 9
        Me.txtSection.Text = "a"
        '
        'txtYear
        '
        Me.txtYear.Location = New System.Drawing.Point(192, 136)
        Me.txtYear.Name = "txtYear"
        Me.txtYear.Size = New System.Drawing.Size(104, 20)
        Me.txtYear.TabIndex = 8
        Me.txtYear.Text = "1"
        '
        'txtSchYr
        '
        Me.txtSchYr.Location = New System.Drawing.Point(192, 88)
        Me.txtSchYr.Name = "txtSchYr"
        Me.txtSchYr.Size = New System.Drawing.Size(104, 20)
        Me.txtSchYr.TabIndex = 6
        Me.txtSchYr.Text = "2008-2009"
        '
        'txtPreview
        '
        Me.txtPreview.Location = New System.Drawing.Point(96, 192)
        Me.txtPreview.Name = "txtPreview"
        Me.txtPreview.Size = New System.Drawing.Size(75, 23)
        Me.txtPreview.TabIndex = 10
        Me.txtPreview.Text = "Preview"
        '
        'Label1
        '
        Me.Label1.Location = New System.Drawing.Point(80, 64)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(100, 23)
        Me.Label1.TabIndex = 11
        Me.Label1.Text = "Program:"
        '
        'Label2
        '
        Me.Label2.Location = New System.Drawing.Point(80, 88)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(100, 23)
        Me.Label2.TabIndex = 12
        Me.Label2.Text = "School Year:"
        '
        'Label3
        '
        Me.Label3.Location = New System.Drawing.Point(80, 112)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(100, 23)
        Me.Label3.TabIndex = 13
        Me.Label3.Text = "Semester:"
        '
        'Label4
        '
        Me.Label4.Location = New System.Drawing.Point(80, 136)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(100, 23)
        Me.Label4.TabIndex = 14
        Me.Label4.Text = "Year:"
        '
        'Label5
        '
        Me.Label5.Location = New System.Drawing.Point(80, 160)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(100, 23)
        Me.Label5.TabIndex = 15
        Me.Label5.Text = "Section:"
        '
        'btnCancel
        '
        Me.btnCancel.Location = New System.Drawing.Point(184, 192)
        Me.btnCancel.Name = "btnCancel"
        Me.btnCancel.Size = New System.Drawing.Size(75, 23)
        Me.btnCancel.TabIndex = 16
        Me.btnCancel.Text = "Cancel"
        '
        'Panel1
        '
        Me.Panel1.BackColor = System.Drawing.SystemColors.ControlDark
        Me.Panel1.Controls.Add(Me.Label6)
        Me.Panel1.Location = New System.Drawing.Point(16, 16)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(336, 40)
        Me.Panel1.TabIndex = 18
        '
        'Label6
        '
        Me.Label6.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label6.Location = New System.Drawing.Point(8, 8)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(312, 24)
        Me.Label6.TabIndex = 18
        Me.Label6.Text = "Enrollment List - Per Section"
        '
        'Panel2
        '
        Me.Panel2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Panel2.Controls.Add(Me.cboSem)
        Me.Panel2.Controls.Add(Me.cboProgramID)
        Me.Panel2.Location = New System.Drawing.Point(8, 8)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(352, 216)
        Me.Panel2.TabIndex = 19
        '
        'cboSem
        '
        Me.cboSem.Location = New System.Drawing.Point(184, 104)
        Me.cboSem.Name = "cboSem"
        Me.cboSem.Size = New System.Drawing.Size(104, 21)
        Me.cboSem.TabIndex = 95
        '
        'cboProgramID
        '
        Me.cboProgramID.DataSource = Me.ProgramBindingSource
        Me.cboProgramID.DisplayMember = "ProgramTitle"
        Me.cboProgramID.Location = New System.Drawing.Point(184, 56)
        Me.cboProgramID.Name = "cboProgramID"
        Me.cboProgramID.Size = New System.Drawing.Size(104, 21)
        Me.cboProgramID.TabIndex = 93
        Me.cboProgramID.ValueMember = "ProgramID"
        '
        'EnrollSystemDataSet
        '
        Me.EnrollSystemDataSet.DataSetName = "EnrollSystemDataSet"
        Me.EnrollSystemDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'EnrollSystemDataSetBindingSource
        '
        Me.EnrollSystemDataSetBindingSource.DataSource = Me.EnrollSystemDataSet
        Me.EnrollSystemDataSetBindingSource.Position = 0
        '
        'ProgramBindingSource
        '
        Me.ProgramBindingSource.DataMember = "Program"
        Me.ProgramBindingSource.DataSource = Me.EnrollSystemDataSet
        '
        'ProgramTableAdapter
        '
        Me.ProgramTableAdapter.ClearBeforeFill = True
        '
        'EnrollListPerSectionDialog
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(368, 232)
        Me.Controls.Add(Me.Panel1)
        Me.Controls.Add(Me.btnCancel)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.txtPreview)
        Me.Controls.Add(Me.txtSection)
        Me.Controls.Add(Me.txtYear)
        Me.Controls.Add(Me.txtSchYr)
        Me.Controls.Add(Me.Panel2)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.Name = "EnrollListPerSectionDialog"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "EnrollListPerSectionDialog"
        Me.Panel1.ResumeLayout(False)
        Me.Panel2.ResumeLayout(False)
        CType(Me.EnrollSystemDataSet, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.EnrollSystemDataSetBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.ProgramBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

#End Region

    Private Sub txtPreview_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txtPreview.Click
        Dim frmReport As New EnrollListPerSection(Me)

        If cboProgramID.Text = "" Or _
            txtSchYr.Text = "" Or _
            cboSem.Text = "" Or _
            txtYear.Text = "" Or _
            txtSection.Text = "" Then

            MessageBox.Show("Please don't leave other field blank", "Error", MessageBoxButtons.OK, MessageBoxIcon.Information)
        Else
            frmReport.Show()
        End If
    End Sub

    Private Sub btnCancel_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnCancel.Click
        Me.Close()
    End Sub

    Private Sub EnrollListPerSectionDialog_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'TODO: This line of code loads data into the 'EnrollSystemDataSet.Program' table. You can move, or remove it, as needed.
        Me.ProgramTableAdapter.Fill(Me.EnrollSystemDataSet.Program)

        With cboSem
            .Items.Add("1st")
            .Items.Add("2nd")
            .Items.Add("Summer")
        End With
    End Sub

End Class

﻿Partial Class EnrollSystemDataSet

    Protected Overrides Sub Finalize()
        MyBase.Finalize()
    End Sub
End Class

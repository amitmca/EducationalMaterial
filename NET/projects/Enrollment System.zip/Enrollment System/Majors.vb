﻿Public Class Majors

    Private Sub MajorBindingNavigatorSaveItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MajorBindingNavigatorSaveItem.Click
        Me.Validate()
        Me.MajorBindingSource.EndEdit()
        Me.TableAdapterManager.UpdateAll(Me.EnrollSystemDataSet)

    End Sub

    Private Sub Majors_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'TODO: This line of code loads data into the 'EnrollSystemDataSet.Major' table. You can move, or remove it, as needed.
        Me.MajorTableAdapter.Fill(Me.EnrollSystemDataSet.Major)

    End Sub
End Class
﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Menu
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.TabControl1 = New System.Windows.Forms.TabControl
        Me.tabTransactions = New System.Windows.Forms.TabPage
        Me.lkRegularLoad = New System.Windows.Forms.LinkLabel
        Me.btnRegularLoad = New System.Windows.Forms.Button
        Me.lkStudentInfo = New System.Windows.Forms.LinkLabel
        Me.btnStudentInfo = New System.Windows.Forms.Button
        Me.tabMasterfiles = New System.Windows.Forms.TabPage
        Me.linkMajors = New System.Windows.Forms.LinkLabel
        Me.btnMajors = New System.Windows.Forms.Button
        Me.linkPrograms = New System.Windows.Forms.LinkLabel
        Me.btnPrograms = New System.Windows.Forms.Button
        Me.linkCourses = New System.Windows.Forms.LinkLabel
        Me.btnCourses = New System.Windows.Forms.Button
        Me.tabReports = New System.Windows.Forms.TabPage
        Me.DeansList = New System.Windows.Forms.LinkLabel
        Me.Button7 = New System.Windows.Forms.Button
        Me.StudentsDirectory = New System.Windows.Forms.LinkLabel
        Me.Button8 = New System.Windows.Forms.Button
        Me.Form137 = New System.Windows.Forms.LinkLabel
        Me.Button4 = New System.Windows.Forms.Button
        Me.NSTPReport = New System.Windows.Forms.LinkLabel
        Me.Button5 = New System.Windows.Forms.Button
        Me.ChedReport = New System.Windows.Forms.LinkLabel
        Me.Button6 = New System.Windows.Forms.Button
        Me.RatingsReport = New System.Windows.Forms.LinkLabel
        Me.Button1 = New System.Windows.Forms.Button
        Me.EnrollmentListPerSubject = New System.Windows.Forms.LinkLabel
        Me.Button2 = New System.Windows.Forms.Button
        Me.EnrollmentListPerSection = New System.Windows.Forms.LinkLabel
        Me.Button3 = New System.Windows.Forms.Button
        Me.tabUtilities = New System.Windows.Forms.TabPage
        Me.Panel1 = New System.Windows.Forms.Panel
        Me.Label1 = New System.Windows.Forms.Label
        Me.Panel2 = New System.Windows.Forms.Panel
        Me.TabControl1.SuspendLayout()
        Me.tabTransactions.SuspendLayout()
        Me.tabMasterfiles.SuspendLayout()
        Me.tabReports.SuspendLayout()
        Me.Panel1.SuspendLayout()
        Me.Panel2.SuspendLayout()
        Me.SuspendLayout()
        '
        'TabControl1
        '
        Me.TabControl1.Controls.Add(Me.tabTransactions)
        Me.TabControl1.Controls.Add(Me.tabMasterfiles)
        Me.TabControl1.Controls.Add(Me.tabReports)
        Me.TabControl1.Controls.Add(Me.tabUtilities)
        Me.TabControl1.Location = New System.Drawing.Point(10, 12)
        Me.TabControl1.Name = "TabControl1"
        Me.TabControl1.SelectedIndex = 0
        Me.TabControl1.Size = New System.Drawing.Size(454, 343)
        Me.TabControl1.SizeMode = System.Windows.Forms.TabSizeMode.Fixed
        Me.TabControl1.TabIndex = 0
        '
        'tabTransactions
        '
        Me.tabTransactions.Controls.Add(Me.lkRegularLoad)
        Me.tabTransactions.Controls.Add(Me.btnRegularLoad)
        Me.tabTransactions.Controls.Add(Me.lkStudentInfo)
        Me.tabTransactions.Controls.Add(Me.btnStudentInfo)
        Me.tabTransactions.Location = New System.Drawing.Point(4, 22)
        Me.tabTransactions.Name = "tabTransactions"
        Me.tabTransactions.Padding = New System.Windows.Forms.Padding(3)
        Me.tabTransactions.Size = New System.Drawing.Size(446, 317)
        Me.tabTransactions.TabIndex = 0
        Me.tabTransactions.Text = "Transactions"
        Me.tabTransactions.UseVisualStyleBackColor = True
        '
        'lkRegularLoad
        '
        Me.lkRegularLoad.AutoSize = True
        Me.lkRegularLoad.Location = New System.Drawing.Point(57, 71)
        Me.lkRegularLoad.Name = "lkRegularLoad"
        Me.lkRegularLoad.Size = New System.Drawing.Size(71, 13)
        Me.lkRegularLoad.TabIndex = 3
        Me.lkRegularLoad.TabStop = True
        Me.lkRegularLoad.Text = "Regular Load"
        '
        'btnRegularLoad
        '
        Me.btnRegularLoad.Location = New System.Drawing.Point(18, 59)
        Me.btnRegularLoad.Name = "btnRegularLoad"
        Me.btnRegularLoad.Size = New System.Drawing.Size(33, 33)
        Me.btnRegularLoad.TabIndex = 2
        Me.btnRegularLoad.UseVisualStyleBackColor = True
        '
        'lkStudentInfo
        '
        Me.lkStudentInfo.AutoSize = True
        Me.lkStudentInfo.Location = New System.Drawing.Point(57, 27)
        Me.lkStudentInfo.Name = "lkStudentInfo"
        Me.lkStudentInfo.Size = New System.Drawing.Size(99, 13)
        Me.lkStudentInfo.TabIndex = 1
        Me.lkStudentInfo.TabStop = True
        Me.lkStudentInfo.Text = "Student Information"
        '
        'btnStudentInfo
        '
        Me.btnStudentInfo.Location = New System.Drawing.Point(18, 17)
        Me.btnStudentInfo.Name = "btnStudentInfo"
        Me.btnStudentInfo.Size = New System.Drawing.Size(33, 33)
        Me.btnStudentInfo.TabIndex = 0
        Me.btnStudentInfo.UseVisualStyleBackColor = True
        '
        'tabMasterfiles
        '
        Me.tabMasterfiles.Controls.Add(Me.linkMajors)
        Me.tabMasterfiles.Controls.Add(Me.btnMajors)
        Me.tabMasterfiles.Controls.Add(Me.linkPrograms)
        Me.tabMasterfiles.Controls.Add(Me.btnPrograms)
        Me.tabMasterfiles.Controls.Add(Me.linkCourses)
        Me.tabMasterfiles.Controls.Add(Me.btnCourses)
        Me.tabMasterfiles.Location = New System.Drawing.Point(4, 22)
        Me.tabMasterfiles.Name = "tabMasterfiles"
        Me.tabMasterfiles.Padding = New System.Windows.Forms.Padding(3)
        Me.tabMasterfiles.Size = New System.Drawing.Size(446, 317)
        Me.tabMasterfiles.TabIndex = 1
        Me.tabMasterfiles.Text = "Masterfiles"
        Me.tabMasterfiles.UseVisualStyleBackColor = True
        '
        'linkMajors
        '
        Me.linkMajors.AutoSize = True
        Me.linkMajors.Location = New System.Drawing.Point(66, 115)
        Me.linkMajors.Name = "linkMajors"
        Me.linkMajors.Size = New System.Drawing.Size(38, 13)
        Me.linkMajors.TabIndex = 5
        Me.linkMajors.TabStop = True
        Me.linkMajors.Text = "Majors"
        '
        'btnMajors
        '
        Me.btnMajors.Location = New System.Drawing.Point(18, 105)
        Me.btnMajors.Name = "btnMajors"
        Me.btnMajors.Size = New System.Drawing.Size(33, 33)
        Me.btnMajors.TabIndex = 4
        Me.btnMajors.UseVisualStyleBackColor = True
        '
        'linkPrograms
        '
        Me.linkPrograms.AutoSize = True
        Me.linkPrograms.Location = New System.Drawing.Point(66, 69)
        Me.linkPrograms.Name = "linkPrograms"
        Me.linkPrograms.Size = New System.Drawing.Size(51, 13)
        Me.linkPrograms.TabIndex = 3
        Me.linkPrograms.TabStop = True
        Me.linkPrograms.Text = "Programs"
        '
        'btnPrograms
        '
        Me.btnPrograms.Location = New System.Drawing.Point(18, 59)
        Me.btnPrograms.Name = "btnPrograms"
        Me.btnPrograms.Size = New System.Drawing.Size(33, 33)
        Me.btnPrograms.TabIndex = 2
        Me.btnPrograms.UseVisualStyleBackColor = True
        '
        'linkCourses
        '
        Me.linkCourses.AutoSize = True
        Me.linkCourses.Location = New System.Drawing.Point(66, 27)
        Me.linkCourses.Name = "linkCourses"
        Me.linkCourses.Size = New System.Drawing.Size(45, 13)
        Me.linkCourses.TabIndex = 1
        Me.linkCourses.TabStop = True
        Me.linkCourses.Text = "Courses"
        '
        'btnCourses
        '
        Me.btnCourses.Location = New System.Drawing.Point(18, 17)
        Me.btnCourses.Name = "btnCourses"
        Me.btnCourses.Size = New System.Drawing.Size(33, 33)
        Me.btnCourses.TabIndex = 0
        Me.btnCourses.UseVisualStyleBackColor = True
        '
        'tabReports
        '
        Me.tabReports.Controls.Add(Me.DeansList)
        Me.tabReports.Controls.Add(Me.Button7)
        Me.tabReports.Controls.Add(Me.StudentsDirectory)
        Me.tabReports.Controls.Add(Me.Button8)
        Me.tabReports.Controls.Add(Me.Form137)
        Me.tabReports.Controls.Add(Me.Button4)
        Me.tabReports.Controls.Add(Me.NSTPReport)
        Me.tabReports.Controls.Add(Me.Button5)
        Me.tabReports.Controls.Add(Me.ChedReport)
        Me.tabReports.Controls.Add(Me.Button6)
        Me.tabReports.Controls.Add(Me.RatingsReport)
        Me.tabReports.Controls.Add(Me.Button1)
        Me.tabReports.Controls.Add(Me.EnrollmentListPerSubject)
        Me.tabReports.Controls.Add(Me.Button2)
        Me.tabReports.Controls.Add(Me.EnrollmentListPerSection)
        Me.tabReports.Controls.Add(Me.Button3)
        Me.tabReports.Location = New System.Drawing.Point(4, 22)
        Me.tabReports.Name = "tabReports"
        Me.tabReports.Size = New System.Drawing.Size(446, 317)
        Me.tabReports.TabIndex = 2
        Me.tabReports.Text = "Reports"
        Me.tabReports.UseVisualStyleBackColor = True
        '
        'DeansList
        '
        Me.DeansList.AutoSize = True
        Me.DeansList.Location = New System.Drawing.Point(66, 265)
        Me.DeansList.Name = "DeansList"
        Me.DeansList.Size = New System.Drawing.Size(59, 13)
        Me.DeansList.TabIndex = 21
        Me.DeansList.TabStop = True
        Me.DeansList.Text = "Dean's List"
        '
        'Button7
        '
        Me.Button7.Location = New System.Drawing.Point(18, 255)
        Me.Button7.Name = "Button7"
        Me.Button7.Size = New System.Drawing.Size(33, 33)
        Me.Button7.TabIndex = 20
        Me.Button7.UseVisualStyleBackColor = True
        '
        'StudentsDirectory
        '
        Me.StudentsDirectory.AutoSize = True
        Me.StudentsDirectory.Location = New System.Drawing.Point(66, 231)
        Me.StudentsDirectory.Name = "StudentsDirectory"
        Me.StudentsDirectory.Size = New System.Drawing.Size(94, 13)
        Me.StudentsDirectory.TabIndex = 19
        Me.StudentsDirectory.TabStop = True
        Me.StudentsDirectory.Text = "Students Directory"
        '
        'Button8
        '
        Me.Button8.Location = New System.Drawing.Point(18, 221)
        Me.Button8.Name = "Button8"
        Me.Button8.Size = New System.Drawing.Size(33, 33)
        Me.Button8.TabIndex = 18
        Me.Button8.UseVisualStyleBackColor = True
        '
        'Form137
        '
        Me.Form137.AutoSize = True
        Me.Form137.Location = New System.Drawing.Point(66, 197)
        Me.Form137.Name = "Form137"
        Me.Form137.Size = New System.Drawing.Size(51, 13)
        Me.Form137.TabIndex = 17
        Me.Form137.TabStop = True
        Me.Form137.Text = "Form 137"
        '
        'Button4
        '
        Me.Button4.Location = New System.Drawing.Point(18, 187)
        Me.Button4.Name = "Button4"
        Me.Button4.Size = New System.Drawing.Size(33, 33)
        Me.Button4.TabIndex = 16
        Me.Button4.UseVisualStyleBackColor = True
        '
        'NSTPReport
        '
        Me.NSTPReport.AutoSize = True
        Me.NSTPReport.Location = New System.Drawing.Point(66, 163)
        Me.NSTPReport.Name = "NSTPReport"
        Me.NSTPReport.Size = New System.Drawing.Size(164, 13)
        Me.NSTPReport.TabIndex = 15
        Me.NSTPReport.TabStop = True
        Me.NSTPReport.Text = "NSTP (CWTS) Enrollment Report"
        '
        'Button5
        '
        Me.Button5.Location = New System.Drawing.Point(18, 153)
        Me.Button5.Name = "Button5"
        Me.Button5.Size = New System.Drawing.Size(33, 33)
        Me.Button5.TabIndex = 14
        Me.Button5.UseVisualStyleBackColor = True
        '
        'ChedReport
        '
        Me.ChedReport.AutoSize = True
        Me.ChedReport.Location = New System.Drawing.Point(66, 129)
        Me.ChedReport.Name = "ChedReport"
        Me.ChedReport.Size = New System.Drawing.Size(72, 13)
        Me.ChedReport.TabIndex = 13
        Me.ChedReport.TabStop = True
        Me.ChedReport.Text = "CHED Report"
        '
        'Button6
        '
        Me.Button6.Location = New System.Drawing.Point(18, 119)
        Me.Button6.Name = "Button6"
        Me.Button6.Size = New System.Drawing.Size(33, 33)
        Me.Button6.TabIndex = 12
        Me.Button6.UseVisualStyleBackColor = True
        '
        'RatingsReport
        '
        Me.RatingsReport.AutoSize = True
        Me.RatingsReport.Location = New System.Drawing.Point(66, 95)
        Me.RatingsReport.Name = "RatingsReport"
        Me.RatingsReport.Size = New System.Drawing.Size(78, 13)
        Me.RatingsReport.TabIndex = 11
        Me.RatingsReport.TabStop = True
        Me.RatingsReport.Text = "Ratings Report"
        '
        'Button1
        '
        Me.Button1.Location = New System.Drawing.Point(18, 85)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(33, 33)
        Me.Button1.TabIndex = 10
        Me.Button1.UseVisualStyleBackColor = True
        '
        'EnrollmentListPerSubject
        '
        Me.EnrollmentListPerSubject.AutoSize = True
        Me.EnrollmentListPerSubject.Location = New System.Drawing.Point(66, 61)
        Me.EnrollmentListPerSubject.Name = "EnrollmentListPerSubject"
        Me.EnrollmentListPerSubject.Size = New System.Drawing.Size(139, 13)
        Me.EnrollmentListPerSubject.TabIndex = 9
        Me.EnrollmentListPerSubject.TabStop = True
        Me.EnrollmentListPerSubject.Text = "Enrollment List - Per Subject"
        '
        'Button2
        '
        Me.Button2.Location = New System.Drawing.Point(18, 51)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(33, 33)
        Me.Button2.TabIndex = 8
        Me.Button2.UseVisualStyleBackColor = True
        '
        'EnrollmentListPerSection
        '
        Me.EnrollmentListPerSection.AutoSize = True
        Me.EnrollmentListPerSection.Location = New System.Drawing.Point(66, 27)
        Me.EnrollmentListPerSection.Name = "EnrollmentListPerSection"
        Me.EnrollmentListPerSection.Size = New System.Drawing.Size(139, 13)
        Me.EnrollmentListPerSection.TabIndex = 7
        Me.EnrollmentListPerSection.TabStop = True
        Me.EnrollmentListPerSection.Text = "Enrollment List - Per Section"
        '
        'Button3
        '
        Me.Button3.Location = New System.Drawing.Point(18, 17)
        Me.Button3.Name = "Button3"
        Me.Button3.Size = New System.Drawing.Size(33, 33)
        Me.Button3.TabIndex = 6
        Me.Button3.UseVisualStyleBackColor = True
        '
        'tabUtilities
        '
        Me.tabUtilities.Location = New System.Drawing.Point(4, 22)
        Me.tabUtilities.Name = "tabUtilities"
        Me.tabUtilities.Size = New System.Drawing.Size(446, 317)
        Me.tabUtilities.TabIndex = 3
        Me.tabUtilities.Text = "Utilities"
        Me.tabUtilities.UseVisualStyleBackColor = True
        '
        'Panel1
        '
        Me.Panel1.BackColor = System.Drawing.SystemColors.ControlDark
        Me.Panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Panel1.Controls.Add(Me.Label1)
        Me.Panel1.Location = New System.Drawing.Point(7, 5)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(475, 40)
        Me.Panel1.TabIndex = 1
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Lucida Console", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(5, 9)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(231, 21)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Enrollment System"
        '
        'Panel2
        '
        Me.Panel2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Panel2.Controls.Add(Me.TabControl1)
        Me.Panel2.Location = New System.Drawing.Point(6, 54)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(476, 360)
        Me.Panel2.TabIndex = 2
        '
        'Menu
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(490, 426)
        Me.Controls.Add(Me.Panel2)
        Me.Controls.Add(Me.Panel1)
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "Menu"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Menu"
        Me.TabControl1.ResumeLayout(False)
        Me.tabTransactions.ResumeLayout(False)
        Me.tabTransactions.PerformLayout()
        Me.tabMasterfiles.ResumeLayout(False)
        Me.tabMasterfiles.PerformLayout()
        Me.tabReports.ResumeLayout(False)
        Me.tabReports.PerformLayout()
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        Me.Panel2.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents TabControl1 As System.Windows.Forms.TabControl
    Friend WithEvents tabTransactions As System.Windows.Forms.TabPage
    Friend WithEvents tabMasterfiles As System.Windows.Forms.TabPage
    Friend WithEvents tabReports As System.Windows.Forms.TabPage
    Friend WithEvents tabUtilities As System.Windows.Forms.TabPage
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents lkStudentInfo As System.Windows.Forms.LinkLabel
    Friend WithEvents btnStudentInfo As System.Windows.Forms.Button
    Friend WithEvents btnCourses As System.Windows.Forms.Button
    Friend WithEvents linkMajors As System.Windows.Forms.LinkLabel
    Friend WithEvents btnMajors As System.Windows.Forms.Button
    Friend WithEvents linkPrograms As System.Windows.Forms.LinkLabel
    Friend WithEvents btnPrograms As System.Windows.Forms.Button
    Friend WithEvents linkCourses As System.Windows.Forms.LinkLabel
    Friend WithEvents lkRegularLoad As System.Windows.Forms.LinkLabel
    Friend WithEvents btnRegularLoad As System.Windows.Forms.Button
    Friend WithEvents Panel2 As System.Windows.Forms.Panel
    Friend WithEvents RatingsReport As System.Windows.Forms.LinkLabel
    Friend WithEvents Button1 As System.Windows.Forms.Button
    Friend WithEvents EnrollmentListPerSubject As System.Windows.Forms.LinkLabel
    Friend WithEvents Button2 As System.Windows.Forms.Button
    Friend WithEvents EnrollmentListPerSection As System.Windows.Forms.LinkLabel
    Friend WithEvents Button3 As System.Windows.Forms.Button
    Friend WithEvents Form137 As System.Windows.Forms.LinkLabel
    Friend WithEvents Button4 As System.Windows.Forms.Button
    Friend WithEvents NSTPReport As System.Windows.Forms.LinkLabel
    Friend WithEvents Button5 As System.Windows.Forms.Button
    Friend WithEvents ChedReport As System.Windows.Forms.LinkLabel
    Friend WithEvents Button6 As System.Windows.Forms.Button
    Friend WithEvents DeansList As System.Windows.Forms.LinkLabel
    Friend WithEvents Button7 As System.Windows.Forms.Button
    Friend WithEvents StudentsDirectory As System.Windows.Forms.LinkLabel
    Friend WithEvents Button8 As System.Windows.Forms.Button
End Class

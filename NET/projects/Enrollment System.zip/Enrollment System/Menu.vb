﻿Public Class Menu
    Private blnActive As Boolean

    Private Function IsOpen(ByVal nameForm As String) As Boolean
        Dim childfrm As Form
        Dim strNaam As String
        Dim intPuntje As Integer

        For Each childfrm In Me.MdiChildren
            strNaam = childfrm.GetType.ToString
            intPuntje = strNaam.LastIndexOf(".")
            strNaam = Mid(strNaam, intPuntje + 2, Len(strNaam) - intPuntje)
            If LCase(strNaam) = LCase(nameForm) Then
                childfrm.BringToFront()
                Return True
            End If
        Next
        Return False
    End Function

    Private Sub lkStudentInfo_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles lkStudentInfo.Click
        'If blnActive = IsOpen("Students") Then
        Dim Students As New Students

        Students.Show()
        'End If
    End Sub

    Private Sub btnStudentInfo_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnStudentInfo.Click
        Call lkStudentInfo_Click(sender, e)
    End Sub

    Private Sub linkCourses_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles linkCourses.Click
        Dim Courses As New Courses

        Courses.Show()
    End Sub

    Private Sub linkPrograms_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles linkPrograms.Click
        Dim Programs As New Programs

        Programs.Show()
    End Sub

    Private Sub linkMajors_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles linkMajors.Click
        Dim Majors As New Majors

        Majors.Show()
    End Sub

    Private Sub btnCourses_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnCourses.Click
        Call linkCourses_Click(sender, e)
    End Sub

    Private Sub btnPrograms_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnPrograms.Click
        Call linkPrograms_Click(sender, e)
    End Sub

    Private Sub btnMajors_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnMajors.Click
        Call linkMajors_Click(sender, e)
    End Sub

    Private Sub lkRegularLoad_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles lkRegularLoad.Click
        Dim RegularLoad As New Regular_Load

        RegularLoad.Show()
    End Sub

    Private Sub btnRegularLoad_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnRegularLoad.Click
        Call lkRegularLoad_Click(sender, e)
    End Sub

    Private Sub EnrollmentListPerSection_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles EnrollmentListPerSection.Click
        Dim EnrollListPerSectionDialog As New EnrollListPerSectionDialog

        EnrollListPerSectionDialog.Show()
    End Sub

    Private Sub EnrollmentListPerSubject_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles EnrollmentListPerSubject.Click
        Dim EnrollListPerSubjectDialog As New EnrollListPerSubjectDialog

        EnrollListPerSubjectDialog.Show()
    End Sub

    Private Sub RatingsReport_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles RatingsReport.Click
        Dim RatingDialog As New RatingDialog

        RatingDialog.Show()
    End Sub

    Private Sub ChedReport_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles ChedReport.Click
        Dim ChedDialog As New ChedDialog

        ChedDialog.Show()
    End Sub

    Private Sub NSTPReport_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles NSTPReport.Click
        Dim NSTPEnrollmentDialog As New NSTPEnrollmentDialog

        NSTPEnrollmentDialog.Show()
    End Sub

    Private Sub Form137_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles Form137.Click
        Dim FORM137Dialog As New FORM137Dialog

        FORM137Dialog.Show()
    End Sub

    Private Sub StudentsDirectory_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles StudentsDirectory.Click
        Dim StudentsDirectoryDialog As New StudentsDirectoryDialog

        StudentsDirectoryDialog.Show()
    End Sub

    Private Sub DeansList_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles DeansList.Click
        Dim DeansListDialog As New DeansListDialog


        DeansListDialog.Show()
    End Sub

End Class
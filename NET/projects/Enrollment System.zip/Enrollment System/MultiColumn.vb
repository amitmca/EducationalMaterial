﻿Imports System.ComponentModel
Imports System.Drawing

'for updated versions or if you have any bug fixes go to http://www.edneeis.com
Public Class MultiComboBox
    Inherits ComboBox

    'internal members for added properties
    Private _imageList As ImageList
    Private _imageindexmember As String
    Private _columns As New ColumnCollection()
    Private _showColumns As Boolean = False
    Private _showColumnHeaders As Boolean = False

    'imagelist to get the images from
    Public Property ImageList() As ImageList
        Get
            Return _imageList
        End Get
        Set(ByVal value As ImageList)
            _imageList = value
        End Set
    End Property

    'property of the item object that holds the imageindex
    Public Property ImageIndexMember() As String
        Get
            Return _imageindexmember
        End Get
        Set(ByVal value As String)
            _imageindexmember = value
        End Set
    End Property

    'holds the collection of column info
    Public ReadOnly Property Columns() As ColumnCollection
        Get
            Return _columns
        End Get
    End Property

    'if false then defaults to normal or image combo regardless of columns collection
    Public Property ShowColumns() As Boolean
        Get
            Return _showColumns
        End Get
        Set(ByVal value As Boolean)
            _showColumns = value
        End Set
    End Property

    'not yet implemented
    Public Property ShowColumnHeader() As Boolean
        Get
            Return _showColumnHeaders
        End Get
        Set(ByVal value As Boolean)
            _showColumnHeaders = value
        End Set
    End Property

    Protected Overrides Sub OnDrawItem(ByVal ea As DrawItemEventArgs)
        'this replaces the normal drawing of the dropdown list
        ea.DrawBackground()
        ea.DrawFocusRectangle()

        Dim iwidth As Integer = 0

        'handle image
        Try
            Dim imageindex As Integer = -1
            Dim imageSize As Size = ImageList.ImageSize
            imageindex = Items(ea.Index).GetType.GetProperty(Me.ImageIndexMember).GetValue(Items(ea.Index), Nothing)
            ImageList.Draw(ea.Graphics, ea.Bounds.Left, ea.Bounds.Top, imageindex)
            iwidth = imageSize.Width
        Catch exi As Exception
        End Try

        'handle regular drawing
        Try
            If ea.Index <> -1 Then
                'handle columns
                If _showColumns Then
                    Dim col As Column
                    Dim cnt As Integer
                    For Each col In Me.Columns
                        cnt += 1

                        Static prevWidth As Integer
                        If cnt = 1 Then prevWidth = ea.Bounds.X
                        Dim useX As Integer = ea.Bounds.X + col.Width
                        Dim useY As Integer = ea.Bounds.Y + ea.Bounds.Height
                        Dim display As String
                        'get the text from the bound object by property name in the columnmember
                        Try
                            If Items(ea.Index).GetType Is GetType(Data.DataRowView) Then
                                Dim d As Data.DataRowView = CType(Items(ea.Index), Data.DataRowView)
                                display = CType(d.Item(col.ColumnMember), String)
                            Else
                                display = CType(Items(ea.Index).GetType.GetProperty(col.ColumnMember).GetValue(Items(ea.Index), Nothing), String)
                            End If
                        Catch ext As Exception
                            display = Items(ea.Index).ToString()
                        End Try
                        'get bounds for the 'cell' and draw text
                        Dim rectf As New RectangleF((ea.Bounds.X + prevWidth) + iwidth, ea.Bounds.Y, useX, ea.Bounds.Height)
                        ea.Graphics.DrawString(display, ea.Font, New SolidBrush(ea.ForeColor), rectf)
                        If cnt > 1 Then
                            'draw the line for everyone but the first one
                            'other good colors for the line is silver and gray
                            ea.Graphics.DrawLine(System.Drawing.Pens.LightGray, prevWidth + iwidth, ea.Bounds.Y, prevWidth + iwidth, useY)
                        End If
                        'remember previous column width
                        prevWidth += col.Width
                    Next
                Else
                    'hide columns deafault to normal
                    Dim display As String
                    'get the text from the bound object by property name in the columnmember
                    Try
                        display = CType(Items(ea.Index).GetType.GetProperty(Me.DisplayMember).GetValue(Items(ea.Index), Nothing), String)
                    Catch ext As Exception
                        display = Items(ea.Index).ToString()
                    End Try
                    ea.Graphics.DrawString(display, ea.Font, New SolidBrush(ea.ForeColor), ea.Bounds.Left + iwidth, ea.Bounds.Top)
                End If
            Else
                'draw default simplest form
                ea.Graphics.DrawString(Me.Text, ea.Font, New SolidBrush(ea.ForeColor), Bounds.Left, Bounds.Top)
            End If
        Catch ex As Exception
            'draw default simplest form
            ea.Graphics.DrawString(Me.Text, ea.Font, New SolidBrush(ea.ForeColor), Bounds.Left, Bounds.Top)
        End Try

        MyBase.OnDrawItem(ea)
    End Sub

    Public Sub New()
        'set to ownerdraw
        Me.DrawMode = DrawMode.OwnerDrawFixed
    End Sub

    Public Sub New(ByRef cbo As ComboBox)
        'assign all properties from cbo to me
        'Dim pi As Reflection.PropertyInfo
        'For Each pi In cbo.GetType.GetProperties
        '    Dim s As String = pi.Attributes.ToString
        '    If pi.CanWrite Then
        '        'On Error Resume Next 'just in case
        '        Me.GetType.GetProperty(pi.Name).SetValue(Me, pi.GetValue(cbo, Nothing), Nothing)
        '    End If
        'Next
        'TODO: have it consume ALL properties of original combo
        Me.Anchor = cbo.Anchor
        Me.BackColor = cbo.BackColor
        Me.BackgroundImage = cbo.BackgroundImage
        Me.CausesValidation = cbo.CausesValidation
        Me.ContextMenu = cbo.ContextMenu
        Me.DataSource = cbo.DataSource
        Me.DisplayMember = cbo.DisplayMember
        Me.Dock = cbo.Dock
        Me.DropDownStyle = cbo.DropDownStyle
        Me.DropDownWidth = cbo.DropDownWidth
        Me.Enabled = cbo.Enabled
        Me.Font = cbo.Font
        Me.ForeColor = cbo.ForeColor
        Me.IntegralHeight = cbo.IntegralHeight
        If cbo.Items.Count > 0 Then
            Dim tmp(cbo.Items.Count) As Object
            cbo.Items.CopyTo(tmp, 0)
            Me.Items.AddRange(tmp)
        End If
        Me.MaxDropDownItems = cbo.MaxDropDownItems
        Me.MaxLength = cbo.MaxLength
        Me.Sorted = cbo.Sorted
        Me.Text = cbo.Text
        Me.TabStop = cbo.TabStop
        Me.ValueMember = cbo.ValueMember
        Me.Visible = cbo.Visible
        Me.Location = cbo.Location
        Me.Size = cbo.Size
        Me.TabIndex = cbo.TabIndex
        'set to ownerdraw
        Me.DrawMode = DrawMode.OwnerDrawFixed
        'switch combos
        Dim parent As Object = cbo.Parent
        parent.Controls.Remove(cbo)
        parent.Controls.Add(Me)
    End Sub

    'column class
    Public Class Column

        Private _Width As Integer
        Private _ColumnMember As String
        Private _Header As String

        'width of the column
        'if it exceed the width of the dropdownwidth then it will not be shown
        Public Property Width() As Integer
            Get
                Return _Width
            End Get
            Set(ByVal Value As Integer)
                _Width = Value
            End Set
        End Property

        'bound field or property that you want to display in this column
        Public Property ColumnMember() As String
            Get
                Return _ColumnMember
            End Get
            Set(ByVal Value As String)
                _ColumnMember = Value
            End Set
        End Property

        'not yet implemented
        Public Property Header() As String
            Get
                Return _Header
            End Get
            Set(ByVal Value As String)
                _Header = Value
            End Set
        End Property

        Public Sub New()
            MyBase.new()
        End Sub

        Public Sub New(ByVal width As Integer, ByVal columnmember As String)
            Me.New(width, columnmember, String.Empty)
        End Sub

        Public Sub New(ByVal width As Integer, ByVal columnmember As String, ByVal header As String)
            MyBase.new()
            Me.Width = width
            Me.ColumnMember = columnmember
            Me.Header = header
        End Sub

    End Class

    'the strong typed collection for the column objects
    Public Class ColumnCollection
        Implements IEnumerable

        Private _Col As New Collection()

        Public ReadOnly Property Count() As Integer
            Get
                Return _Col.Count
            End Get
        End Property

        Default Public ReadOnly Property Item(ByVal Key As String) As Column
            Get
                Return _Col(Key)
            End Get
        End Property

        Default Public ReadOnly Property Item(ByVal Index As Integer) As Column
            Get
                Return _Col(Index)
            End Get
        End Property

        Public Function Add(ByVal NewItem As Column, Optional ByVal Key As String = Nothing) As Column
            If Key Is Nothing Then
                _Col.Add(NewItem)
            Else
                _Col.Add(NewItem, Key)
            End If
        End Function

        Public Sub Remove(ByVal Key As String)
            _Col.Remove(Key)
        End Sub

        Public Sub Remove(ByVal Index As Integer)
            _Col.Remove(Index)
        End Sub

        Public Sub Clear()
            Dim cnt As Integer
            Dim cntMax As Integer

            cntMax = _Col.Count
            For cnt = cntMax To 1 Step -1
                _Col.Remove(cnt)
            Next
        End Sub

        Public Function Contains(ByVal Key As String) As Boolean
            Try
                Dim obj As Object = _Col(Key)
                Return True
            Catch ex As Exception
                Return False
            End Try
        End Function

        Public Sub New()
            MyBase.new()
        End Sub

        Public Function GetEnumerator() As System.Collections.IEnumerator Implements System.Collections.IEnumerable.GetEnumerator
            Return _Col.GetEnumerator
        End Function

    End Class

End Class

'just a sample class to use for items in this example
Public Class GenericList
    Private _Display As String
    Private _AlternateDisplay As String
    Private _ID As Integer
    Private _Index As Integer = -1

    Public Property Display() As String
        Get
            Return _Display
        End Get
        Set(ByVal Value As String)
            _Display = Value
        End Set
    End Property

    Public Property AlternateDisplay() As String
        Get
            Return _AlternateDisplay
        End Get
        Set(ByVal Value As String)
            _AlternateDisplay = Value
        End Set
    End Property

    Public Property ID() As Integer
        Get
            Return _ID
        End Get
        Set(ByVal Value As Integer)
            _ID = Value
        End Set
    End Property

    Public Property Index() As Integer
        Get
            Return _Index
        End Get
        Set(ByVal Value As Integer)
            _Index = Value
        End Set
    End Property

    Public Sub New()
        MyBase.new()
    End Sub

    Public Sub New(ByVal display As String, ByVal id As Integer)
        Me.Display = display
        Me.ID = id
    End Sub

    Public Sub New(ByVal display As String, ByVal altdisplay As String, ByVal id As Integer)
        Me.Display = display
        Me.AlternateDisplay = altdisplay
        Me.ID = id
    End Sub

    Public Sub New(ByVal display As String, ByVal id As Integer, ByVal index As Integer)
        Me.Display = display
        Me.ID = id
        Me.Index = index
    End Sub

    Public Sub New(ByVal display As String, ByVal altdisplay As String, ByVal id As Integer, ByVal index As Integer)
        Me.Display = display
        Me.AlternateDisplay = altdisplay
        Me.ID = id
        Me.Index = index
    End Sub

End Class

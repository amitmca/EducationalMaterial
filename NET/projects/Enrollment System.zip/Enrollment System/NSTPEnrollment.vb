Imports System.Data
Imports System.Data.SqlClient
Imports CrystalDecisions.CrystalReports.Engine

Public Class NSTPEnrollment
    Inherits System.Windows.Forms.Form

    Private ServerName As String = "localhost"

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents CrystalReportViewer1 As CrystalDecisions.Windows.Forms.CrystalReportViewer
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.CrystalReportViewer1 = New CrystalDecisions.Windows.Forms.CrystalReportViewer
        Me.SuspendLayout()
        '
        'CrystalReportViewer1
        '
        Me.CrystalReportViewer1.ActiveViewIndex = -1
        Me.CrystalReportViewer1.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.CrystalReportViewer1.DisplayGroupTree = False
        Me.CrystalReportViewer1.Location = New System.Drawing.Point(0, 0)
        Me.CrystalReportViewer1.Name = "CrystalReportViewer1"
        Me.CrystalReportViewer1.ReportSource = Nothing
        Me.CrystalReportViewer1.ShowGroupTreeButton = False
        Me.CrystalReportViewer1.Size = New System.Drawing.Size(968, 600)
        Me.CrystalReportViewer1.TabIndex = 6
        '
        'NSTPEnrollment
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(968, 598)
        Me.Controls.Add(Me.CrystalReportViewer1)
        Me.Name = "NSTPEnrollment"
        Me.Text = "NSTP Enrollment"
        Me.WindowState = System.Windows.Forms.FormWindowState.Maximized
        Me.ResumeLayout(False)

    End Sub

#End Region

    Public Sub New(ByVal frmDialog As NSTPEnrollmentDialog)
        Me.New()

        Dim rptNSTPEnrollment As New ReportDocument

        Dim pvCollection As New CrystalDecisions.Shared.ParameterValues
        Dim pdvSchYr As New CrystalDecisions.Shared.ParameterDiscreteValue
        Dim pdvSem As New CrystalDecisions.Shared.ParameterDiscreteValue
        Dim pdvCourseID As New CrystalDecisions.Shared.ParameterDiscreteValue

        Dim tbCurrent As CrystalDecisions.CrystalReports.Engine.Table
        Dim tliCurrent As CrystalDecisions.Shared.TableLogOnInfo

        'Try
        rptNSTPEnrollment.Load("..\..\Reports\rptNSTPEnrollment.rpt")

        For Each tbCurrent In rptNSTPEnrollment.Database.Tables
            tliCurrent = tbCurrent.LogOnInfo
            With tliCurrent.ConnectionInfo
                .ServerName = ServerName
                .UserID = ""
                .Password = ""
                .DatabaseName = "EnrollSystem"
            End With
            tbCurrent.ApplyLogOnInfo(tliCurrent)
        Next tbCurrent

        pdvSchYr.Value = frmDialog.txtSchYr.Text
        pdvSem.Value = frmDialog.cboSem.Text
        'pdvCourseID.Value = frmDialog.cboCourseCode.SelectedValue.ToString
        pdvCourseID.Value = frmDialog.mcbo.SelectedValue.ToString

        pvCollection.Clear()
        pvCollection.Add(pdvSchYr)
        rptNSTPEnrollment.DataDefinition.ParameterFields("@SchYr").ApplyCurrentValues(pvCollection)


        pvCollection.Clear()
        pvCollection.Add(pdvSem)
        rptNSTPEnrollment.DataDefinition.ParameterFields("@Sem").ApplyCurrentValues(pvCollection)

        pvCollection.Clear()
        pvCollection.Add(pdvCourseID)
        rptNSTPEnrollment.DataDefinition.ParameterFields("@CourseID").ApplyCurrentValues(pvCollection)

        CrystalReportViewer1.ReportSource = rptNSTPEnrollment

        'Catch Exp As LoadSaveReportException
        'MsgBox("Incorrect path for loading report.", _
        '        MsgBoxStyle.Critical, "Load Report Error")

        'Catch Exp As Exception
        'MsgBox(Exp.Message, MsgBoxStyle.Critical, "General Error")
        'End Try
    End Sub
End Class

Imports System.Data.SqlClient

Public Class NSTPEnrollmentDialog
    Inherits System.Windows.Forms.Form
    Dim connectionString As String = "Data Source=localhost;Initial Catalog=EnrollSystem;Integrated Security=True"

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents txtPreview As System.Windows.Forms.Button
    Friend WithEvents btnCancel As System.Windows.Forms.Button
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents Panel2 As System.Windows.Forms.Panel
    Friend WithEvents cboSem As System.Windows.Forms.ComboBox
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents cboCourseCode As System.Windows.Forms.ComboBox
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents EnrollSystemDataSet As Enrollment_System.EnrollSystemDataSet
    Friend WithEvents CourseBindingSource As System.Windows.Forms.BindingSource
    Friend WithEvents CourseTableAdapter As Enrollment_System.EnrollSystemDataSetTableAdapters.CourseTableAdapter
    Friend WithEvents txtSchYr As System.Windows.Forms.TextBox
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container
        Me.txtPreview = New System.Windows.Forms.Button
        Me.btnCancel = New System.Windows.Forms.Button
        Me.Panel1 = New System.Windows.Forms.Panel
        Me.Label6 = New System.Windows.Forms.Label
        Me.Panel2 = New System.Windows.Forms.Panel
        Me.Label3 = New System.Windows.Forms.Label
        Me.Label2 = New System.Windows.Forms.Label
        Me.txtSchYr = New System.Windows.Forms.TextBox
        Me.cboCourseCode = New System.Windows.Forms.ComboBox
        Me.CourseBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.EnrollSystemDataSet = New Enrollment_System.EnrollSystemDataSet
        Me.cboSem = New System.Windows.Forms.ComboBox
        Me.Label7 = New System.Windows.Forms.Label
        Me.CourseTableAdapter = New Enrollment_System.EnrollSystemDataSetTableAdapters.CourseTableAdapter
        Me.Panel1.SuspendLayout()
        Me.Panel2.SuspendLayout()
        CType(Me.CourseBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.EnrollSystemDataSet, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'txtPreview
        '
        Me.txtPreview.Location = New System.Drawing.Point(136, 160)
        Me.txtPreview.Name = "txtPreview"
        Me.txtPreview.Size = New System.Drawing.Size(75, 23)
        Me.txtPreview.TabIndex = 10
        Me.txtPreview.Text = "Preview"
        '
        'btnCancel
        '
        Me.btnCancel.Location = New System.Drawing.Point(224, 160)
        Me.btnCancel.Name = "btnCancel"
        Me.btnCancel.Size = New System.Drawing.Size(75, 23)
        Me.btnCancel.TabIndex = 16
        Me.btnCancel.Text = "Cancel"
        '
        'Panel1
        '
        Me.Panel1.BackColor = System.Drawing.SystemColors.ControlDark
        Me.Panel1.Controls.Add(Me.Label6)
        Me.Panel1.Location = New System.Drawing.Point(16, 16)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(424, 40)
        Me.Panel1.TabIndex = 18
        '
        'Label6
        '
        Me.Label6.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label6.Location = New System.Drawing.Point(8, 8)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(312, 24)
        Me.Label6.TabIndex = 18
        Me.Label6.Text = "NSTP Enrollment Report"
        '
        'Panel2
        '
        Me.Panel2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Panel2.Controls.Add(Me.Label3)
        Me.Panel2.Controls.Add(Me.Label2)
        Me.Panel2.Controls.Add(Me.txtSchYr)
        Me.Panel2.Controls.Add(Me.cboCourseCode)
        Me.Panel2.Controls.Add(Me.cboSem)
        Me.Panel2.Controls.Add(Me.btnCancel)
        Me.Panel2.Controls.Add(Me.txtPreview)
        Me.Panel2.Controls.Add(Me.Label7)
        Me.Panel2.Location = New System.Drawing.Point(8, 8)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(440, 200)
        Me.Panel2.TabIndex = 19
        '
        'Label3
        '
        Me.Label3.Location = New System.Drawing.Point(72, 88)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(100, 23)
        Me.Label3.TabIndex = 99
        Me.Label3.Text = "Semester:"
        '
        'Label2
        '
        Me.Label2.Location = New System.Drawing.Point(72, 64)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(100, 23)
        Me.Label2.TabIndex = 98
        Me.Label2.Text = "School Year:"
        '
        'txtSchYr
        '
        Me.txtSchYr.Location = New System.Drawing.Point(184, 64)
        Me.txtSchYr.Name = "txtSchYr"
        Me.txtSchYr.Size = New System.Drawing.Size(104, 20)
        Me.txtSchYr.TabIndex = 97
        Me.txtSchYr.Text = "2008-2009"
        '
        'cboCourseCode
        '
        Me.cboCourseCode.Location = New System.Drawing.Point(184, 120)
        Me.cboCourseCode.Name = "cboCourseCode"
        Me.cboCourseCode.Size = New System.Drawing.Size(248, 21)
        Me.cboCourseCode.TabIndex = 96
        '
        'CourseBindingSource
        '
        Me.CourseBindingSource.DataMember = "Course"
        Me.CourseBindingSource.DataSource = Me.EnrollSystemDataSet
        '
        'EnrollSystemDataSet
        '
        Me.EnrollSystemDataSet.DataSetName = "EnrollSystemDataSet"
        Me.EnrollSystemDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'cboSem
        '
        Me.cboSem.Location = New System.Drawing.Point(184, 88)
        Me.cboSem.Name = "cboSem"
        Me.cboSem.Size = New System.Drawing.Size(104, 21)
        Me.cboSem.TabIndex = 95
        '
        'Label7
        '
        Me.Label7.Location = New System.Drawing.Point(72, 120)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(100, 23)
        Me.Label7.TabIndex = 20
        Me.Label7.Text = "Course Code:"
        '
        'CourseTableAdapter
        '
        Me.CourseTableAdapter.ClearBeforeFill = True
        '
        'NSTPEnrollmentDialog
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(456, 216)
        Me.Controls.Add(Me.Panel1)
        Me.Controls.Add(Me.Panel2)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.Name = "NSTPEnrollmentDialog"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "EnrollListPerSectionDialog"
        Me.Panel1.ResumeLayout(False)
        Me.Panel2.ResumeLayout(False)
        Me.Panel2.PerformLayout()
        CType(Me.CourseBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.EnrollSystemDataSet, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub

#End Region
    Public mcbo As MultiComboBox

    Private Sub txtPreview_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txtPreview.Click
        Dim frmReport As New NSTPEnrollment(Me)

        If txtSchYr.Text = "" Or _
            cboSem.Text = "" Or _
            mcbo.Text = "" Then

            MessageBox.Show("Please don't leave other field blank", "Error", MessageBoxButtons.OK, MessageBoxIcon.Information)
        Else
            frmReport.Show()
        End If
    End Sub

    Private Sub btnCancel_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnCancel.Click
        Me.Close()
    End Sub

    Private Sub EnrollListPerSectionDialog_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'TODO: This line of code loads data into the 'EnrollSystemDataSet.Course' table. You can move, or remove it, as needed.
        'Me.CourseTableAdapter.Fill(Me.EnrollSystemDataSet.Course)
        BindCourse()

        With cboSem
            .Items.Add("1st")
            .Items.Add("2nd")
            .Items.Add("Summer")
        End With
    End Sub

    Private Sub BindCourse()
        Dim conString As New SqlConnection(connectionString)
        Dim SQLString As String

        conString.Open()
        SQLString = "Select CourseID, CourseCode, CourseTitle from Course Where CourseCode Like 'NSTP%' Order by CourseCode"

        Dim daCourse As New SqlDataAdapter(SQLString, conString)
        Dim dsCourse As New DataSet
        daCourse.Fill(dsCourse, "Course")

        mcbo = New MultiComboBox(cboCourseCode)

        mcbo.ShowColumns = True
        mcbo.DataSource = dsCourse.Tables("Course")
        mcbo.DisplayMember = "CourseCode"
        mcbo.ValueMember = "CourseID"
        mcbo.Columns.Add(New MultiComboBox.Column(60, "CourseCode"))
        mcbo.Columns.Add(New MultiComboBox.Column(200, "CourseTitle"))
    End Sub

    Private Sub NSTPEnrollmentDialog_Resize(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.Resize
        Me.WindowState = FormWindowState.Normal
    End Sub
End Class

﻿Public Class Programs

    Private Sub ProgramBindingNavigatorSaveItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ProgramBindingNavigatorSaveItem.Click
        Me.Validate()
        Me.ProgramBindingSource.EndEdit()
        Me.TableAdapterManager.UpdateAll(Me.EnrollSystemDataSet)

    End Sub

    Private Sub Programs_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'TODO: This line of code loads data into the 'EnrollSystemDataSet.Program' table. You can move, or remove it, as needed.
        Me.ProgramTableAdapter.Fill(Me.EnrollSystemDataSet.Program)

    End Sub

End Class
Imports System.Data
Imports System.Data.SqlClient
Imports CrystalDecisions.CrystalReports.Engine

Public Class Rating
    Inherits System.Windows.Forms.Form

    Private ServerName As String = "localhost"

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents CrystalReportViewer1 As CrystalDecisions.Windows.Forms.CrystalReportViewer
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.CrystalReportViewer1 = New CrystalDecisions.Windows.Forms.CrystalReportViewer
        Me.SuspendLayout()
        '
        'CrystalReportViewer1
        '
        Me.CrystalReportViewer1.ActiveViewIndex = -1
        Me.CrystalReportViewer1.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.CrystalReportViewer1.DisplayGroupTree = False
        Me.CrystalReportViewer1.Location = New System.Drawing.Point(0, 0)
        Me.CrystalReportViewer1.Name = "CrystalReportViewer1"
        Me.CrystalReportViewer1.ReportSource = Nothing
        Me.CrystalReportViewer1.ShowGroupTreeButton = False
        Me.CrystalReportViewer1.Size = New System.Drawing.Size(968, 600)
        Me.CrystalReportViewer1.TabIndex = 6
        '
        'EnrollListPerSubject
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(968, 598)
        Me.Controls.Add(Me.CrystalReportViewer1)
        Me.Name = "EnrollListPerSubject"
        Me.Text = "Enrollment List Per Subject"
        Me.WindowState = System.Windows.Forms.FormWindowState.Maximized
        Me.ResumeLayout(False)

    End Sub

#End Region

    Public Sub New(ByVal frmDialog As RatingDialog)
        Me.New()

        Dim rptDeansList As New ReportDocument

        Dim pvCollection As New CrystalDecisions.Shared.ParameterValues
        Dim pdvIDNo As New CrystalDecisions.Shared.ParameterDiscreteValue
        Dim pdvYear As New CrystalDecisions.Shared.ParameterDiscreteValue
        Dim pdvSem As New CrystalDecisions.Shared.ParameterDiscreteValue
        Dim pdvExclude As New CrystalDecisions.Shared.ParameterDiscreteValue
        Dim pdvRemarks1 As New CrystalDecisions.Shared.ParameterDiscreteValue
        Dim pdvRemarks2 As New CrystalDecisions.Shared.ParameterDiscreteValue
        Dim pdvORNo As New CrystalDecisions.Shared.ParameterDiscreteValue
        Dim pdvORDate As New CrystalDecisions.Shared.ParameterDiscreteValue
        Dim pdvCheckedby As New CrystalDecisions.Shared.ParameterDiscreteValue

        Dim tbCurrent As CrystalDecisions.CrystalReports.Engine.Table
        Dim tliCurrent As CrystalDecisions.Shared.TableLogOnInfo

        'Try
        rptDeansList.Load("..\..\Reports\rptRating.rpt")

        For Each tbCurrent In rptDeansList.Database.Tables
            tliCurrent = tbCurrent.LogOnInfo
            With tliCurrent.ConnectionInfo
                .ServerName = ServerName
                .UserID = ""
                .Password = ""
                .DatabaseName = "EnrollSystem"
            End With
            tbCurrent.ApplyLogOnInfo(tliCurrent)
        Next tbCurrent

        pdvIDNo.Value = frmDialog.cboIDNo.SelectedValue.ToString
        pdvYear.Value = IIf(frmDialog.txtYear.Text = "", Nothing, frmDialog.txtYear.Text)
        pdvSem.Value = IIf(frmDialog.cboSem.Text = "", Nothing, frmDialog.cboSem.Text)
        pdvExclude.Value = IIf(frmDialog.mcbo.Text = "", Nothing, frmDialog.mcbo.Text)
        pdvRemarks1.Value = frmDialog.txtRemarks1.Text
        pdvRemarks2.Value = frmDialog.txtRemarks2.Text
        pdvORNo.Value = frmDialog.txtORNo.Text
        pdvORDate.Value = frmDialog.txtORDate.Text
        pdvCheckedby.Value = frmDialog.txtCheckedby.Text

        pvCollection.Add(pdvIDNo)
        rptDeansList.DataDefinition.ParameterFields("@IDNo").ApplyCurrentValues(pvCollection)

        pvCollection.Clear()
        pvCollection.Add(pdvYear)
        rptDeansList.DataDefinition.ParameterFields("@Year").ApplyCurrentValues(pvCollection)

        pvCollection.Clear()
        pvCollection.Add(pdvSem)
        rptDeansList.DataDefinition.ParameterFields("@Sem").ApplyCurrentValues(pvCollection)

        pvCollection.Clear()
        pvCollection.Add(pdvExclude)
        rptDeansList.DataDefinition.ParameterFields("@Exclude").ApplyCurrentValues(pvCollection)

        pvCollection.Clear()
        pvCollection.Add(pdvRemarks1)
        rptDeansList.DataDefinition.ParameterFields("Remarks1").ApplyCurrentValues(pvCollection)

        pvCollection.Clear()
        pvCollection.Add(pdvRemarks2)
        rptDeansList.DataDefinition.ParameterFields("Remarks2").ApplyCurrentValues(pvCollection)

        pvCollection.Clear()
        pvCollection.Add(pdvORNo)
        rptDeansList.DataDefinition.ParameterFields("ORNo").ApplyCurrentValues(pvCollection)

        pvCollection.Clear()
        pvCollection.Add(pdvORDate)
        rptDeansList.DataDefinition.ParameterFields("ORDate").ApplyCurrentValues(pvCollection)

        pvCollection.Clear()
        pvCollection.Add(pdvCheckedby)
        rptDeansList.DataDefinition.ParameterFields("Checkedby").ApplyCurrentValues(pvCollection)

        CrystalReportViewer1.ReportSource = rptDeansList

        'Catch Exp As LoadSaveReportException
        'MsgBox("Incorrect path for loading report.", _
        '        MsgBoxStyle.Critical, "Load Report Error")

        'Catch Exp As Exception
        'MsgBox(Exp.Message, MsgBoxStyle.Critical, "General Error")
        'End Try
    End Sub
End Class

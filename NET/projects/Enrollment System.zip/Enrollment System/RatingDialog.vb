Imports System.Data.SqlClient

Public Class RatingDialog
    Inherits System.Windows.Forms.Form
    Dim connectionString As String = "Data Source=localhost;Initial Catalog=EnrollSystem;Integrated Security=True"

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents txtPreview As System.Windows.Forms.Button
    Friend WithEvents btnCancel As System.Windows.Forms.Button
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents Panel2 As System.Windows.Forms.Panel
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents cboIDNo As System.Windows.Forms.ComboBox
    Friend WithEvents cboSem As System.Windows.Forms.ComboBox
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents txtYear As System.Windows.Forms.TextBox
    Friend WithEvents cboExclude As System.Windows.Forms.ComboBox
    Friend WithEvents txtRemarks1 As System.Windows.Forms.TextBox
    Friend WithEvents txtRemarks2 As System.Windows.Forms.TextBox
    Friend WithEvents txtORNo As System.Windows.Forms.TextBox
    Friend WithEvents txtORDate As System.Windows.Forms.TextBox
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents EnrollSystemDataSet As Enrollment_System.EnrollSystemDataSet
    Friend WithEvents StudentsBindingSource As System.Windows.Forms.BindingSource
    Friend WithEvents StudentsTableAdapter As Enrollment_System.EnrollSystemDataSetTableAdapters.StudentsTableAdapter
    Friend WithEvents txtCheckedby As System.Windows.Forms.TextBox
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container
        Me.txtPreview = New System.Windows.Forms.Button
        Me.btnCancel = New System.Windows.Forms.Button
        Me.Panel1 = New System.Windows.Forms.Panel
        Me.Label6 = New System.Windows.Forms.Label
        Me.Panel2 = New System.Windows.Forms.Panel
        Me.Label10 = New System.Windows.Forms.Label
        Me.Label9 = New System.Windows.Forms.Label
        Me.Label8 = New System.Windows.Forms.Label
        Me.Label5 = New System.Windows.Forms.Label
        Me.Label4 = New System.Windows.Forms.Label
        Me.txtCheckedby = New System.Windows.Forms.TextBox
        Me.txtORDate = New System.Windows.Forms.TextBox
        Me.txtORNo = New System.Windows.Forms.TextBox
        Me.txtRemarks2 = New System.Windows.Forms.TextBox
        Me.txtRemarks1 = New System.Windows.Forms.TextBox
        Me.txtYear = New System.Windows.Forms.TextBox
        Me.Label3 = New System.Windows.Forms.Label
        Me.Label2 = New System.Windows.Forms.Label
        Me.Label1 = New System.Windows.Forms.Label
        Me.cboExclude = New System.Windows.Forms.ComboBox
        Me.cboSem = New System.Windows.Forms.ComboBox
        Me.cboIDNo = New System.Windows.Forms.ComboBox
        Me.StudentsBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.EnrollSystemDataSet = New Enrollment_System.EnrollSystemDataSet
        Me.Label7 = New System.Windows.Forms.Label
        Me.StudentsTableAdapter = New Enrollment_System.EnrollSystemDataSetTableAdapters.StudentsTableAdapter
        Me.Panel1.SuspendLayout()
        Me.Panel2.SuspendLayout()
        CType(Me.StudentsBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.EnrollSystemDataSet, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'txtPreview
        '
        Me.txtPreview.Location = New System.Drawing.Point(144, 296)
        Me.txtPreview.Name = "txtPreview"
        Me.txtPreview.Size = New System.Drawing.Size(75, 23)
        Me.txtPreview.TabIndex = 10
        Me.txtPreview.Text = "Preview"
        '
        'btnCancel
        '
        Me.btnCancel.Location = New System.Drawing.Point(232, 296)
        Me.btnCancel.Name = "btnCancel"
        Me.btnCancel.Size = New System.Drawing.Size(75, 23)
        Me.btnCancel.TabIndex = 16
        Me.btnCancel.Text = "Cancel"
        '
        'Panel1
        '
        Me.Panel1.BackColor = System.Drawing.SystemColors.ControlDark
        Me.Panel1.Controls.Add(Me.Label6)
        Me.Panel1.Location = New System.Drawing.Point(16, 16)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(424, 40)
        Me.Panel1.TabIndex = 18
        '
        'Label6
        '
        Me.Label6.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label6.Location = New System.Drawing.Point(8, 8)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(312, 24)
        Me.Label6.TabIndex = 18
        Me.Label6.Text = "Rating Report"
        '
        'Panel2
        '
        Me.Panel2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Panel2.Controls.Add(Me.Label10)
        Me.Panel2.Controls.Add(Me.Label9)
        Me.Panel2.Controls.Add(Me.Label8)
        Me.Panel2.Controls.Add(Me.Label5)
        Me.Panel2.Controls.Add(Me.Label4)
        Me.Panel2.Controls.Add(Me.txtCheckedby)
        Me.Panel2.Controls.Add(Me.txtORDate)
        Me.Panel2.Controls.Add(Me.txtORNo)
        Me.Panel2.Controls.Add(Me.txtRemarks2)
        Me.Panel2.Controls.Add(Me.txtRemarks1)
        Me.Panel2.Controls.Add(Me.txtYear)
        Me.Panel2.Controls.Add(Me.Label3)
        Me.Panel2.Controls.Add(Me.Label2)
        Me.Panel2.Controls.Add(Me.Label1)
        Me.Panel2.Controls.Add(Me.cboExclude)
        Me.Panel2.Controls.Add(Me.cboSem)
        Me.Panel2.Controls.Add(Me.cboIDNo)
        Me.Panel2.Controls.Add(Me.btnCancel)
        Me.Panel2.Controls.Add(Me.txtPreview)
        Me.Panel2.Controls.Add(Me.Label7)
        Me.Panel2.Location = New System.Drawing.Point(8, 8)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(440, 328)
        Me.Panel2.TabIndex = 19
        '
        'Label10
        '
        Me.Label10.Location = New System.Drawing.Point(8, 264)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(100, 23)
        Me.Label10.TabIndex = 111
        Me.Label10.Text = "Checked by:"
        '
        'Label9
        '
        Me.Label9.Location = New System.Drawing.Point(8, 240)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(100, 23)
        Me.Label9.TabIndex = 110
        Me.Label9.Text = "O.R. Date:"
        '
        'Label8
        '
        Me.Label8.Location = New System.Drawing.Point(8, 216)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(100, 23)
        Me.Label8.TabIndex = 109
        Me.Label8.Text = "O.R. No.:"
        '
        'Label5
        '
        Me.Label5.Location = New System.Drawing.Point(8, 171)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(100, 24)
        Me.Label5.TabIndex = 108
        Me.Label5.Text = "Remarks 2"
        '
        'Label4
        '
        Me.Label4.Location = New System.Drawing.Point(8, 128)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(100, 23)
        Me.Label4.TabIndex = 107
        Me.Label4.Text = "Remarks 1"
        '
        'txtCheckedby
        '
        Me.txtCheckedby.Location = New System.Drawing.Point(112, 264)
        Me.txtCheckedby.Name = "txtCheckedby"
        Me.txtCheckedby.Size = New System.Drawing.Size(240, 20)
        Me.txtCheckedby.TabIndex = 106
        '
        'txtORDate
        '
        Me.txtORDate.Location = New System.Drawing.Point(112, 240)
        Me.txtORDate.Name = "txtORDate"
        Me.txtORDate.Size = New System.Drawing.Size(240, 20)
        Me.txtORDate.TabIndex = 105
        '
        'txtORNo
        '
        Me.txtORNo.Location = New System.Drawing.Point(112, 216)
        Me.txtORNo.Name = "txtORNo"
        Me.txtORNo.Size = New System.Drawing.Size(240, 20)
        Me.txtORNo.TabIndex = 104
        '
        'txtRemarks2
        '
        Me.txtRemarks2.Location = New System.Drawing.Point(112, 171)
        Me.txtRemarks2.Multiline = True
        Me.txtRemarks2.Name = "txtRemarks2"
        Me.txtRemarks2.Size = New System.Drawing.Size(320, 40)
        Me.txtRemarks2.TabIndex = 103
        '
        'txtRemarks1
        '
        Me.txtRemarks1.Location = New System.Drawing.Point(112, 128)
        Me.txtRemarks1.Multiline = True
        Me.txtRemarks1.Name = "txtRemarks1"
        Me.txtRemarks1.Size = New System.Drawing.Size(320, 40)
        Me.txtRemarks1.TabIndex = 102
        '
        'txtYear
        '
        Me.txtYear.Location = New System.Drawing.Point(112, 80)
        Me.txtYear.Name = "txtYear"
        Me.txtYear.Size = New System.Drawing.Size(104, 20)
        Me.txtYear.TabIndex = 101
        '
        'Label3
        '
        Me.Label3.Location = New System.Drawing.Point(8, 104)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(100, 23)
        Me.Label3.TabIndex = 100
        Me.Label3.Text = "Semester:"
        '
        'Label2
        '
        Me.Label2.Location = New System.Drawing.Point(8, 80)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(100, 23)
        Me.Label2.TabIndex = 99
        Me.Label2.Text = "Year:"
        '
        'Label1
        '
        Me.Label1.Location = New System.Drawing.Point(8, 56)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(100, 23)
        Me.Label1.TabIndex = 98
        Me.Label1.Text = "Name:"
        '
        'cboExclude
        '
        Me.cboExclude.DisplayMember = "SchYrSemID"
        Me.cboExclude.Location = New System.Drawing.Point(224, 104)
        Me.cboExclude.Name = "cboExclude"
        Me.cboExclude.Size = New System.Drawing.Size(208, 21)
        Me.cboExclude.TabIndex = 96
        Me.cboExclude.ValueMember = "SchYrSemID"
        '
        'cboSem
        '
        Me.cboSem.ItemHeight = 13
        Me.cboSem.Location = New System.Drawing.Point(112, 104)
        Me.cboSem.Name = "cboSem"
        Me.cboSem.Size = New System.Drawing.Size(104, 21)
        Me.cboSem.TabIndex = 95
        '
        'cboIDNo
        '
        Me.cboIDNo.DataSource = Me.StudentsBindingSource
        Me.cboIDNo.Location = New System.Drawing.Point(112, 56)
        Me.cboIDNo.Name = "cboIDNo"
        Me.cboIDNo.Size = New System.Drawing.Size(320, 21)
        Me.cboIDNo.TabIndex = 93
        Me.cboIDNo.ValueMember = "IDNo"
        '
        'StudentsBindingSource
        '
        Me.StudentsBindingSource.DataMember = "Students"
        Me.StudentsBindingSource.DataSource = Me.EnrollSystemDataSet
        '
        'EnrollSystemDataSet
        '
        Me.EnrollSystemDataSet.DataSetName = "EnrollSystemDataSet"
        Me.EnrollSystemDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'Label7
        '
        Me.Label7.Location = New System.Drawing.Point(224, 80)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(192, 24)
        Me.Label7.TabIndex = 20
        Me.Label7.Text = "Exclude this Year && Semester:"
        '
        'StudentsTableAdapter
        '
        Me.StudentsTableAdapter.ClearBeforeFill = True
        '
        'RatingDialog
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(456, 344)
        Me.Controls.Add(Me.Panel1)
        Me.Controls.Add(Me.Panel2)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.Name = "RatingDialog"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "EnrollListPerSectionDialog"
        Me.Panel1.ResumeLayout(False)
        Me.Panel2.ResumeLayout(False)
        Me.Panel2.PerformLayout()
        CType(Me.StudentsBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.EnrollSystemDataSet, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub

#End Region
    Public mcbo As MultiComboBox
    Dim dsSchYrSem As DataSet

    Private Sub txtPreview_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txtPreview.Click
        Dim frmReport As New Rating(Me)

        If cboIDNo.Text = "" Then
            MessageBox.Show("Please don't leave other field blank", "Error", MessageBoxButtons.OK, MessageBoxIcon.Information)
        Else
            frmReport.Show()
        End If
    End Sub

    Private Sub btnCancel_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnCancel.Click
        Me.Close()
    End Sub

    Private Sub EnrollListPerSectionDialog_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Me.StudentsTableAdapter.FillByName(Me.EnrollSystemDataSet.Students)

        cboIDNo.DisplayMember = "Name"

        BindExclude()

        With cboSem
            .Items.Add("1st")
            .Items.Add("2nd")
            .Items.Add("Summer")
        End With
    End Sub

    Private Sub BindExclude()
        mcbo = New MultiComboBox(cboExclude)

        mcbo.ShowColumns = True
        mcbo.DisplayMember = "SchYrSemID"
        mcbo.Columns.Add(New MultiComboBox.Column(60, "SchYrSemID"))
        mcbo.Columns.Add(New MultiComboBox.Column(60, "Year"))
        mcbo.Columns.Add(New MultiComboBox.Column(60, "Sem"))
        mcbo.Text = Nothing
    End Sub

    Private Sub BindSchYrSem(ByVal intIDNo As Integer)
        Dim conString As New SqlConnection(connectionString)
        Dim SQLString As String

        conString.Open()
        SQLString = "Select SchYrSemID, IDNo, Year, Sem from SchYrSem Where (IDNo = @IDNo)"

        Dim daSchYrSem As New SqlDataAdapter
        Dim selectCMD As SqlCommand = New SqlCommand(SQLString, conString)
        daSchYrSem.SelectCommand = selectCMD

        selectCMD.Parameters.Add("@IDNo", SqlDbType.Int).Value = intIDNo

        dsSchYrSem = New DataSet
        daSchYrSem.Fill(dsSchYrSem, "SchYrSem")

        mcbo.DataSource = dsSchYrSem.Tables("SchYrSem")
        mcbo.Text = Nothing
    End Sub

    Private Sub cboIDNo_SelectionChangeCommitted(ByVal sender As Object, ByVal e As System.EventArgs) Handles cboIDNo.SelectionChangeCommitted
        BindSchYrSem(cboIDNo.SelectedValue.ToString)
    End Sub

    Private Sub RatingDialog_Resize(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.Resize
        Me.WindowState = FormWindowState.Normal
    End Sub
End Class

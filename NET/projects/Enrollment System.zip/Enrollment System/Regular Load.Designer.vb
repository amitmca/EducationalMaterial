﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Regular_Load
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container
        Dim YearLabel As System.Windows.Forms.Label
        Dim SemesterLabel As System.Windows.Forms.Label
        Dim ProgramIDLabel1 As System.Windows.Forms.Label
        Dim MajorIDLabel As System.Windows.Forms.Label
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Regular_Load))
        Me.EnrollSystemDataSet = New Enrollment_System.EnrollSystemDataSet
        Me.RegularLoadBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.RegularLoadTableAdapter = New Enrollment_System.EnrollSystemDataSetTableAdapters.RegularLoadTableAdapter
        Me.TableAdapterManager = New Enrollment_System.EnrollSystemDataSetTableAdapters.TableAdapterManager
        Me.CourseTableAdapter = New Enrollment_System.EnrollSystemDataSetTableAdapters.CourseTableAdapter
        Me.MajorTableAdapter = New Enrollment_System.EnrollSystemDataSetTableAdapters.MajorTableAdapter
        Me.ProgramTableAdapter = New Enrollment_System.EnrollSystemDataSetTableAdapters.ProgramTableAdapter
        Me.RegularLoad_DetailsTableAdapter = New Enrollment_System.EnrollSystemDataSetTableAdapters.RegularLoad_DetailsTableAdapter
        Me.RegularLoadBindingNavigator = New System.Windows.Forms.BindingNavigator(Me.components)
        Me.BindingNavigatorAddNewItem = New System.Windows.Forms.ToolStripButton
        Me.BindingNavigatorCountItem = New System.Windows.Forms.ToolStripLabel
        Me.BindingNavigatorDeleteItem = New System.Windows.Forms.ToolStripButton
        Me.BindingNavigatorMoveFirstItem = New System.Windows.Forms.ToolStripButton
        Me.BindingNavigatorMovePreviousItem = New System.Windows.Forms.ToolStripButton
        Me.BindingNavigatorSeparator = New System.Windows.Forms.ToolStripSeparator
        Me.BindingNavigatorPositionItem = New System.Windows.Forms.ToolStripTextBox
        Me.BindingNavigatorSeparator1 = New System.Windows.Forms.ToolStripSeparator
        Me.BindingNavigatorMoveNextItem = New System.Windows.Forms.ToolStripButton
        Me.BindingNavigatorMoveLastItem = New System.Windows.Forms.ToolStripButton
        Me.BindingNavigatorSeparator2 = New System.Windows.Forms.ToolStripSeparator
        Me.RegularLoadBindingNavigatorSaveItem = New System.Windows.Forms.ToolStripButton
        Me.YearTextBox = New System.Windows.Forms.TextBox
        Me.SemesterTextBox = New System.Windows.Forms.TextBox
        Me.TabControl1 = New System.Windows.Forms.TabControl
        Me.TabPage1 = New System.Windows.Forms.TabPage
        Me.MajorIDComboBox = New System.Windows.Forms.ComboBox
        Me.MajorBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.ProgramIDComboBox = New System.Windows.Forms.ComboBox
        Me.ProgramBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.RegularLoad_DetailsDataGridView = New System.Windows.Forms.DataGridView
        Me.DataGridViewTextBoxColumn3 = New System.Windows.Forms.DataGridViewComboBoxColumn
        Me.CourseBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.RegularLoad_DetailsBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.TabPage2 = New System.Windows.Forms.TabPage
        Me.RegularLoadDataGridView = New System.Windows.Forms.DataGridView
        Me.Panel1 = New System.Windows.Forms.Panel
        Me.Label1 = New System.Windows.Forms.Label
        Me.DataGridViewTextBoxColumn5 = New System.Windows.Forms.DataGridViewComboBoxColumn
        Me.DataGridViewTextBoxColumn6 = New System.Windows.Forms.DataGridViewComboBoxColumn
        Me.DataGridViewTextBoxColumn7 = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.DataGridViewTextBoxColumn8 = New System.Windows.Forms.DataGridViewTextBoxColumn
        YearLabel = New System.Windows.Forms.Label
        SemesterLabel = New System.Windows.Forms.Label
        ProgramIDLabel1 = New System.Windows.Forms.Label
        MajorIDLabel = New System.Windows.Forms.Label
        CType(Me.EnrollSystemDataSet, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.RegularLoadBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.RegularLoadBindingNavigator, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.RegularLoadBindingNavigator.SuspendLayout()
        Me.TabControl1.SuspendLayout()
        Me.TabPage1.SuspendLayout()
        CType(Me.MajorBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.ProgramBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.RegularLoad_DetailsDataGridView, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.CourseBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.RegularLoad_DetailsBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.TabPage2.SuspendLayout()
        CType(Me.RegularLoadDataGridView, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel1.SuspendLayout()
        Me.SuspendLayout()
        '
        'YearLabel
        '
        YearLabel.AutoSize = True
        YearLabel.Location = New System.Drawing.Point(237, 39)
        YearLabel.Name = "YearLabel"
        YearLabel.Size = New System.Drawing.Size(32, 13)
        YearLabel.TabIndex = 7
        YearLabel.Text = "Year:"
        '
        'SemesterLabel
        '
        SemesterLabel.AutoSize = True
        SemesterLabel.Location = New System.Drawing.Point(237, 65)
        SemesterLabel.Name = "SemesterLabel"
        SemesterLabel.Size = New System.Drawing.Size(54, 13)
        SemesterLabel.TabIndex = 9
        SemesterLabel.Text = "Semester:"
        '
        'ProgramIDLabel1
        '
        ProgramIDLabel1.AutoSize = True
        ProgramIDLabel1.Location = New System.Drawing.Point(19, 38)
        ProgramIDLabel1.Name = "ProgramIDLabel1"
        ProgramIDLabel1.Size = New System.Drawing.Size(49, 13)
        ProgramIDLabel1.TabIndex = 10
        ProgramIDLabel1.Text = "Program:"
        '
        'MajorIDLabel
        '
        MajorIDLabel.AutoSize = True
        MajorIDLabel.Location = New System.Drawing.Point(32, 68)
        MajorIDLabel.Name = "MajorIDLabel"
        MajorIDLabel.Size = New System.Drawing.Size(36, 13)
        MajorIDLabel.TabIndex = 11
        MajorIDLabel.Text = "Major:"
        '
        'EnrollSystemDataSet
        '
        Me.EnrollSystemDataSet.DataSetName = "EnrollSystemDataSet"
        Me.EnrollSystemDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'RegularLoadBindingSource
        '
        Me.RegularLoadBindingSource.DataMember = "RegularLoad"
        Me.RegularLoadBindingSource.DataSource = Me.EnrollSystemDataSet
        '
        'RegularLoadTableAdapter
        '
        Me.RegularLoadTableAdapter.ClearBeforeFill = True
        '
        'TableAdapterManager
        '
        Me.TableAdapterManager.BackupDataSetBeforeUpdate = False
        Me.TableAdapterManager.CourseTableAdapter = Me.CourseTableAdapter
        Me.TableAdapterManager.MajorTableAdapter = Me.MajorTableAdapter
        Me.TableAdapterManager.ProgramTableAdapter = Me.ProgramTableAdapter
        Me.TableAdapterManager.RegularLoad_DetailsTableAdapter = Me.RegularLoad_DetailsTableAdapter
        Me.TableAdapterManager.RegularLoadTableAdapter = Me.RegularLoadTableAdapter
        Me.TableAdapterManager.SchYrSemCourseJoinTableAdapter = Nothing
        Me.TableAdapterManager.SchYrSemTableAdapter = Nothing
        Me.TableAdapterManager.StudentsTableAdapter = Nothing
        Me.TableAdapterManager.Switchboard_ItemsTableAdapter = Nothing
        Me.TableAdapterManager.UpdateOrder = Enrollment_System.EnrollSystemDataSetTableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete
        '
        'CourseTableAdapter
        '
        Me.CourseTableAdapter.ClearBeforeFill = True
        '
        'MajorTableAdapter
        '
        Me.MajorTableAdapter.ClearBeforeFill = True
        '
        'ProgramTableAdapter
        '
        Me.ProgramTableAdapter.ClearBeforeFill = True
        '
        'RegularLoad_DetailsTableAdapter
        '
        Me.RegularLoad_DetailsTableAdapter.ClearBeforeFill = True
        '
        'RegularLoadBindingNavigator
        '
        Me.RegularLoadBindingNavigator.AddNewItem = Me.BindingNavigatorAddNewItem
        Me.RegularLoadBindingNavigator.BindingSource = Me.RegularLoadBindingSource
        Me.RegularLoadBindingNavigator.CountItem = Me.BindingNavigatorCountItem
        Me.RegularLoadBindingNavigator.DeleteItem = Me.BindingNavigatorDeleteItem
        Me.RegularLoadBindingNavigator.Dock = System.Windows.Forms.DockStyle.None
        Me.RegularLoadBindingNavigator.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.BindingNavigatorMoveFirstItem, Me.BindingNavigatorMovePreviousItem, Me.BindingNavigatorSeparator, Me.BindingNavigatorPositionItem, Me.BindingNavigatorCountItem, Me.BindingNavigatorSeparator1, Me.BindingNavigatorMoveNextItem, Me.BindingNavigatorMoveLastItem, Me.BindingNavigatorSeparator2, Me.BindingNavigatorAddNewItem, Me.BindingNavigatorDeleteItem, Me.RegularLoadBindingNavigatorSaveItem})
        Me.RegularLoadBindingNavigator.Location = New System.Drawing.Point(205, 432)
        Me.RegularLoadBindingNavigator.MoveFirstItem = Me.BindingNavigatorMoveFirstItem
        Me.RegularLoadBindingNavigator.MoveLastItem = Me.BindingNavigatorMoveLastItem
        Me.RegularLoadBindingNavigator.MoveNextItem = Me.BindingNavigatorMoveNextItem
        Me.RegularLoadBindingNavigator.MovePreviousItem = Me.BindingNavigatorMovePreviousItem
        Me.RegularLoadBindingNavigator.Name = "RegularLoadBindingNavigator"
        Me.RegularLoadBindingNavigator.PositionItem = Me.BindingNavigatorPositionItem
        Me.RegularLoadBindingNavigator.Size = New System.Drawing.Size(277, 25)
        Me.RegularLoadBindingNavigator.TabIndex = 0
        Me.RegularLoadBindingNavigator.Text = "BindingNavigator1"
        '
        'BindingNavigatorAddNewItem
        '
        Me.BindingNavigatorAddNewItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorAddNewItem.Image = CType(resources.GetObject("BindingNavigatorAddNewItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorAddNewItem.Name = "BindingNavigatorAddNewItem"
        Me.BindingNavigatorAddNewItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorAddNewItem.Size = New System.Drawing.Size(23, 22)
        Me.BindingNavigatorAddNewItem.Text = "Add new"
        '
        'BindingNavigatorCountItem
        '
        Me.BindingNavigatorCountItem.Name = "BindingNavigatorCountItem"
        Me.BindingNavigatorCountItem.Size = New System.Drawing.Size(36, 22)
        Me.BindingNavigatorCountItem.Text = "of {0}"
        Me.BindingNavigatorCountItem.ToolTipText = "Total number of items"
        '
        'BindingNavigatorDeleteItem
        '
        Me.BindingNavigatorDeleteItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorDeleteItem.Image = CType(resources.GetObject("BindingNavigatorDeleteItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorDeleteItem.Name = "BindingNavigatorDeleteItem"
        Me.BindingNavigatorDeleteItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorDeleteItem.Size = New System.Drawing.Size(23, 22)
        Me.BindingNavigatorDeleteItem.Text = "Delete"
        '
        'BindingNavigatorMoveFirstItem
        '
        Me.BindingNavigatorMoveFirstItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorMoveFirstItem.Image = CType(resources.GetObject("BindingNavigatorMoveFirstItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorMoveFirstItem.Name = "BindingNavigatorMoveFirstItem"
        Me.BindingNavigatorMoveFirstItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorMoveFirstItem.Size = New System.Drawing.Size(23, 22)
        Me.BindingNavigatorMoveFirstItem.Text = "Move first"
        '
        'BindingNavigatorMovePreviousItem
        '
        Me.BindingNavigatorMovePreviousItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorMovePreviousItem.Image = CType(resources.GetObject("BindingNavigatorMovePreviousItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorMovePreviousItem.Name = "BindingNavigatorMovePreviousItem"
        Me.BindingNavigatorMovePreviousItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorMovePreviousItem.Size = New System.Drawing.Size(23, 22)
        Me.BindingNavigatorMovePreviousItem.Text = "Move previous"
        '
        'BindingNavigatorSeparator
        '
        Me.BindingNavigatorSeparator.Name = "BindingNavigatorSeparator"
        Me.BindingNavigatorSeparator.Size = New System.Drawing.Size(6, 25)
        '
        'BindingNavigatorPositionItem
        '
        Me.BindingNavigatorPositionItem.AccessibleName = "Position"
        Me.BindingNavigatorPositionItem.AutoSize = False
        Me.BindingNavigatorPositionItem.Name = "BindingNavigatorPositionItem"
        Me.BindingNavigatorPositionItem.Size = New System.Drawing.Size(50, 21)
        Me.BindingNavigatorPositionItem.Text = "0"
        Me.BindingNavigatorPositionItem.ToolTipText = "Current position"
        '
        'BindingNavigatorSeparator1
        '
        Me.BindingNavigatorSeparator1.Name = "BindingNavigatorSeparator1"
        Me.BindingNavigatorSeparator1.Size = New System.Drawing.Size(6, 25)
        '
        'BindingNavigatorMoveNextItem
        '
        Me.BindingNavigatorMoveNextItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorMoveNextItem.Image = CType(resources.GetObject("BindingNavigatorMoveNextItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorMoveNextItem.Name = "BindingNavigatorMoveNextItem"
        Me.BindingNavigatorMoveNextItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorMoveNextItem.Size = New System.Drawing.Size(23, 22)
        Me.BindingNavigatorMoveNextItem.Text = "Move next"
        '
        'BindingNavigatorMoveLastItem
        '
        Me.BindingNavigatorMoveLastItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorMoveLastItem.Image = CType(resources.GetObject("BindingNavigatorMoveLastItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorMoveLastItem.Name = "BindingNavigatorMoveLastItem"
        Me.BindingNavigatorMoveLastItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorMoveLastItem.Size = New System.Drawing.Size(23, 22)
        Me.BindingNavigatorMoveLastItem.Text = "Move last"
        '
        'BindingNavigatorSeparator2
        '
        Me.BindingNavigatorSeparator2.Name = "BindingNavigatorSeparator2"
        Me.BindingNavigatorSeparator2.Size = New System.Drawing.Size(6, 25)
        '
        'RegularLoadBindingNavigatorSaveItem
        '
        Me.RegularLoadBindingNavigatorSaveItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.RegularLoadBindingNavigatorSaveItem.Image = CType(resources.GetObject("RegularLoadBindingNavigatorSaveItem.Image"), System.Drawing.Image)
        Me.RegularLoadBindingNavigatorSaveItem.Name = "RegularLoadBindingNavigatorSaveItem"
        Me.RegularLoadBindingNavigatorSaveItem.Size = New System.Drawing.Size(23, 22)
        Me.RegularLoadBindingNavigatorSaveItem.Text = "Save Data"
        '
        'YearTextBox
        '
        Me.YearTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.RegularLoadBindingSource, "Year", True))
        Me.YearTextBox.Location = New System.Drawing.Point(297, 36)
        Me.YearTextBox.Name = "YearTextBox"
        Me.YearTextBox.Size = New System.Drawing.Size(100, 20)
        Me.YearTextBox.TabIndex = 8
        '
        'SemesterTextBox
        '
        Me.SemesterTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.RegularLoadBindingSource, "Semester", True))
        Me.SemesterTextBox.Location = New System.Drawing.Point(297, 62)
        Me.SemesterTextBox.Name = "SemesterTextBox"
        Me.SemesterTextBox.Size = New System.Drawing.Size(100, 20)
        Me.SemesterTextBox.TabIndex = 10
        '
        'TabControl1
        '
        Me.TabControl1.Controls.Add(Me.TabPage1)
        Me.TabControl1.Controls.Add(Me.TabPage2)
        Me.TabControl1.Location = New System.Drawing.Point(12, 44)
        Me.TabControl1.Name = "TabControl1"
        Me.TabControl1.SelectedIndex = 0
        Me.TabControl1.Size = New System.Drawing.Size(646, 381)
        Me.TabControl1.TabIndex = 11
        '
        'TabPage1
        '
        Me.TabPage1.AutoScroll = True
        Me.TabPage1.Controls.Add(MajorIDLabel)
        Me.TabPage1.Controls.Add(Me.MajorIDComboBox)
        Me.TabPage1.Controls.Add(ProgramIDLabel1)
        Me.TabPage1.Controls.Add(Me.ProgramIDComboBox)
        Me.TabPage1.Controls.Add(Me.RegularLoad_DetailsDataGridView)
        Me.TabPage1.Controls.Add(Me.SemesterTextBox)
        Me.TabPage1.Controls.Add(SemesterLabel)
        Me.TabPage1.Controls.Add(Me.YearTextBox)
        Me.TabPage1.Controls.Add(YearLabel)
        Me.TabPage1.Location = New System.Drawing.Point(4, 22)
        Me.TabPage1.Name = "TabPage1"
        Me.TabPage1.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage1.Size = New System.Drawing.Size(638, 355)
        Me.TabPage1.TabIndex = 0
        Me.TabPage1.Text = "Regular Load"
        Me.TabPage1.UseVisualStyleBackColor = True
        '
        'MajorIDComboBox
        '
        Me.MajorIDComboBox.DataBindings.Add(New System.Windows.Forms.Binding("SelectedValue", Me.RegularLoadBindingSource, "MajorID", True))
        Me.MajorIDComboBox.DataSource = Me.MajorBindingSource
        Me.MajorIDComboBox.DisplayMember = "Major"
        Me.MajorIDComboBox.DropDownWidth = 400
        Me.MajorIDComboBox.FormattingEnabled = True
        Me.MajorIDComboBox.Location = New System.Drawing.Point(88, 65)
        Me.MajorIDComboBox.Name = "MajorIDComboBox"
        Me.MajorIDComboBox.Size = New System.Drawing.Size(121, 21)
        Me.MajorIDComboBox.TabIndex = 12
        Me.MajorIDComboBox.ValueMember = "MajorID"
        '
        'MajorBindingSource
        '
        Me.MajorBindingSource.DataMember = "Major"
        Me.MajorBindingSource.DataSource = Me.EnrollSystemDataSet
        '
        'ProgramIDComboBox
        '
        Me.ProgramIDComboBox.DataBindings.Add(New System.Windows.Forms.Binding("SelectedValue", Me.RegularLoadBindingSource, "ProgramID", True))
        Me.ProgramIDComboBox.DataSource = Me.ProgramBindingSource
        Me.ProgramIDComboBox.DisplayMember = "ProgramTitle"
        Me.ProgramIDComboBox.FormattingEnabled = True
        Me.ProgramIDComboBox.Location = New System.Drawing.Point(88, 35)
        Me.ProgramIDComboBox.Name = "ProgramIDComboBox"
        Me.ProgramIDComboBox.Size = New System.Drawing.Size(121, 21)
        Me.ProgramIDComboBox.TabIndex = 11
        Me.ProgramIDComboBox.ValueMember = "ProgramID"
        '
        'ProgramBindingSource
        '
        Me.ProgramBindingSource.DataMember = "Program"
        Me.ProgramBindingSource.DataSource = Me.EnrollSystemDataSet
        '
        'RegularLoad_DetailsDataGridView
        '
        Me.RegularLoad_DetailsDataGridView.AutoGenerateColumns = False
        Me.RegularLoad_DetailsDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.RegularLoad_DetailsDataGridView.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.DataGridViewTextBoxColumn3})
        Me.RegularLoad_DetailsDataGridView.DataSource = Me.RegularLoad_DetailsBindingSource
        Me.RegularLoad_DetailsDataGridView.Location = New System.Drawing.Point(16, 109)
        Me.RegularLoad_DetailsDataGridView.Name = "RegularLoad_DetailsDataGridView"
        Me.RegularLoad_DetailsDataGridView.Size = New System.Drawing.Size(604, 220)
        Me.RegularLoad_DetailsDataGridView.TabIndex = 10
        '
        'DataGridViewTextBoxColumn3
        '
        Me.DataGridViewTextBoxColumn3.DataPropertyName = "CourseID"
        Me.DataGridViewTextBoxColumn3.DataSource = Me.CourseBindingSource
        Me.DataGridViewTextBoxColumn3.DisplayMember = "CourseTitle"
        Me.DataGridViewTextBoxColumn3.DropDownWidth = 400
        Me.DataGridViewTextBoxColumn3.HeaderText = "Course"
        Me.DataGridViewTextBoxColumn3.Name = "DataGridViewTextBoxColumn3"
        Me.DataGridViewTextBoxColumn3.Resizable = System.Windows.Forms.DataGridViewTriState.[True]
        Me.DataGridViewTextBoxColumn3.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic
        Me.DataGridViewTextBoxColumn3.ValueMember = "CourseID"
        Me.DataGridViewTextBoxColumn3.Width = 300
        '
        'CourseBindingSource
        '
        Me.CourseBindingSource.DataMember = "Course"
        Me.CourseBindingSource.DataSource = Me.EnrollSystemDataSet
        '
        'RegularLoad_DetailsBindingSource
        '
        Me.RegularLoad_DetailsBindingSource.DataMember = "RegularLoad_RegularLoad Details"
        Me.RegularLoad_DetailsBindingSource.DataSource = Me.RegularLoadBindingSource
        '
        'TabPage2
        '
        Me.TabPage2.Controls.Add(Me.RegularLoadDataGridView)
        Me.TabPage2.Location = New System.Drawing.Point(4, 22)
        Me.TabPage2.Name = "TabPage2"
        Me.TabPage2.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage2.Size = New System.Drawing.Size(638, 355)
        Me.TabPage2.TabIndex = 1
        Me.TabPage2.Text = "List"
        Me.TabPage2.UseVisualStyleBackColor = True
        '
        'RegularLoadDataGridView
        '
        Me.RegularLoadDataGridView.AutoGenerateColumns = False
        Me.RegularLoadDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.RegularLoadDataGridView.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.DataGridViewTextBoxColumn5, Me.DataGridViewTextBoxColumn6, Me.DataGridViewTextBoxColumn7, Me.DataGridViewTextBoxColumn8})
        Me.RegularLoadDataGridView.DataSource = Me.RegularLoadBindingSource
        Me.RegularLoadDataGridView.Location = New System.Drawing.Point(17, 20)
        Me.RegularLoadDataGridView.Name = "RegularLoadDataGridView"
        Me.RegularLoadDataGridView.Size = New System.Drawing.Size(604, 318)
        Me.RegularLoadDataGridView.TabIndex = 0
        '
        'Panel1
        '
        Me.Panel1.BackColor = System.Drawing.SystemColors.ControlDark
        Me.Panel1.Controls.Add(Me.Label1)
        Me.Panel1.Location = New System.Drawing.Point(12, 6)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(646, 32)
        Me.Panel1.TabIndex = 12
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Lucida Console", 14.25!)
        Me.Label1.Location = New System.Drawing.Point(4, 6)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(141, 19)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Regular Load"
        '
        'DataGridViewTextBoxColumn5
        '
        Me.DataGridViewTextBoxColumn5.DataPropertyName = "ProgramID"
        Me.DataGridViewTextBoxColumn5.DataSource = Me.ProgramBindingSource
        Me.DataGridViewTextBoxColumn5.DisplayMember = "ProgramTitle"
        Me.DataGridViewTextBoxColumn5.HeaderText = "Program"
        Me.DataGridViewTextBoxColumn5.Name = "DataGridViewTextBoxColumn5"
        Me.DataGridViewTextBoxColumn5.Resizable = System.Windows.Forms.DataGridViewTriState.[True]
        Me.DataGridViewTextBoxColumn5.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic
        Me.DataGridViewTextBoxColumn5.ValueMember = "ProgramID"
        Me.DataGridViewTextBoxColumn5.Width = 90
        '
        'DataGridViewTextBoxColumn6
        '
        Me.DataGridViewTextBoxColumn6.DataPropertyName = "MajorID"
        Me.DataGridViewTextBoxColumn6.DataSource = Me.MajorBindingSource
        Me.DataGridViewTextBoxColumn6.DisplayMember = "Major"
        Me.DataGridViewTextBoxColumn6.HeaderText = "Major"
        Me.DataGridViewTextBoxColumn6.Name = "DataGridViewTextBoxColumn6"
        Me.DataGridViewTextBoxColumn6.Resizable = System.Windows.Forms.DataGridViewTriState.[True]
        Me.DataGridViewTextBoxColumn6.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic
        Me.DataGridViewTextBoxColumn6.ValueMember = "MajorID"
        Me.DataGridViewTextBoxColumn6.Width = 300
        '
        'DataGridViewTextBoxColumn7
        '
        Me.DataGridViewTextBoxColumn7.DataPropertyName = "Year"
        Me.DataGridViewTextBoxColumn7.HeaderText = "Year"
        Me.DataGridViewTextBoxColumn7.Name = "DataGridViewTextBoxColumn7"
        Me.DataGridViewTextBoxColumn7.Width = 70
        '
        'DataGridViewTextBoxColumn8
        '
        Me.DataGridViewTextBoxColumn8.DataPropertyName = "Semester"
        Me.DataGridViewTextBoxColumn8.HeaderText = "Semester"
        Me.DataGridViewTextBoxColumn8.Name = "DataGridViewTextBoxColumn8"
        Me.DataGridViewTextBoxColumn8.Width = 70
        '
        'Regular_Load
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(670, 466)
        Me.Controls.Add(Me.Panel1)
        Me.Controls.Add(Me.RegularLoadBindingNavigator)
        Me.Controls.Add(Me.TabControl1)
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "Regular_Load"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Regular Load"
        CType(Me.EnrollSystemDataSet, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.RegularLoadBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.RegularLoadBindingNavigator, System.ComponentModel.ISupportInitialize).EndInit()
        Me.RegularLoadBindingNavigator.ResumeLayout(False)
        Me.RegularLoadBindingNavigator.PerformLayout()
        Me.TabControl1.ResumeLayout(False)
        Me.TabPage1.ResumeLayout(False)
        Me.TabPage1.PerformLayout()
        CType(Me.MajorBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.ProgramBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.RegularLoad_DetailsDataGridView, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.CourseBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.RegularLoad_DetailsBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        Me.TabPage2.ResumeLayout(False)
        CType(Me.RegularLoadDataGridView, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents EnrollSystemDataSet As Enrollment_System.EnrollSystemDataSet
    Friend WithEvents RegularLoadBindingSource As System.Windows.Forms.BindingSource
    Friend WithEvents RegularLoadTableAdapter As Enrollment_System.EnrollSystemDataSetTableAdapters.RegularLoadTableAdapter
    Friend WithEvents TableAdapterManager As Enrollment_System.EnrollSystemDataSetTableAdapters.TableAdapterManager
    Friend WithEvents RegularLoadBindingNavigator As System.Windows.Forms.BindingNavigator
    Friend WithEvents BindingNavigatorAddNewItem As System.Windows.Forms.ToolStripButton
    Friend WithEvents BindingNavigatorCountItem As System.Windows.Forms.ToolStripLabel
    Friend WithEvents BindingNavigatorDeleteItem As System.Windows.Forms.ToolStripButton
    Friend WithEvents BindingNavigatorMoveFirstItem As System.Windows.Forms.ToolStripButton
    Friend WithEvents BindingNavigatorMovePreviousItem As System.Windows.Forms.ToolStripButton
    Friend WithEvents BindingNavigatorSeparator As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents BindingNavigatorPositionItem As System.Windows.Forms.ToolStripTextBox
    Friend WithEvents BindingNavigatorSeparator1 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents BindingNavigatorMoveNextItem As System.Windows.Forms.ToolStripButton
    Friend WithEvents BindingNavigatorMoveLastItem As System.Windows.Forms.ToolStripButton
    Friend WithEvents BindingNavigatorSeparator2 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents RegularLoadBindingNavigatorSaveItem As System.Windows.Forms.ToolStripButton
    Friend WithEvents YearTextBox As System.Windows.Forms.TextBox
    Friend WithEvents SemesterTextBox As System.Windows.Forms.TextBox
    Friend WithEvents TabControl1 As System.Windows.Forms.TabControl
    Friend WithEvents TabPage1 As System.Windows.Forms.TabPage
    Friend WithEvents TabPage2 As System.Windows.Forms.TabPage
    Friend WithEvents RegularLoad_DetailsTableAdapter As Enrollment_System.EnrollSystemDataSetTableAdapters.RegularLoad_DetailsTableAdapter
    Friend WithEvents RegularLoad_DetailsBindingSource As System.Windows.Forms.BindingSource
    Friend WithEvents RegularLoad_DetailsDataGridView As System.Windows.Forms.DataGridView
    Friend WithEvents RegularLoadDataGridView As System.Windows.Forms.DataGridView
    Friend WithEvents ProgramTableAdapter As Enrollment_System.EnrollSystemDataSetTableAdapters.ProgramTableAdapter
    Friend WithEvents MajorIDComboBox As System.Windows.Forms.ComboBox
    Friend WithEvents ProgramIDComboBox As System.Windows.Forms.ComboBox
    Friend WithEvents ProgramBindingSource As System.Windows.Forms.BindingSource
    Friend WithEvents MajorTableAdapter As Enrollment_System.EnrollSystemDataSetTableAdapters.MajorTableAdapter
    Friend WithEvents MajorBindingSource As System.Windows.Forms.BindingSource
    Friend WithEvents CourseTableAdapter As Enrollment_System.EnrollSystemDataSetTableAdapters.CourseTableAdapter
    Friend WithEvents CourseBindingSource As System.Windows.Forms.BindingSource
    Friend WithEvents DataGridViewTextBoxColumn3 As System.Windows.Forms.DataGridViewComboBoxColumn
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents DataGridViewTextBoxColumn5 As System.Windows.Forms.DataGridViewComboBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn6 As System.Windows.Forms.DataGridViewComboBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn7 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn8 As System.Windows.Forms.DataGridViewTextBoxColumn
End Class

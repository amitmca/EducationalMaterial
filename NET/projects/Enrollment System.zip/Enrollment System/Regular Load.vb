﻿Public Class Regular_Load

    Private Sub RegularLoadBindingNavigatorSaveItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles RegularLoadBindingNavigatorSaveItem.Click
        Me.Validate()
        Me.RegularLoadBindingSource.EndEdit()
        Me.TableAdapterManager.UpdateAll(Me.EnrollSystemDataSet)

    End Sub

    Private Sub Regular_Load_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'TODO: This line of code loads data into the 'EnrollSystemDataSet.Course' table. You can move, or remove it, as needed.
        Me.CourseTableAdapter.Fill(Me.EnrollSystemDataSet.Course)
        'TODO: This line of code loads data into the 'EnrollSystemDataSet.Major' table. You can move, or remove it, as needed.
        Me.MajorTableAdapter.Fill(Me.EnrollSystemDataSet.Major)
        'TODO: This line of code loads data into the 'EnrollSystemDataSet.Program' table. You can move, or remove it, as needed.
        Me.ProgramTableAdapter.Fill(Me.EnrollSystemDataSet.Program)
        Me.RegularLoadTableAdapter.Fill(Me.EnrollSystemDataSet.RegularLoad)
        Me.RegularLoad_DetailsTableAdapter.Fill(Me.EnrollSystemDataSet.RegularLoad_Details)
    End Sub

End Class
﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Students
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container
        Dim IDNoLabel As System.Windows.Forms.Label
        Dim LastNameLabel As System.Windows.Forms.Label
        Dim FirstNameLabel As System.Windows.Forms.Label
        Dim MiddleNameLabel As System.Windows.Forms.Label
        Dim GenderLabel As System.Windows.Forms.Label
        Dim AddressLabel As System.Windows.Forms.Label
        Dim ParentGuardianLabel As System.Windows.Forms.Label
        Dim ProgramIDLabel As System.Windows.Forms.Label
        Dim DateofBirthLabel As System.Windows.Forms.Label
        Dim PlaceofBirthLabel As System.Windows.Forms.Label
        Dim ScholarshipLabel As System.Windows.Forms.Label
        Dim ElemSchoolLabel As System.Windows.Forms.Label
        Dim ESAddressLabel As System.Windows.Forms.Label
        Dim ESSchYearLabel As System.Windows.Forms.Label
        Dim ProgramIDLabel1 As System.Windows.Forms.Label
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Students))
        Me.TabControl1 = New System.Windows.Forms.TabControl
        Me.TabPage1 = New System.Windows.Forms.TabPage
        Me.ProgramIDTextBox = New System.Windows.Forms.TextBox
        Me.StudentsBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.EnrollSystemDataSet = New Enrollment_System.EnrollSystemDataSet
        Me.GroupBox2 = New System.Windows.Forms.GroupBox
        Me.Label4 = New System.Windows.Forms.Label
        Me.Label3 = New System.Windows.Forms.Label
        Me.Label2 = New System.Windows.Forms.Label
        Me.ElemSchoolTextBox = New System.Windows.Forms.TextBox
        Me.ESAddressTextBox = New System.Windows.Forms.TextBox
        Me.ESSchYearTextBox = New System.Windows.Forms.TextBox
        Me.SecSchoolTextBox = New System.Windows.Forms.TextBox
        Me.SSAddressTextBox = New System.Windows.Forms.TextBox
        Me.SSSchYearTextBox = New System.Windows.Forms.TextBox
        Me.TerSchoolTextBox = New System.Windows.Forms.TextBox
        Me.TSAddressTextBox = New System.Windows.Forms.TextBox
        Me.TSSchYrTextBox = New System.Windows.Forms.TextBox
        Me.GroupBox1 = New System.Windows.Forms.GroupBox
        Me.OrigTRCheckBox = New System.Windows.Forms.CheckBox
        Me.Form137CheckBox = New System.Windows.Forms.CheckBox
        Me.BirthCertificateCheckBox = New System.Windows.Forms.CheckBox
        Me.Label1 = New System.Windows.Forms.Label
        Me.IDNoTextBox = New System.Windows.Forms.TextBox
        Me.LastNameTextBox = New System.Windows.Forms.TextBox
        Me.FirstNameTextBox = New System.Windows.Forms.TextBox
        Me.MiddleNameTextBox = New System.Windows.Forms.TextBox
        Me.GenderTextBox = New System.Windows.Forms.TextBox
        Me.AddressTextBox = New System.Windows.Forms.TextBox
        Me.ParentGuardianTextBox = New System.Windows.Forms.TextBox
        Me.ProgramIDComboBox = New System.Windows.Forms.ComboBox
        Me.ProgramBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.DateofBirthDateTimePicker = New System.Windows.Forms.DateTimePicker
        Me.PlaceofBirthTextBox = New System.Windows.Forms.TextBox
        Me.ScholarshipTextBox = New System.Windows.Forms.TextBox
        Me.TabPage2 = New System.Windows.Forms.TabPage
        Me.SchYrSemCourseJoinDataGridView = New System.Windows.Forms.DataGridView
        Me.DataGridViewTextBoxColumn8 = New System.Windows.Forms.DataGridViewComboBoxColumn
        Me.CourseBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.DataGridViewTextBoxColumn9 = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.DataGridViewTextBoxColumn10 = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.DataGridViewTextBoxColumn11 = New System.Windows.Forms.DataGridViewComboBoxColumn
        Me.DataGridViewTextBoxColumn12 = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.DataGridViewTextBoxColumn13 = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.SchYrSemCourseJoinBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.SchYrSemBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.SchYrSemDataGridView = New System.Windows.Forms.DataGridView
        Me.SchYrSemID = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.DataGridViewTextBoxColumn3 = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.DataGridViewTextBoxColumn4 = New System.Windows.Forms.DataGridViewComboBoxColumn
        Me.DataGridViewTextBoxColumn5 = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.DataGridViewTextBoxColumn6 = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.ProgramID = New System.Windows.Forms.DataGridViewComboBoxColumn
        Me.DataGridViewTextBoxColumn7 = New System.Windows.Forms.DataGridViewComboBoxColumn
        Me.MajorBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.DataGridViewCheckBoxColumn1 = New System.Windows.Forms.DataGridViewCheckBoxColumn
        Me.FillCourseButton = New System.Windows.Forms.DataGridViewButtonColumn
        Me.ProgramAlias = New System.Windows.Forms.DataGridViewComboBoxColumn
        Me.Remarks = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.TabPage3 = New System.Windows.Forms.TabPage
        Me.StudentsDataGridView = New System.Windows.Forms.DataGridView
        Me.DataGridViewTextBoxColumn17 = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.DataGridViewTextBoxColumn18 = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.DataGridViewTextBoxColumn19 = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.DataGridViewTextBoxColumn20 = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.DataGridViewTextBoxColumn21 = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.DataGridViewTextBoxColumn22 = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.DataGridViewTextBoxColumn23 = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.DataGridViewTextBoxColumn24 = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.DataGridViewTextBoxColumn25 = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.DataGridViewTextBoxColumn26 = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.DataGridViewTextBoxColumn27 = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.DataGridViewCheckBoxColumn3 = New System.Windows.Forms.DataGridViewCheckBoxColumn
        Me.DataGridViewCheckBoxColumn4 = New System.Windows.Forms.DataGridViewCheckBoxColumn
        Me.DataGridViewCheckBoxColumn5 = New System.Windows.Forms.DataGridViewCheckBoxColumn
        Me.DataGridViewTextBoxColumn28 = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.DataGridViewTextBoxColumn29 = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.DataGridViewTextBoxColumn30 = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.DataGridViewTextBoxColumn31 = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.DataGridViewTextBoxColumn32 = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.DataGridViewTextBoxColumn33 = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.DataGridViewTextBoxColumn34 = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.DataGridViewTextBoxColumn35 = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.DataGridViewTextBoxColumn36 = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.StudentsBindingNavigator = New System.Windows.Forms.BindingNavigator(Me.components)
        Me.BindingNavigatorAddNewItem = New System.Windows.Forms.ToolStripButton
        Me.BindingNavigatorCountItem = New System.Windows.Forms.ToolStripLabel
        Me.BindingNavigatorDeleteItem = New System.Windows.Forms.ToolStripButton
        Me.BindingNavigatorMoveFirstItem = New System.Windows.Forms.ToolStripButton
        Me.BindingNavigatorMovePreviousItem = New System.Windows.Forms.ToolStripButton
        Me.BindingNavigatorSeparator = New System.Windows.Forms.ToolStripSeparator
        Me.BindingNavigatorPositionItem = New System.Windows.Forms.ToolStripTextBox
        Me.BindingNavigatorSeparator1 = New System.Windows.Forms.ToolStripSeparator
        Me.BindingNavigatorMoveNextItem = New System.Windows.Forms.ToolStripButton
        Me.BindingNavigatorMoveLastItem = New System.Windows.Forms.ToolStripButton
        Me.BindingNavigatorSeparator2 = New System.Windows.Forms.ToolStripSeparator
        Me.StudentsBindingNavigatorSaveItem = New System.Windows.Forms.ToolStripButton
        Me.StudentsTableAdapter = New Enrollment_System.EnrollSystemDataSetTableAdapters.StudentsTableAdapter
        Me.TableAdapterManager = New Enrollment_System.EnrollSystemDataSetTableAdapters.TableAdapterManager
        Me.CourseTableAdapter = New Enrollment_System.EnrollSystemDataSetTableAdapters.CourseTableAdapter
        Me.MajorTableAdapter = New Enrollment_System.EnrollSystemDataSetTableAdapters.MajorTableAdapter
        Me.ProgramTableAdapter = New Enrollment_System.EnrollSystemDataSetTableAdapters.ProgramTableAdapter
        Me.RegularLoad_DetailsTableAdapter = New Enrollment_System.EnrollSystemDataSetTableAdapters.RegularLoad_DetailsTableAdapter
        Me.RegularLoadTableAdapter = New Enrollment_System.EnrollSystemDataSetTableAdapters.RegularLoadTableAdapter
        Me.SchYrSemCourseJoinTableAdapter = New Enrollment_System.EnrollSystemDataSetTableAdapters.SchYrSemCourseJoinTableAdapter
        Me.SchYrSemTableAdapter = New Enrollment_System.EnrollSystemDataSetTableAdapters.SchYrSemTableAdapter
        Me.Panel1 = New System.Windows.Forms.Panel
        Me.Label6 = New System.Windows.Forms.Label
        Me.Label5 = New System.Windows.Forms.Label
        Me.txtSearchName = New System.Windows.Forms.TextBox
        Me.RegularLoadBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.RegularLoad_DetailsBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.StudentsBindingSource1 = New System.Windows.Forms.BindingSource(Me.components)
        IDNoLabel = New System.Windows.Forms.Label
        LastNameLabel = New System.Windows.Forms.Label
        FirstNameLabel = New System.Windows.Forms.Label
        MiddleNameLabel = New System.Windows.Forms.Label
        GenderLabel = New System.Windows.Forms.Label
        AddressLabel = New System.Windows.Forms.Label
        ParentGuardianLabel = New System.Windows.Forms.Label
        ProgramIDLabel = New System.Windows.Forms.Label
        DateofBirthLabel = New System.Windows.Forms.Label
        PlaceofBirthLabel = New System.Windows.Forms.Label
        ScholarshipLabel = New System.Windows.Forms.Label
        ElemSchoolLabel = New System.Windows.Forms.Label
        ESAddressLabel = New System.Windows.Forms.Label
        ESSchYearLabel = New System.Windows.Forms.Label
        ProgramIDLabel1 = New System.Windows.Forms.Label
        Me.TabControl1.SuspendLayout()
        Me.TabPage1.SuspendLayout()
        CType(Me.StudentsBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.EnrollSystemDataSet, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox2.SuspendLayout()
        Me.GroupBox1.SuspendLayout()
        CType(Me.ProgramBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.TabPage2.SuspendLayout()
        CType(Me.SchYrSemCourseJoinDataGridView, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.CourseBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.SchYrSemCourseJoinBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.SchYrSemBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.SchYrSemDataGridView, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.MajorBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.TabPage3.SuspendLayout()
        CType(Me.StudentsDataGridView, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.StudentsBindingNavigator, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.StudentsBindingNavigator.SuspendLayout()
        Me.Panel1.SuspendLayout()
        CType(Me.RegularLoadBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.RegularLoad_DetailsBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.StudentsBindingSource1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'IDNoLabel
        '
        IDNoLabel.AutoSize = True
        IDNoLabel.Location = New System.Drawing.Point(19, 17)
        IDNoLabel.Name = "IDNoLabel"
        IDNoLabel.Size = New System.Drawing.Size(35, 13)
        IDNoLabel.TabIndex = 0
        IDNoLabel.Text = "IDNo:"
        '
        'LastNameLabel
        '
        LastNameLabel.AutoSize = True
        LastNameLabel.Location = New System.Drawing.Point(109, 43)
        LastNameLabel.Name = "LastNameLabel"
        LastNameLabel.Size = New System.Drawing.Size(58, 13)
        LastNameLabel.TabIndex = 2
        LastNameLabel.Text = "Last Name"
        '
        'FirstNameLabel
        '
        FirstNameLabel.AutoSize = True
        FirstNameLabel.Location = New System.Drawing.Point(318, 43)
        FirstNameLabel.Name = "FirstNameLabel"
        FirstNameLabel.Size = New System.Drawing.Size(57, 13)
        FirstNameLabel.TabIndex = 4
        FirstNameLabel.Text = "First Name"
        '
        'MiddleNameLabel
        '
        MiddleNameLabel.AutoSize = True
        MiddleNameLabel.Location = New System.Drawing.Point(524, 43)
        MiddleNameLabel.Name = "MiddleNameLabel"
        MiddleNameLabel.Size = New System.Drawing.Size(69, 13)
        MiddleNameLabel.TabIndex = 6
        MiddleNameLabel.Text = "Middle Name"
        '
        'GenderLabel
        '
        GenderLabel.AutoSize = True
        GenderLabel.Location = New System.Drawing.Point(19, 89)
        GenderLabel.Name = "GenderLabel"
        GenderLabel.Size = New System.Drawing.Size(45, 13)
        GenderLabel.TabIndex = 8
        GenderLabel.Text = "Gender:"
        '
        'AddressLabel
        '
        AddressLabel.AutoSize = True
        AddressLabel.Location = New System.Drawing.Point(19, 115)
        AddressLabel.Name = "AddressLabel"
        AddressLabel.Size = New System.Drawing.Size(48, 13)
        AddressLabel.TabIndex = 10
        AddressLabel.Text = "Address:"
        '
        'ParentGuardianLabel
        '
        ParentGuardianLabel.AutoSize = True
        ParentGuardianLabel.Location = New System.Drawing.Point(19, 141)
        ParentGuardianLabel.Name = "ParentGuardianLabel"
        ParentGuardianLabel.Size = New System.Drawing.Size(87, 13)
        ParentGuardianLabel.TabIndex = 12
        ParentGuardianLabel.Text = "Parent Guardian:"
        '
        'ProgramIDLabel
        '
        ProgramIDLabel.AutoSize = True
        ProgramIDLabel.Location = New System.Drawing.Point(19, 167)
        ProgramIDLabel.Name = "ProgramIDLabel"
        ProgramIDLabel.Size = New System.Drawing.Size(63, 13)
        ProgramIDLabel.TabIndex = 14
        ProgramIDLabel.Text = "Program ID:"
        '
        'DateofBirthLabel
        '
        DateofBirthLabel.AutoSize = True
        DateofBirthLabel.Location = New System.Drawing.Point(19, 195)
        DateofBirthLabel.Name = "DateofBirthLabel"
        DateofBirthLabel.Size = New System.Drawing.Size(66, 13)
        DateofBirthLabel.TabIndex = 16
        DateofBirthLabel.Text = "Dateof Birth:"
        '
        'PlaceofBirthLabel
        '
        PlaceofBirthLabel.AutoSize = True
        PlaceofBirthLabel.Location = New System.Drawing.Point(19, 221)
        PlaceofBirthLabel.Name = "PlaceofBirthLabel"
        PlaceofBirthLabel.Size = New System.Drawing.Size(70, 13)
        PlaceofBirthLabel.TabIndex = 18
        PlaceofBirthLabel.Text = "Placeof Birth:"
        '
        'ScholarshipLabel
        '
        ScholarshipLabel.AutoSize = True
        ScholarshipLabel.Location = New System.Drawing.Point(19, 247)
        ScholarshipLabel.Name = "ScholarshipLabel"
        ScholarshipLabel.Size = New System.Drawing.Size(65, 13)
        ScholarshipLabel.TabIndex = 20
        ScholarshipLabel.Text = "Scholarship:"
        '
        'ElemSchoolLabel
        '
        ElemSchoolLabel.AutoSize = True
        ElemSchoolLabel.Location = New System.Drawing.Point(111, 19)
        ElemSchoolLabel.Name = "ElemSchoolLabel"
        ElemSchoolLabel.Size = New System.Drawing.Size(69, 13)
        ElemSchoolLabel.TabIndex = 46
        ElemSchoolLabel.Text = "Elem School:"
        '
        'ESAddressLabel
        '
        ESAddressLabel.AutoSize = True
        ESAddressLabel.Location = New System.Drawing.Point(324, 16)
        ESAddressLabel.Name = "ESAddressLabel"
        ESAddressLabel.Size = New System.Drawing.Size(62, 13)
        ESAddressLabel.TabIndex = 48
        ESAddressLabel.Text = "ESAddress:"
        '
        'ESSchYearLabel
        '
        ESSchYearLabel.AutoSize = True
        ESSchYearLabel.Location = New System.Drawing.Point(539, 19)
        ESSchYearLabel.Name = "ESSchYearLabel"
        ESSchYearLabel.Size = New System.Drawing.Size(68, 13)
        ESSchYearLabel.TabIndex = 50
        ESSchYearLabel.Text = "ESSch Year:"
        '
        'ProgramIDLabel1
        '
        ProgramIDLabel1.AutoSize = True
        ProgramIDLabel1.Location = New System.Drawing.Point(370, 222)
        ProgramIDLabel1.Name = "ProgramIDLabel1"
        ProgramIDLabel1.Size = New System.Drawing.Size(63, 13)
        ProgramIDLabel1.TabIndex = 48
        ProgramIDLabel1.Text = "Program ID:"
        '
        'TabControl1
        '
        Me.TabControl1.Controls.Add(Me.TabPage1)
        Me.TabControl1.Controls.Add(Me.TabPage2)
        Me.TabControl1.Controls.Add(Me.TabPage3)
        Me.TabControl1.Location = New System.Drawing.Point(12, 48)
        Me.TabControl1.Name = "TabControl1"
        Me.TabControl1.SelectedIndex = 0
        Me.TabControl1.Size = New System.Drawing.Size(737, 483)
        Me.TabControl1.TabIndex = 0
        '
        'TabPage1
        '
        Me.TabPage1.AutoScroll = True
        Me.TabPage1.Controls.Add(ProgramIDLabel1)
        Me.TabPage1.Controls.Add(Me.ProgramIDTextBox)
        Me.TabPage1.Controls.Add(Me.GroupBox2)
        Me.TabPage1.Controls.Add(Me.GroupBox1)
        Me.TabPage1.Controls.Add(Me.Label1)
        Me.TabPage1.Controls.Add(IDNoLabel)
        Me.TabPage1.Controls.Add(Me.IDNoTextBox)
        Me.TabPage1.Controls.Add(LastNameLabel)
        Me.TabPage1.Controls.Add(Me.LastNameTextBox)
        Me.TabPage1.Controls.Add(FirstNameLabel)
        Me.TabPage1.Controls.Add(Me.FirstNameTextBox)
        Me.TabPage1.Controls.Add(MiddleNameLabel)
        Me.TabPage1.Controls.Add(Me.MiddleNameTextBox)
        Me.TabPage1.Controls.Add(GenderLabel)
        Me.TabPage1.Controls.Add(Me.GenderTextBox)
        Me.TabPage1.Controls.Add(AddressLabel)
        Me.TabPage1.Controls.Add(Me.AddressTextBox)
        Me.TabPage1.Controls.Add(ParentGuardianLabel)
        Me.TabPage1.Controls.Add(Me.ParentGuardianTextBox)
        Me.TabPage1.Controls.Add(ProgramIDLabel)
        Me.TabPage1.Controls.Add(Me.ProgramIDComboBox)
        Me.TabPage1.Controls.Add(DateofBirthLabel)
        Me.TabPage1.Controls.Add(Me.DateofBirthDateTimePicker)
        Me.TabPage1.Controls.Add(PlaceofBirthLabel)
        Me.TabPage1.Controls.Add(Me.PlaceofBirthTextBox)
        Me.TabPage1.Controls.Add(ScholarshipLabel)
        Me.TabPage1.Controls.Add(Me.ScholarshipTextBox)
        Me.TabPage1.Location = New System.Drawing.Point(4, 22)
        Me.TabPage1.Name = "TabPage1"
        Me.TabPage1.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage1.Size = New System.Drawing.Size(729, 457)
        Me.TabPage1.TabIndex = 0
        Me.TabPage1.Text = "Info"
        Me.TabPage1.UseVisualStyleBackColor = True
        '
        'ProgramIDTextBox
        '
        Me.ProgramIDTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.StudentsBindingSource, "ProgramID", True))
        Me.ProgramIDTextBox.Location = New System.Drawing.Point(439, 219)
        Me.ProgramIDTextBox.Name = "ProgramIDTextBox"
        Me.ProgramIDTextBox.Size = New System.Drawing.Size(100, 20)
        Me.ProgramIDTextBox.TabIndex = 49
        '
        'StudentsBindingSource
        '
        Me.StudentsBindingSource.DataMember = "Students"
        Me.StudentsBindingSource.DataSource = Me.EnrollSystemDataSet
        '
        'EnrollSystemDataSet
        '
        Me.EnrollSystemDataSet.DataSetName = "EnrollSystemDataSet"
        Me.EnrollSystemDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'GroupBox2
        '
        Me.GroupBox2.Controls.Add(Me.Label4)
        Me.GroupBox2.Controls.Add(Me.Label3)
        Me.GroupBox2.Controls.Add(Me.Label2)
        Me.GroupBox2.Controls.Add(ElemSchoolLabel)
        Me.GroupBox2.Controls.Add(Me.ElemSchoolTextBox)
        Me.GroupBox2.Controls.Add(ESAddressLabel)
        Me.GroupBox2.Controls.Add(Me.ESAddressTextBox)
        Me.GroupBox2.Controls.Add(ESSchYearLabel)
        Me.GroupBox2.Controls.Add(Me.ESSchYearTextBox)
        Me.GroupBox2.Controls.Add(Me.SecSchoolTextBox)
        Me.GroupBox2.Controls.Add(Me.SSAddressTextBox)
        Me.GroupBox2.Controls.Add(Me.SSSchYearTextBox)
        Me.GroupBox2.Controls.Add(Me.TerSchoolTextBox)
        Me.GroupBox2.Controls.Add(Me.TSAddressTextBox)
        Me.GroupBox2.Controls.Add(Me.TSSchYrTextBox)
        Me.GroupBox2.Location = New System.Drawing.Point(22, 331)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(663, 123)
        Me.GroupBox2.TabIndex = 48
        Me.GroupBox2.TabStop = False
        Me.GroupBox2.Text = "School Info"
        '
        'Label4
        '
        Me.Label4.Location = New System.Drawing.Point(8, 80)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(100, 23)
        Me.Label4.TabIndex = 109
        Me.Label4.Text = "Tertiary:"
        '
        'Label3
        '
        Me.Label3.Location = New System.Drawing.Point(8, 56)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(100, 23)
        Me.Label3.TabIndex = 108
        Me.Label3.Text = "Secondary:"
        '
        'Label2
        '
        Me.Label2.Location = New System.Drawing.Point(8, 32)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(100, 23)
        Me.Label2.TabIndex = 107
        Me.Label2.Text = "Elementary:"
        '
        'ElemSchoolTextBox
        '
        Me.ElemSchoolTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.StudentsBindingSource, "ElemSchool", True))
        Me.ElemSchoolTextBox.Location = New System.Drawing.Point(114, 35)
        Me.ElemSchoolTextBox.Name = "ElemSchoolTextBox"
        Me.ElemSchoolTextBox.Size = New System.Drawing.Size(200, 20)
        Me.ElemSchoolTextBox.TabIndex = 47
        '
        'ESAddressTextBox
        '
        Me.ESAddressTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.StudentsBindingSource, "ESAddress", True))
        Me.ESAddressTextBox.Location = New System.Drawing.Point(327, 35)
        Me.ESAddressTextBox.Name = "ESAddressTextBox"
        Me.ESAddressTextBox.Size = New System.Drawing.Size(200, 20)
        Me.ESAddressTextBox.TabIndex = 49
        '
        'ESSchYearTextBox
        '
        Me.ESSchYearTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.StudentsBindingSource, "ESSchYear", True))
        Me.ESSchYearTextBox.Location = New System.Drawing.Point(542, 35)
        Me.ESSchYearTextBox.Name = "ESSchYearTextBox"
        Me.ESSchYearTextBox.Size = New System.Drawing.Size(115, 20)
        Me.ESSchYearTextBox.TabIndex = 51
        '
        'SecSchoolTextBox
        '
        Me.SecSchoolTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.StudentsBindingSource, "SecSchool", True))
        Me.SecSchoolTextBox.Location = New System.Drawing.Point(114, 59)
        Me.SecSchoolTextBox.Name = "SecSchoolTextBox"
        Me.SecSchoolTextBox.Size = New System.Drawing.Size(200, 20)
        Me.SecSchoolTextBox.TabIndex = 53
        '
        'SSAddressTextBox
        '
        Me.SSAddressTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.StudentsBindingSource, "SSAddress", True))
        Me.SSAddressTextBox.Location = New System.Drawing.Point(327, 61)
        Me.SSAddressTextBox.Name = "SSAddressTextBox"
        Me.SSAddressTextBox.Size = New System.Drawing.Size(200, 20)
        Me.SSAddressTextBox.TabIndex = 55
        '
        'SSSchYearTextBox
        '
        Me.SSSchYearTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.StudentsBindingSource, "SSSchYear", True))
        Me.SSSchYearTextBox.Location = New System.Drawing.Point(542, 61)
        Me.SSSchYearTextBox.Name = "SSSchYearTextBox"
        Me.SSSchYearTextBox.Size = New System.Drawing.Size(115, 20)
        Me.SSSchYearTextBox.TabIndex = 57
        '
        'TerSchoolTextBox
        '
        Me.TerSchoolTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.StudentsBindingSource, "TerSchool", True))
        Me.TerSchoolTextBox.Location = New System.Drawing.Point(114, 85)
        Me.TerSchoolTextBox.Name = "TerSchoolTextBox"
        Me.TerSchoolTextBox.Size = New System.Drawing.Size(200, 20)
        Me.TerSchoolTextBox.TabIndex = 59
        '
        'TSAddressTextBox
        '
        Me.TSAddressTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.StudentsBindingSource, "TSAddress", True))
        Me.TSAddressTextBox.Location = New System.Drawing.Point(327, 87)
        Me.TSAddressTextBox.Name = "TSAddressTextBox"
        Me.TSAddressTextBox.Size = New System.Drawing.Size(200, 20)
        Me.TSAddressTextBox.TabIndex = 61
        '
        'TSSchYrTextBox
        '
        Me.TSSchYrTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.StudentsBindingSource, "TSSchYr", True))
        Me.TSSchYrTextBox.Location = New System.Drawing.Point(542, 87)
        Me.TSSchYrTextBox.Name = "TSSchYrTextBox"
        Me.TSSchYrTextBox.Size = New System.Drawing.Size(115, 20)
        Me.TSSchYrTextBox.TabIndex = 63
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.OrigTRCheckBox)
        Me.GroupBox1.Controls.Add(Me.Form137CheckBox)
        Me.GroupBox1.Controls.Add(Me.BirthCertificateCheckBox)
        Me.GroupBox1.Location = New System.Drawing.Point(22, 277)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(648, 48)
        Me.GroupBox1.TabIndex = 47
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Document Submitted"
        '
        'OrigTRCheckBox
        '
        Me.OrigTRCheckBox.AutoSize = True
        Me.OrigTRCheckBox.DataBindings.Add(New System.Windows.Forms.Binding("CheckState", Me.StudentsBindingSource, "OrigTR", True))
        Me.OrigTRCheckBox.Location = New System.Drawing.Point(368, 19)
        Me.OrigTRCheckBox.Name = "OrigTRCheckBox"
        Me.OrigTRCheckBox.Size = New System.Drawing.Size(63, 17)
        Me.OrigTRCheckBox.TabIndex = 28
        Me.OrigTRCheckBox.Text = "Orig TR"
        Me.OrigTRCheckBox.UseVisualStyleBackColor = True
        '
        'Form137CheckBox
        '
        Me.Form137CheckBox.AutoSize = True
        Me.Form137CheckBox.DataBindings.Add(New System.Windows.Forms.Binding("CheckState", Me.StudentsBindingSource, "Form137", True))
        Me.Form137CheckBox.Location = New System.Drawing.Point(205, 19)
        Me.Form137CheckBox.Name = "Form137CheckBox"
        Me.Form137CheckBox.Size = New System.Drawing.Size(67, 17)
        Me.Form137CheckBox.TabIndex = 26
        Me.Form137CheckBox.Text = "Form137"
        Me.Form137CheckBox.UseVisualStyleBackColor = True
        '
        'BirthCertificateCheckBox
        '
        Me.BirthCertificateCheckBox.AutoSize = True
        Me.BirthCertificateCheckBox.DataBindings.Add(New System.Windows.Forms.Binding("CheckState", Me.StudentsBindingSource, "BirthCertificate", True))
        Me.BirthCertificateCheckBox.Location = New System.Drawing.Point(25, 19)
        Me.BirthCertificateCheckBox.Name = "BirthCertificateCheckBox"
        Me.BirthCertificateCheckBox.Size = New System.Drawing.Size(97, 17)
        Me.BirthCertificateCheckBox.TabIndex = 23
        Me.BirthCertificateCheckBox.Text = "Birth Certificate"
        Me.BirthCertificateCheckBox.UseVisualStyleBackColor = True
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(22, 59)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(38, 13)
        Me.Label1.TabIndex = 46
        Me.Label1.Text = "Name:"
        '
        'IDNoTextBox
        '
        Me.IDNoTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.StudentsBindingSource, "IDNo", True))
        Me.IDNoTextBox.Location = New System.Drawing.Point(112, 14)
        Me.IDNoTextBox.Name = "IDNoTextBox"
        Me.IDNoTextBox.Size = New System.Drawing.Size(113, 20)
        Me.IDNoTextBox.TabIndex = 1
        '
        'LastNameTextBox
        '
        Me.LastNameTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.StudentsBindingSource, "LastName", True))
        Me.LastNameTextBox.Location = New System.Drawing.Point(112, 59)
        Me.LastNameTextBox.Name = "LastNameTextBox"
        Me.LastNameTextBox.Size = New System.Drawing.Size(200, 20)
        Me.LastNameTextBox.TabIndex = 3
        '
        'FirstNameTextBox
        '
        Me.FirstNameTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.StudentsBindingSource, "FirstName", True))
        Me.FirstNameTextBox.Location = New System.Drawing.Point(321, 59)
        Me.FirstNameTextBox.Name = "FirstNameTextBox"
        Me.FirstNameTextBox.Size = New System.Drawing.Size(200, 20)
        Me.FirstNameTextBox.TabIndex = 5
        '
        'MiddleNameTextBox
        '
        Me.MiddleNameTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.StudentsBindingSource, "MiddleName", True))
        Me.MiddleNameTextBox.Location = New System.Drawing.Point(527, 59)
        Me.MiddleNameTextBox.Name = "MiddleNameTextBox"
        Me.MiddleNameTextBox.Size = New System.Drawing.Size(129, 20)
        Me.MiddleNameTextBox.TabIndex = 7
        '
        'GenderTextBox
        '
        Me.GenderTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.StudentsBindingSource, "Gender", True))
        Me.GenderTextBox.Location = New System.Drawing.Point(112, 86)
        Me.GenderTextBox.Name = "GenderTextBox"
        Me.GenderTextBox.Size = New System.Drawing.Size(200, 20)
        Me.GenderTextBox.TabIndex = 9
        '
        'AddressTextBox
        '
        Me.AddressTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.StudentsBindingSource, "Address", True))
        Me.AddressTextBox.Location = New System.Drawing.Point(112, 112)
        Me.AddressTextBox.Name = "AddressTextBox"
        Me.AddressTextBox.Size = New System.Drawing.Size(200, 20)
        Me.AddressTextBox.TabIndex = 11
        '
        'ParentGuardianTextBox
        '
        Me.ParentGuardianTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.StudentsBindingSource, "ParentGuardian", True))
        Me.ParentGuardianTextBox.Location = New System.Drawing.Point(112, 138)
        Me.ParentGuardianTextBox.Name = "ParentGuardianTextBox"
        Me.ParentGuardianTextBox.Size = New System.Drawing.Size(200, 20)
        Me.ParentGuardianTextBox.TabIndex = 13
        '
        'ProgramIDComboBox
        '
        Me.ProgramIDComboBox.DataBindings.Add(New System.Windows.Forms.Binding("SelectedValue", Me.StudentsBindingSource, "ProgramID", True))
        Me.ProgramIDComboBox.DataSource = Me.ProgramBindingSource
        Me.ProgramIDComboBox.DisplayMember = "ProgramTitle"
        Me.ProgramIDComboBox.FormattingEnabled = True
        Me.ProgramIDComboBox.Location = New System.Drawing.Point(112, 164)
        Me.ProgramIDComboBox.Name = "ProgramIDComboBox"
        Me.ProgramIDComboBox.Size = New System.Drawing.Size(200, 21)
        Me.ProgramIDComboBox.TabIndex = 15
        Me.ProgramIDComboBox.ValueMember = "ProgramID"
        '
        'ProgramBindingSource
        '
        Me.ProgramBindingSource.DataMember = "Program"
        Me.ProgramBindingSource.DataSource = Me.EnrollSystemDataSet
        '
        'DateofBirthDateTimePicker
        '
        Me.DateofBirthDateTimePicker.DataBindings.Add(New System.Windows.Forms.Binding("Value", Me.StudentsBindingSource, "DateofBirth", True))
        Me.DateofBirthDateTimePicker.Location = New System.Drawing.Point(112, 191)
        Me.DateofBirthDateTimePicker.Name = "DateofBirthDateTimePicker"
        Me.DateofBirthDateTimePicker.Size = New System.Drawing.Size(200, 20)
        Me.DateofBirthDateTimePicker.TabIndex = 17
        '
        'PlaceofBirthTextBox
        '
        Me.PlaceofBirthTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.StudentsBindingSource, "PlaceofBirth", True))
        Me.PlaceofBirthTextBox.Location = New System.Drawing.Point(112, 218)
        Me.PlaceofBirthTextBox.Name = "PlaceofBirthTextBox"
        Me.PlaceofBirthTextBox.Size = New System.Drawing.Size(200, 20)
        Me.PlaceofBirthTextBox.TabIndex = 19
        '
        'ScholarshipTextBox
        '
        Me.ScholarshipTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.StudentsBindingSource, "Scholarship", True))
        Me.ScholarshipTextBox.Location = New System.Drawing.Point(112, 244)
        Me.ScholarshipTextBox.Name = "ScholarshipTextBox"
        Me.ScholarshipTextBox.Size = New System.Drawing.Size(200, 20)
        Me.ScholarshipTextBox.TabIndex = 21
        '
        'TabPage2
        '
        Me.TabPage2.AutoScroll = True
        Me.TabPage2.Controls.Add(Me.SchYrSemCourseJoinDataGridView)
        Me.TabPage2.Controls.Add(Me.SchYrSemDataGridView)
        Me.TabPage2.Location = New System.Drawing.Point(4, 22)
        Me.TabPage2.Name = "TabPage2"
        Me.TabPage2.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage2.Size = New System.Drawing.Size(729, 457)
        Me.TabPage2.TabIndex = 1
        Me.TabPage2.Text = "Sch Year & Courses"
        Me.TabPage2.UseVisualStyleBackColor = True
        '
        'SchYrSemCourseJoinDataGridView
        '
        Me.SchYrSemCourseJoinDataGridView.AutoGenerateColumns = False
        Me.SchYrSemCourseJoinDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.SchYrSemCourseJoinDataGridView.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.DataGridViewTextBoxColumn8, Me.DataGridViewTextBoxColumn9, Me.DataGridViewTextBoxColumn10, Me.DataGridViewTextBoxColumn11, Me.DataGridViewTextBoxColumn12, Me.DataGridViewTextBoxColumn13})
        Me.SchYrSemCourseJoinDataGridView.DataSource = Me.SchYrSemCourseJoinBindingSource
        Me.SchYrSemCourseJoinDataGridView.Location = New System.Drawing.Point(26, 221)
        Me.SchYrSemCourseJoinDataGridView.Name = "SchYrSemCourseJoinDataGridView"
        Me.SchYrSemCourseJoinDataGridView.Size = New System.Drawing.Size(650, 220)
        Me.SchYrSemCourseJoinDataGridView.TabIndex = 1
        '
        'DataGridViewTextBoxColumn8
        '
        Me.DataGridViewTextBoxColumn8.DataPropertyName = "CourseID"
        Me.DataGridViewTextBoxColumn8.DataSource = Me.CourseBindingSource
        Me.DataGridViewTextBoxColumn8.DisplayMember = "CourseTitle"
        Me.DataGridViewTextBoxColumn8.DropDownWidth = 300
        Me.DataGridViewTextBoxColumn8.HeaderText = "Course"
        Me.DataGridViewTextBoxColumn8.Name = "DataGridViewTextBoxColumn8"
        Me.DataGridViewTextBoxColumn8.Resizable = System.Windows.Forms.DataGridViewTriState.[True]
        Me.DataGridViewTextBoxColumn8.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic
        Me.DataGridViewTextBoxColumn8.ValueMember = "CourseID"
        Me.DataGridViewTextBoxColumn8.Width = 200
        '
        'CourseBindingSource
        '
        Me.CourseBindingSource.DataMember = "Course"
        Me.CourseBindingSource.DataSource = Me.EnrollSystemDataSet
        '
        'DataGridViewTextBoxColumn9
        '
        Me.DataGridViewTextBoxColumn9.DataPropertyName = "Annotation"
        Me.DataGridViewTextBoxColumn9.HeaderText = "Annotation"
        Me.DataGridViewTextBoxColumn9.Name = "DataGridViewTextBoxColumn9"
        '
        'DataGridViewTextBoxColumn10
        '
        Me.DataGridViewTextBoxColumn10.DataPropertyName = "Final"
        Me.DataGridViewTextBoxColumn10.HeaderText = "Final"
        Me.DataGridViewTextBoxColumn10.Name = "DataGridViewTextBoxColumn10"
        '
        'DataGridViewTextBoxColumn11
        '
        Me.DataGridViewTextBoxColumn11.DataPropertyName = "ProgramID"
        Me.DataGridViewTextBoxColumn11.DataSource = Me.ProgramBindingSource
        Me.DataGridViewTextBoxColumn11.DisplayMember = "ProgramTitle"
        Me.DataGridViewTextBoxColumn11.HeaderText = "Program"
        Me.DataGridViewTextBoxColumn11.Name = "DataGridViewTextBoxColumn11"
        Me.DataGridViewTextBoxColumn11.Resizable = System.Windows.Forms.DataGridViewTriState.[True]
        Me.DataGridViewTextBoxColumn11.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic
        Me.DataGridViewTextBoxColumn11.ValueMember = "ProgramID"
        '
        'DataGridViewTextBoxColumn12
        '
        Me.DataGridViewTextBoxColumn12.DataPropertyName = "Year"
        Me.DataGridViewTextBoxColumn12.HeaderText = "Year"
        Me.DataGridViewTextBoxColumn12.Name = "DataGridViewTextBoxColumn12"
        '
        'DataGridViewTextBoxColumn13
        '
        Me.DataGridViewTextBoxColumn13.DataPropertyName = "Section"
        Me.DataGridViewTextBoxColumn13.HeaderText = "Section"
        Me.DataGridViewTextBoxColumn13.Name = "DataGridViewTextBoxColumn13"
        '
        'SchYrSemCourseJoinBindingSource
        '
        Me.SchYrSemCourseJoinBindingSource.DataMember = "FK_SchYrSemCourseJoin_SchYrSem"
        Me.SchYrSemCourseJoinBindingSource.DataSource = Me.SchYrSemBindingSource
        '
        'SchYrSemBindingSource
        '
        Me.SchYrSemBindingSource.DataMember = "FK_SchYrSem_Students"
        Me.SchYrSemBindingSource.DataSource = Me.StudentsBindingSource
        '
        'SchYrSemDataGridView
        '
        Me.SchYrSemDataGridView.AutoGenerateColumns = False
        Me.SchYrSemDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.SchYrSemDataGridView.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.SchYrSemID, Me.DataGridViewTextBoxColumn3, Me.DataGridViewTextBoxColumn4, Me.DataGridViewTextBoxColumn5, Me.DataGridViewTextBoxColumn6, Me.ProgramID, Me.DataGridViewTextBoxColumn7, Me.DataGridViewCheckBoxColumn1, Me.FillCourseButton, Me.ProgramAlias, Me.Remarks})
        Me.SchYrSemDataGridView.DataSource = Me.SchYrSemBindingSource
        Me.SchYrSemDataGridView.Location = New System.Drawing.Point(25, 25)
        Me.SchYrSemDataGridView.Name = "SchYrSemDataGridView"
        Me.SchYrSemDataGridView.Size = New System.Drawing.Size(651, 184)
        Me.SchYrSemDataGridView.TabIndex = 0
        '
        'SchYrSemID
        '
        Me.SchYrSemID.DataPropertyName = "SchYrSemID"
        Me.SchYrSemID.HeaderText = "SchYrSemID"
        Me.SchYrSemID.Name = "SchYrSemID"
        Me.SchYrSemID.ReadOnly = True
        Me.SchYrSemID.Visible = False
        '
        'DataGridViewTextBoxColumn3
        '
        Me.DataGridViewTextBoxColumn3.DataPropertyName = "SchYr"
        Me.DataGridViewTextBoxColumn3.HeaderText = "SchYr"
        Me.DataGridViewTextBoxColumn3.Name = "DataGridViewTextBoxColumn3"
        '
        'DataGridViewTextBoxColumn4
        '
        Me.DataGridViewTextBoxColumn4.DataPropertyName = "Sem"
        Me.DataGridViewTextBoxColumn4.HeaderText = "Sem"
        Me.DataGridViewTextBoxColumn4.Items.AddRange(New Object() {"1st", "2nd", "Summer"})
        Me.DataGridViewTextBoxColumn4.Name = "DataGridViewTextBoxColumn4"
        Me.DataGridViewTextBoxColumn4.Resizable = System.Windows.Forms.DataGridViewTriState.[True]
        Me.DataGridViewTextBoxColumn4.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic
        '
        'DataGridViewTextBoxColumn5
        '
        Me.DataGridViewTextBoxColumn5.DataPropertyName = "Year"
        Me.DataGridViewTextBoxColumn5.HeaderText = "Year"
        Me.DataGridViewTextBoxColumn5.Name = "DataGridViewTextBoxColumn5"
        '
        'DataGridViewTextBoxColumn6
        '
        Me.DataGridViewTextBoxColumn6.DataPropertyName = "Section"
        Me.DataGridViewTextBoxColumn6.HeaderText = "Section"
        Me.DataGridViewTextBoxColumn6.Name = "DataGridViewTextBoxColumn6"
        '
        'ProgramID
        '
        Me.ProgramID.DataPropertyName = "ProgramID"
        Me.ProgramID.DataSource = Me.ProgramBindingSource
        Me.ProgramID.DisplayMember = "ProgramTitle"
        Me.ProgramID.HeaderText = "Program"
        Me.ProgramID.Name = "ProgramID"
        Me.ProgramID.Resizable = System.Windows.Forms.DataGridViewTriState.[True]
        Me.ProgramID.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic
        Me.ProgramID.ValueMember = "ProgramID"
        '
        'DataGridViewTextBoxColumn7
        '
        Me.DataGridViewTextBoxColumn7.DataPropertyName = "MajorID"
        Me.DataGridViewTextBoxColumn7.DataSource = Me.MajorBindingSource
        Me.DataGridViewTextBoxColumn7.DisplayMember = "Major"
        Me.DataGridViewTextBoxColumn7.DropDownWidth = 300
        Me.DataGridViewTextBoxColumn7.HeaderText = "Major"
        Me.DataGridViewTextBoxColumn7.Name = "DataGridViewTextBoxColumn7"
        Me.DataGridViewTextBoxColumn7.Resizable = System.Windows.Forms.DataGridViewTriState.[True]
        Me.DataGridViewTextBoxColumn7.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic
        Me.DataGridViewTextBoxColumn7.ValueMember = "MajorID"
        Me.DataGridViewTextBoxColumn7.Width = 200
        '
        'MajorBindingSource
        '
        Me.MajorBindingSource.DataMember = "Major"
        Me.MajorBindingSource.DataSource = Me.EnrollSystemDataSet
        '
        'DataGridViewCheckBoxColumn1
        '
        Me.DataGridViewCheckBoxColumn1.DataPropertyName = "Regular"
        Me.DataGridViewCheckBoxColumn1.HeaderText = "Regular"
        Me.DataGridViewCheckBoxColumn1.Name = "DataGridViewCheckBoxColumn1"
        '
        'FillCourseButton
        '
        Me.FillCourseButton.HeaderText = "Fill Courses"
        Me.FillCourseButton.Name = "FillCourseButton"
        Me.FillCourseButton.Text = "Auto Fill Course"
        Me.FillCourseButton.UseColumnTextForButtonValue = True
        '
        'ProgramAlias
        '
        Me.ProgramAlias.DataPropertyName = "ProgramAlias"
        Me.ProgramAlias.DataSource = Me.ProgramBindingSource
        Me.ProgramAlias.DisplayMember = "ProgramTitle"
        Me.ProgramAlias.HeaderText = "ProgramAlias"
        Me.ProgramAlias.Name = "ProgramAlias"
        Me.ProgramAlias.Resizable = System.Windows.Forms.DataGridViewTriState.[True]
        Me.ProgramAlias.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic
        Me.ProgramAlias.ValueMember = "ProgramID"
        '
        'Remarks
        '
        Me.Remarks.DataPropertyName = "Remarks"
        Me.Remarks.HeaderText = "Remarks"
        Me.Remarks.Name = "Remarks"
        '
        'TabPage3
        '
        Me.TabPage3.Controls.Add(Me.StudentsDataGridView)
        Me.TabPage3.Location = New System.Drawing.Point(4, 22)
        Me.TabPage3.Name = "TabPage3"
        Me.TabPage3.Size = New System.Drawing.Size(729, 457)
        Me.TabPage3.TabIndex = 2
        Me.TabPage3.Text = "List"
        Me.TabPage3.UseVisualStyleBackColor = True
        '
        'StudentsDataGridView
        '
        Me.StudentsDataGridView.AutoGenerateColumns = False
        Me.StudentsDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.StudentsDataGridView.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.DataGridViewTextBoxColumn17, Me.DataGridViewTextBoxColumn18, Me.DataGridViewTextBoxColumn19, Me.DataGridViewTextBoxColumn20, Me.DataGridViewTextBoxColumn21, Me.DataGridViewTextBoxColumn22, Me.DataGridViewTextBoxColumn23, Me.DataGridViewTextBoxColumn24, Me.DataGridViewTextBoxColumn25, Me.DataGridViewTextBoxColumn26, Me.DataGridViewTextBoxColumn27, Me.DataGridViewCheckBoxColumn3, Me.DataGridViewCheckBoxColumn4, Me.DataGridViewCheckBoxColumn5, Me.DataGridViewTextBoxColumn28, Me.DataGridViewTextBoxColumn29, Me.DataGridViewTextBoxColumn30, Me.DataGridViewTextBoxColumn31, Me.DataGridViewTextBoxColumn32, Me.DataGridViewTextBoxColumn33, Me.DataGridViewTextBoxColumn34, Me.DataGridViewTextBoxColumn35, Me.DataGridViewTextBoxColumn36})
        Me.StudentsDataGridView.DataSource = Me.StudentsBindingSource
        Me.StudentsDataGridView.Location = New System.Drawing.Point(19, 19)
        Me.StudentsDataGridView.Name = "StudentsDataGridView"
        Me.StudentsDataGridView.Size = New System.Drawing.Size(660, 440)
        Me.StudentsDataGridView.TabIndex = 0
        '
        'DataGridViewTextBoxColumn17
        '
        Me.DataGridViewTextBoxColumn17.DataPropertyName = "IDNo"
        Me.DataGridViewTextBoxColumn17.HeaderText = "IDNo"
        Me.DataGridViewTextBoxColumn17.Name = "DataGridViewTextBoxColumn17"
        '
        'DataGridViewTextBoxColumn18
        '
        Me.DataGridViewTextBoxColumn18.DataPropertyName = "LastName"
        Me.DataGridViewTextBoxColumn18.HeaderText = "LastName"
        Me.DataGridViewTextBoxColumn18.Name = "DataGridViewTextBoxColumn18"
        '
        'DataGridViewTextBoxColumn19
        '
        Me.DataGridViewTextBoxColumn19.DataPropertyName = "FirstName"
        Me.DataGridViewTextBoxColumn19.HeaderText = "FirstName"
        Me.DataGridViewTextBoxColumn19.Name = "DataGridViewTextBoxColumn19"
        '
        'DataGridViewTextBoxColumn20
        '
        Me.DataGridViewTextBoxColumn20.DataPropertyName = "MiddleName"
        Me.DataGridViewTextBoxColumn20.HeaderText = "MiddleName"
        Me.DataGridViewTextBoxColumn20.Name = "DataGridViewTextBoxColumn20"
        '
        'DataGridViewTextBoxColumn21
        '
        Me.DataGridViewTextBoxColumn21.DataPropertyName = "Gender"
        Me.DataGridViewTextBoxColumn21.HeaderText = "Gender"
        Me.DataGridViewTextBoxColumn21.Name = "DataGridViewTextBoxColumn21"
        '
        'DataGridViewTextBoxColumn22
        '
        Me.DataGridViewTextBoxColumn22.DataPropertyName = "Address"
        Me.DataGridViewTextBoxColumn22.HeaderText = "Address"
        Me.DataGridViewTextBoxColumn22.Name = "DataGridViewTextBoxColumn22"
        '
        'DataGridViewTextBoxColumn23
        '
        Me.DataGridViewTextBoxColumn23.DataPropertyName = "ParentGuardian"
        Me.DataGridViewTextBoxColumn23.HeaderText = "ParentGuardian"
        Me.DataGridViewTextBoxColumn23.Name = "DataGridViewTextBoxColumn23"
        '
        'DataGridViewTextBoxColumn24
        '
        Me.DataGridViewTextBoxColumn24.DataPropertyName = "ProgramID"
        Me.DataGridViewTextBoxColumn24.HeaderText = "ProgramID"
        Me.DataGridViewTextBoxColumn24.Name = "DataGridViewTextBoxColumn24"
        '
        'DataGridViewTextBoxColumn25
        '
        Me.DataGridViewTextBoxColumn25.DataPropertyName = "DateofBirth"
        Me.DataGridViewTextBoxColumn25.HeaderText = "DateofBirth"
        Me.DataGridViewTextBoxColumn25.Name = "DataGridViewTextBoxColumn25"
        '
        'DataGridViewTextBoxColumn26
        '
        Me.DataGridViewTextBoxColumn26.DataPropertyName = "PlaceofBirth"
        Me.DataGridViewTextBoxColumn26.HeaderText = "PlaceofBirth"
        Me.DataGridViewTextBoxColumn26.Name = "DataGridViewTextBoxColumn26"
        '
        'DataGridViewTextBoxColumn27
        '
        Me.DataGridViewTextBoxColumn27.DataPropertyName = "Scholarship"
        Me.DataGridViewTextBoxColumn27.HeaderText = "Scholarship"
        Me.DataGridViewTextBoxColumn27.Name = "DataGridViewTextBoxColumn27"
        '
        'DataGridViewCheckBoxColumn3
        '
        Me.DataGridViewCheckBoxColumn3.DataPropertyName = "BirthCertificate"
        Me.DataGridViewCheckBoxColumn3.HeaderText = "BirthCertificate"
        Me.DataGridViewCheckBoxColumn3.Name = "DataGridViewCheckBoxColumn3"
        '
        'DataGridViewCheckBoxColumn4
        '
        Me.DataGridViewCheckBoxColumn4.DataPropertyName = "Form137"
        Me.DataGridViewCheckBoxColumn4.HeaderText = "Form137"
        Me.DataGridViewCheckBoxColumn4.Name = "DataGridViewCheckBoxColumn4"
        '
        'DataGridViewCheckBoxColumn5
        '
        Me.DataGridViewCheckBoxColumn5.DataPropertyName = "OrigTR"
        Me.DataGridViewCheckBoxColumn5.HeaderText = "OrigTR"
        Me.DataGridViewCheckBoxColumn5.Name = "DataGridViewCheckBoxColumn5"
        '
        'DataGridViewTextBoxColumn28
        '
        Me.DataGridViewTextBoxColumn28.DataPropertyName = "ElemSchool"
        Me.DataGridViewTextBoxColumn28.HeaderText = "ElemSchool"
        Me.DataGridViewTextBoxColumn28.Name = "DataGridViewTextBoxColumn28"
        '
        'DataGridViewTextBoxColumn29
        '
        Me.DataGridViewTextBoxColumn29.DataPropertyName = "ESAddress"
        Me.DataGridViewTextBoxColumn29.HeaderText = "ESAddress"
        Me.DataGridViewTextBoxColumn29.Name = "DataGridViewTextBoxColumn29"
        '
        'DataGridViewTextBoxColumn30
        '
        Me.DataGridViewTextBoxColumn30.DataPropertyName = "ESSchYear"
        Me.DataGridViewTextBoxColumn30.HeaderText = "ESSchYear"
        Me.DataGridViewTextBoxColumn30.Name = "DataGridViewTextBoxColumn30"
        '
        'DataGridViewTextBoxColumn31
        '
        Me.DataGridViewTextBoxColumn31.DataPropertyName = "SecSchool"
        Me.DataGridViewTextBoxColumn31.HeaderText = "SecSchool"
        Me.DataGridViewTextBoxColumn31.Name = "DataGridViewTextBoxColumn31"
        '
        'DataGridViewTextBoxColumn32
        '
        Me.DataGridViewTextBoxColumn32.DataPropertyName = "SSAddress"
        Me.DataGridViewTextBoxColumn32.HeaderText = "SSAddress"
        Me.DataGridViewTextBoxColumn32.Name = "DataGridViewTextBoxColumn32"
        '
        'DataGridViewTextBoxColumn33
        '
        Me.DataGridViewTextBoxColumn33.DataPropertyName = "SSSchYear"
        Me.DataGridViewTextBoxColumn33.HeaderText = "SSSchYear"
        Me.DataGridViewTextBoxColumn33.Name = "DataGridViewTextBoxColumn33"
        '
        'DataGridViewTextBoxColumn34
        '
        Me.DataGridViewTextBoxColumn34.DataPropertyName = "TerSchool"
        Me.DataGridViewTextBoxColumn34.HeaderText = "TerSchool"
        Me.DataGridViewTextBoxColumn34.Name = "DataGridViewTextBoxColumn34"
        '
        'DataGridViewTextBoxColumn35
        '
        Me.DataGridViewTextBoxColumn35.DataPropertyName = "TSAddress"
        Me.DataGridViewTextBoxColumn35.HeaderText = "TSAddress"
        Me.DataGridViewTextBoxColumn35.Name = "DataGridViewTextBoxColumn35"
        '
        'DataGridViewTextBoxColumn36
        '
        Me.DataGridViewTextBoxColumn36.DataPropertyName = "TSSchYr"
        Me.DataGridViewTextBoxColumn36.HeaderText = "TSSchYr"
        Me.DataGridViewTextBoxColumn36.Name = "DataGridViewTextBoxColumn36"
        '
        'StudentsBindingNavigator
        '
        Me.StudentsBindingNavigator.AddNewItem = Me.BindingNavigatorAddNewItem
        Me.StudentsBindingNavigator.BindingSource = Me.StudentsBindingSource
        Me.StudentsBindingNavigator.CountItem = Me.BindingNavigatorCountItem
        Me.StudentsBindingNavigator.DeleteItem = Me.BindingNavigatorDeleteItem
        Me.StudentsBindingNavigator.Dock = System.Windows.Forms.DockStyle.None
        Me.StudentsBindingNavigator.ImageScalingSize = New System.Drawing.Size(26, 26)
        Me.StudentsBindingNavigator.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.BindingNavigatorMoveFirstItem, Me.BindingNavigatorMovePreviousItem, Me.BindingNavigatorSeparator, Me.BindingNavigatorPositionItem, Me.BindingNavigatorCountItem, Me.BindingNavigatorSeparator1, Me.BindingNavigatorMoveNextItem, Me.BindingNavigatorMoveLastItem, Me.BindingNavigatorSeparator2, Me.BindingNavigatorAddNewItem, Me.BindingNavigatorDeleteItem, Me.StudentsBindingNavigatorSaveItem})
        Me.StudentsBindingNavigator.Location = New System.Drawing.Point(229, 538)
        Me.StudentsBindingNavigator.MoveFirstItem = Me.BindingNavigatorMoveFirstItem
        Me.StudentsBindingNavigator.MoveLastItem = Me.BindingNavigatorMoveLastItem
        Me.StudentsBindingNavigator.MoveNextItem = Me.BindingNavigatorMoveNextItem
        Me.StudentsBindingNavigator.MovePreviousItem = Me.BindingNavigatorMovePreviousItem
        Me.StudentsBindingNavigator.Name = "StudentsBindingNavigator"
        Me.StudentsBindingNavigator.PositionItem = Me.BindingNavigatorPositionItem
        Me.StudentsBindingNavigator.Size = New System.Drawing.Size(326, 33)
        Me.StudentsBindingNavigator.TabIndex = 1
        Me.StudentsBindingNavigator.Text = "BindingNavigator1"
        '
        'BindingNavigatorAddNewItem
        '
        Me.BindingNavigatorAddNewItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorAddNewItem.Image = CType(resources.GetObject("BindingNavigatorAddNewItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorAddNewItem.Name = "BindingNavigatorAddNewItem"
        Me.BindingNavigatorAddNewItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorAddNewItem.Size = New System.Drawing.Size(30, 30)
        Me.BindingNavigatorAddNewItem.Text = "Add new"
        '
        'BindingNavigatorCountItem
        '
        Me.BindingNavigatorCountItem.Name = "BindingNavigatorCountItem"
        Me.BindingNavigatorCountItem.Size = New System.Drawing.Size(36, 30)
        Me.BindingNavigatorCountItem.Text = "of {0}"
        Me.BindingNavigatorCountItem.ToolTipText = "Total number of items"
        '
        'BindingNavigatorDeleteItem
        '
        Me.BindingNavigatorDeleteItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorDeleteItem.Image = CType(resources.GetObject("BindingNavigatorDeleteItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorDeleteItem.Name = "BindingNavigatorDeleteItem"
        Me.BindingNavigatorDeleteItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorDeleteItem.Size = New System.Drawing.Size(30, 30)
        Me.BindingNavigatorDeleteItem.Text = "Delete"
        '
        'BindingNavigatorMoveFirstItem
        '
        Me.BindingNavigatorMoveFirstItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorMoveFirstItem.Image = CType(resources.GetObject("BindingNavigatorMoveFirstItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorMoveFirstItem.Name = "BindingNavigatorMoveFirstItem"
        Me.BindingNavigatorMoveFirstItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorMoveFirstItem.Size = New System.Drawing.Size(30, 30)
        Me.BindingNavigatorMoveFirstItem.Text = "Move first"
        '
        'BindingNavigatorMovePreviousItem
        '
        Me.BindingNavigatorMovePreviousItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorMovePreviousItem.Image = CType(resources.GetObject("BindingNavigatorMovePreviousItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorMovePreviousItem.Name = "BindingNavigatorMovePreviousItem"
        Me.BindingNavigatorMovePreviousItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorMovePreviousItem.Size = New System.Drawing.Size(30, 30)
        Me.BindingNavigatorMovePreviousItem.Text = "Move previous"
        '
        'BindingNavigatorSeparator
        '
        Me.BindingNavigatorSeparator.Name = "BindingNavigatorSeparator"
        Me.BindingNavigatorSeparator.Size = New System.Drawing.Size(6, 33)
        '
        'BindingNavigatorPositionItem
        '
        Me.BindingNavigatorPositionItem.AccessibleName = "Position"
        Me.BindingNavigatorPositionItem.AutoSize = False
        Me.BindingNavigatorPositionItem.Name = "BindingNavigatorPositionItem"
        Me.BindingNavigatorPositionItem.Size = New System.Drawing.Size(50, 21)
        Me.BindingNavigatorPositionItem.Text = "0"
        Me.BindingNavigatorPositionItem.ToolTipText = "Current position"
        '
        'BindingNavigatorSeparator1
        '
        Me.BindingNavigatorSeparator1.Name = "BindingNavigatorSeparator1"
        Me.BindingNavigatorSeparator1.Size = New System.Drawing.Size(6, 33)
        '
        'BindingNavigatorMoveNextItem
        '
        Me.BindingNavigatorMoveNextItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorMoveNextItem.Image = CType(resources.GetObject("BindingNavigatorMoveNextItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorMoveNextItem.Name = "BindingNavigatorMoveNextItem"
        Me.BindingNavigatorMoveNextItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorMoveNextItem.Size = New System.Drawing.Size(30, 30)
        Me.BindingNavigatorMoveNextItem.Text = "Move next"
        '
        'BindingNavigatorMoveLastItem
        '
        Me.BindingNavigatorMoveLastItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorMoveLastItem.Image = CType(resources.GetObject("BindingNavigatorMoveLastItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorMoveLastItem.Name = "BindingNavigatorMoveLastItem"
        Me.BindingNavigatorMoveLastItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorMoveLastItem.Size = New System.Drawing.Size(30, 30)
        Me.BindingNavigatorMoveLastItem.Text = "Move last"
        '
        'BindingNavigatorSeparator2
        '
        Me.BindingNavigatorSeparator2.Name = "BindingNavigatorSeparator2"
        Me.BindingNavigatorSeparator2.Size = New System.Drawing.Size(6, 33)
        '
        'StudentsBindingNavigatorSaveItem
        '
        Me.StudentsBindingNavigatorSaveItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.StudentsBindingNavigatorSaveItem.Image = CType(resources.GetObject("StudentsBindingNavigatorSaveItem.Image"), System.Drawing.Image)
        Me.StudentsBindingNavigatorSaveItem.Name = "StudentsBindingNavigatorSaveItem"
        Me.StudentsBindingNavigatorSaveItem.Size = New System.Drawing.Size(30, 30)
        Me.StudentsBindingNavigatorSaveItem.Text = "Save Data"
        '
        'StudentsTableAdapter
        '
        Me.StudentsTableAdapter.ClearBeforeFill = True
        '
        'TableAdapterManager
        '
        Me.TableAdapterManager.BackupDataSetBeforeUpdate = False
        Me.TableAdapterManager.CourseTableAdapter = Me.CourseTableAdapter
        Me.TableAdapterManager.MajorTableAdapter = Me.MajorTableAdapter
        Me.TableAdapterManager.ProgramTableAdapter = Me.ProgramTableAdapter
        Me.TableAdapterManager.RegularLoad_DetailsTableAdapter = Me.RegularLoad_DetailsTableAdapter
        Me.TableAdapterManager.RegularLoadTableAdapter = Me.RegularLoadTableAdapter
        Me.TableAdapterManager.SchYrSemCourseJoinTableAdapter = Me.SchYrSemCourseJoinTableAdapter
        Me.TableAdapterManager.SchYrSemTableAdapter = Me.SchYrSemTableAdapter
        Me.TableAdapterManager.StudentsTableAdapter = Me.StudentsTableAdapter
        Me.TableAdapterManager.Switchboard_ItemsTableAdapter = Nothing
        Me.TableAdapterManager.UpdateOrder = Enrollment_System.EnrollSystemDataSetTableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete
        '
        'CourseTableAdapter
        '
        Me.CourseTableAdapter.ClearBeforeFill = True
        '
        'MajorTableAdapter
        '
        Me.MajorTableAdapter.ClearBeforeFill = True
        '
        'ProgramTableAdapter
        '
        Me.ProgramTableAdapter.ClearBeforeFill = True
        '
        'RegularLoad_DetailsTableAdapter
        '
        Me.RegularLoad_DetailsTableAdapter.ClearBeforeFill = True
        '
        'RegularLoadTableAdapter
        '
        Me.RegularLoadTableAdapter.ClearBeforeFill = True
        '
        'SchYrSemCourseJoinTableAdapter
        '
        Me.SchYrSemCourseJoinTableAdapter.ClearBeforeFill = True
        '
        'SchYrSemTableAdapter
        '
        Me.SchYrSemTableAdapter.ClearBeforeFill = True
        '
        'Panel1
        '
        Me.Panel1.BackColor = System.Drawing.SystemColors.ControlDark
        Me.Panel1.Controls.Add(Me.Label6)
        Me.Panel1.Controls.Add(Me.Label5)
        Me.Panel1.Controls.Add(Me.txtSearchName)
        Me.Panel1.Location = New System.Drawing.Point(13, 6)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(731, 36)
        Me.Panel1.TabIndex = 2
        '
        'Label6
        '
        Me.Label6.ForeColor = System.Drawing.Color.White
        Me.Label6.Location = New System.Drawing.Point(472, 9)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(80, 18)
        Me.Label6.TabIndex = 110
        Me.Label6.Text = "Search Name:"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Font = New System.Drawing.Font("Lucida Console", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.Location = New System.Drawing.Point(7, 8)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(240, 19)
        Me.Label5.TabIndex = 0
        Me.Label5.Text = "Student's Information"
        '
        'txtSearchName
        '
        Me.txtSearchName.Location = New System.Drawing.Point(558, 8)
        Me.txtSearchName.Name = "txtSearchName"
        Me.txtSearchName.Size = New System.Drawing.Size(160, 20)
        Me.txtSearchName.TabIndex = 109
        '
        'RegularLoadBindingSource
        '
        Me.RegularLoadBindingSource.DataMember = "RegularLoad"
        Me.RegularLoadBindingSource.DataSource = Me.EnrollSystemDataSet
        '
        'RegularLoad_DetailsBindingSource
        '
        Me.RegularLoad_DetailsBindingSource.DataMember = "RegularLoad Details"
        Me.RegularLoad_DetailsBindingSource.DataSource = Me.EnrollSystemDataSet
        '
        'StudentsBindingSource1
        '
        Me.StudentsBindingSource1.DataMember = "Students"
        Me.StudentsBindingSource1.DataSource = Me.EnrollSystemDataSet
        '
        'Students
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(761, 571)
        Me.Controls.Add(Me.Panel1)
        Me.Controls.Add(Me.StudentsBindingNavigator)
        Me.Controls.Add(Me.TabControl1)
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "Students"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Students Information"
        Me.TabControl1.ResumeLayout(False)
        Me.TabPage1.ResumeLayout(False)
        Me.TabPage1.PerformLayout()
        CType(Me.StudentsBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.EnrollSystemDataSet, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox2.ResumeLayout(False)
        Me.GroupBox2.PerformLayout()
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        CType(Me.ProgramBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        Me.TabPage2.ResumeLayout(False)
        CType(Me.SchYrSemCourseJoinDataGridView, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.CourseBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.SchYrSemCourseJoinBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.SchYrSemBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.SchYrSemDataGridView, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.MajorBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        Me.TabPage3.ResumeLayout(False)
        CType(Me.StudentsDataGridView, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.StudentsBindingNavigator, System.ComponentModel.ISupportInitialize).EndInit()
        Me.StudentsBindingNavigator.ResumeLayout(False)
        Me.StudentsBindingNavigator.PerformLayout()
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        CType(Me.RegularLoadBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.RegularLoad_DetailsBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.StudentsBindingSource1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents TabControl1 As System.Windows.Forms.TabControl
    Friend WithEvents TabPage1 As System.Windows.Forms.TabPage
    Friend WithEvents TabPage2 As System.Windows.Forms.TabPage
    Friend WithEvents EnrollSystemDataSet As Enrollment_System.EnrollSystemDataSet
    Friend WithEvents StudentsBindingSource As System.Windows.Forms.BindingSource
    Friend WithEvents StudentsTableAdapter As Enrollment_System.EnrollSystemDataSetTableAdapters.StudentsTableAdapter
    Friend WithEvents TableAdapterManager As Enrollment_System.EnrollSystemDataSetTableAdapters.TableAdapterManager
    Friend WithEvents StudentsBindingNavigator As System.Windows.Forms.BindingNavigator
    Friend WithEvents BindingNavigatorAddNewItem As System.Windows.Forms.ToolStripButton
    Friend WithEvents BindingNavigatorCountItem As System.Windows.Forms.ToolStripLabel
    Friend WithEvents BindingNavigatorDeleteItem As System.Windows.Forms.ToolStripButton
    Friend WithEvents BindingNavigatorMoveFirstItem As System.Windows.Forms.ToolStripButton
    Friend WithEvents BindingNavigatorMovePreviousItem As System.Windows.Forms.ToolStripButton
    Friend WithEvents BindingNavigatorSeparator As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents BindingNavigatorPositionItem As System.Windows.Forms.ToolStripTextBox
    Friend WithEvents BindingNavigatorSeparator1 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents BindingNavigatorMoveNextItem As System.Windows.Forms.ToolStripButton
    Friend WithEvents BindingNavigatorMoveLastItem As System.Windows.Forms.ToolStripButton
    Friend WithEvents BindingNavigatorSeparator2 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents StudentsBindingNavigatorSaveItem As System.Windows.Forms.ToolStripButton
    Friend WithEvents IDNoTextBox As System.Windows.Forms.TextBox
    Friend WithEvents LastNameTextBox As System.Windows.Forms.TextBox
    Friend WithEvents FirstNameTextBox As System.Windows.Forms.TextBox
    Friend WithEvents MiddleNameTextBox As System.Windows.Forms.TextBox
    Friend WithEvents GenderTextBox As System.Windows.Forms.TextBox
    Friend WithEvents AddressTextBox As System.Windows.Forms.TextBox
    Friend WithEvents ParentGuardianTextBox As System.Windows.Forms.TextBox
    Friend WithEvents ProgramIDComboBox As System.Windows.Forms.ComboBox
    Friend WithEvents DateofBirthDateTimePicker As System.Windows.Forms.DateTimePicker
    Friend WithEvents PlaceofBirthTextBox As System.Windows.Forms.TextBox
    Friend WithEvents ScholarshipTextBox As System.Windows.Forms.TextBox
    Friend WithEvents BirthCertificateCheckBox As System.Windows.Forms.CheckBox
    Friend WithEvents SchYrSemTableAdapter As Enrollment_System.EnrollSystemDataSetTableAdapters.SchYrSemTableAdapter
    Friend WithEvents SchYrSemBindingSource As System.Windows.Forms.BindingSource
    Friend WithEvents SchYrSemDataGridView As System.Windows.Forms.DataGridView
    Friend WithEvents CourseTableAdapter As Enrollment_System.EnrollSystemDataSetTableAdapters.CourseTableAdapter
    Friend WithEvents CourseBindingSource As System.Windows.Forms.BindingSource
    Friend WithEvents ProgramTableAdapter As Enrollment_System.EnrollSystemDataSetTableAdapters.ProgramTableAdapter
    Friend WithEvents ProgramBindingSource As System.Windows.Forms.BindingSource
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents GroupBox2 As System.Windows.Forms.GroupBox
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents ElemSchoolTextBox As System.Windows.Forms.TextBox
    Friend WithEvents ESAddressTextBox As System.Windows.Forms.TextBox
    Friend WithEvents ESSchYearTextBox As System.Windows.Forms.TextBox
    Friend WithEvents SecSchoolTextBox As System.Windows.Forms.TextBox
    Friend WithEvents SSAddressTextBox As System.Windows.Forms.TextBox
    Friend WithEvents SSSchYearTextBox As System.Windows.Forms.TextBox
    Friend WithEvents TerSchoolTextBox As System.Windows.Forms.TextBox
    Friend WithEvents TSAddressTextBox As System.Windows.Forms.TextBox
    Friend WithEvents TSSchYrTextBox As System.Windows.Forms.TextBox
    Friend WithEvents OrigTRCheckBox As System.Windows.Forms.CheckBox
    Friend WithEvents Form137CheckBox As System.Windows.Forms.CheckBox
    Friend WithEvents TabPage3 As System.Windows.Forms.TabPage
    Friend WithEvents MajorTableAdapter As Enrollment_System.EnrollSystemDataSetTableAdapters.MajorTableAdapter
    Friend WithEvents MajorBindingSource As System.Windows.Forms.BindingSource
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents SchYrSemCourseJoinTableAdapter As Enrollment_System.EnrollSystemDataSetTableAdapters.SchYrSemCourseJoinTableAdapter
    Friend WithEvents SchYrSemCourseJoinBindingSource As System.Windows.Forms.BindingSource
    Friend WithEvents SchYrSemCourseJoinDataGridView As System.Windows.Forms.DataGridView
    Friend WithEvents DataGridViewTextBoxColumn16 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn14 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn15 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn37 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn38 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents ProgramIDTextBox As System.Windows.Forms.TextBox
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents txtSearchName As System.Windows.Forms.TextBox
    Friend WithEvents StudentsDataGridView As System.Windows.Forms.DataGridView
    Friend WithEvents DataGridViewTextBoxColumn17 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn18 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn19 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn20 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn21 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn22 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn23 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn24 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn25 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn26 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn27 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewCheckBoxColumn3 As System.Windows.Forms.DataGridViewCheckBoxColumn
    Friend WithEvents DataGridViewCheckBoxColumn4 As System.Windows.Forms.DataGridViewCheckBoxColumn
    Friend WithEvents DataGridViewCheckBoxColumn5 As System.Windows.Forms.DataGridViewCheckBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn28 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn29 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn30 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn31 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn32 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn33 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn34 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn35 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn36 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents RegularLoadTableAdapter As Enrollment_System.EnrollSystemDataSetTableAdapters.RegularLoadTableAdapter
    Friend WithEvents RegularLoadBindingSource As System.Windows.Forms.BindingSource
    Friend WithEvents RegularLoad_DetailsTableAdapter As Enrollment_System.EnrollSystemDataSetTableAdapters.RegularLoad_DetailsTableAdapter
    Friend WithEvents RegularLoad_DetailsBindingSource As System.Windows.Forms.BindingSource
    Friend WithEvents SchYrSemID As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn3 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn4 As System.Windows.Forms.DataGridViewComboBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn5 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn6 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents ProgramID As System.Windows.Forms.DataGridViewComboBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn7 As System.Windows.Forms.DataGridViewComboBoxColumn
    Friend WithEvents DataGridViewCheckBoxColumn1 As System.Windows.Forms.DataGridViewCheckBoxColumn
    Friend WithEvents FillCourseButton As System.Windows.Forms.DataGridViewButtonColumn
    Friend WithEvents ProgramAlias As System.Windows.Forms.DataGridViewComboBoxColumn
    Friend WithEvents Remarks As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents StudentsBindingSource1 As System.Windows.Forms.BindingSource
    Friend WithEvents DataGridViewTextBoxColumn8 As System.Windows.Forms.DataGridViewComboBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn9 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn10 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn11 As System.Windows.Forms.DataGridViewComboBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn12 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn13 As System.Windows.Forms.DataGridViewTextBoxColumn

End Class

﻿
Public Class Students

    Private Sub StudentsBindingNavigatorSaveItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles StudentsBindingNavigatorSaveItem.Click
        Me.Validate()
        Me.StudentsBindingSource.EndEdit()
        Me.SchYrSemBindingSource.EndEdit()
        Me.SchYrSemCourseJoinBindingSource.EndEdit()
        Me.TableAdapterManager.UpdateAll(Me.EnrollSystemDataSet)
    End Sub

    Private Sub Students_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Me.RegularLoadTableAdapter.Fill(Me.EnrollSystemDataSet.RegularLoad)
        Me.RegularLoad_DetailsTableAdapter.Fill(Me.EnrollSystemDataSet.RegularLoad_Details)
        Me.MajorTableAdapter.Fill(Me.EnrollSystemDataSet.Major)
        Me.ProgramTableAdapter.Fill(Me.EnrollSystemDataSet.Program)
        Me.CourseTableAdapter.Fill(Me.EnrollSystemDataSet.Course)
    End Sub

    Private Sub SchYrSemDataGridView_CellContentClick(ByVal sender As System.Object, ByVal e As System.Windows.Forms.DataGridViewCellEventArgs) Handles SchYrSemDataGridView.CellContentClick
        If IsANonHeaderButtonCell(e) Then
            Dim rowNum As Integer = SchYrSemDataGridView.CurrentCell.RowIndex
            Dim SchYrSemIDValue As Integer = SchYrSemDataGridView(0, rowNum).Value
            Dim SemValue As String = SchYrSemDataGridView(2, rowNum).Value
            Dim YearValue As Integer = SchYrSemDataGridView(3, rowNum).Value
            Dim intProgramID = SchYrSemDataGridView(5, rowNum).Value
            Dim intMajorID As Integer = SchYrSemDataGridView(6, rowNum).Value

            With SchYrSemDataGridView
                .BindingContext(.DataSource, .DataMember).EndCurrentEdit()
            End With

            If SchYrSemDataGridView(7, rowNum).Value = False Then Exit Sub

            Dim SelectedRegularLoadID As Integer
            Dim drRegularLoadID() As DataRow = EnrollSystemDataSet.Tables("RegularLoad").Select("ProgramID = " & intProgramID & " And MajorID = " & intMajorID & " And Semester = '" & SemValue & "' And [Year] = " & YearValue)

            Dim RegularLoadID As DataRow

            If drRegularLoadID.Length = 0 Then
                MessageBox.Show("No matching record(s) found.")
                Exit Sub
            End If

            For Each RegularLoadID In drRegularLoadID
                SelectedRegularLoadID = RegularLoadID("RegularLoadID")
            Next

            Dim drSelectedRegularLoad As DataRow
            drSelectedRegularLoad = _
               EnrollSystemDataSet.RegularLoad.FindByRegularLoadID _
               (SelectedRegularLoadID)

            Dim draRegularLoad As DataRow()
            draRegularLoad = drSelectedRegularLoad.GetChildRows("RegularLoad_RegularLoad Details")

            Dim drRegularLoadDetails As DataRow
            For Each drRegularLoadDetails In draRegularLoad
                Dim myTable As DataTable = EnrollSystemDataSet.Tables("SchYrSemCourseJoin")
                Dim myRow As DataRow

                myRow = myTable.NewRow()
                myRow("SchYrSemID") = SchYrSemIDValue
                myRow("CourseID") = drRegularLoadDetails("CourseID")
                myTable.Rows.Add(myRow)
            Next
        End If

    End Sub

    Private Function IsANonHeaderButtonCell(ByVal cellEvent As  _
       DataGridViewCellEventArgs) As Boolean

        If TypeOf SchYrSemDataGridView.Columns(cellEvent.ColumnIndex) _
            Is DataGridViewButtonColumn _
            AndAlso Not cellEvent.RowIndex = -1 Then _
            Return True Else Return (False)

    End Function

    Private Sub txtSearchName_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles txtSearchName.KeyPress
        If e.KeyChar = Microsoft.VisualBasic.ChrW(13) Then
            Try
                EnrollSystemDataSet.SchYrSemCourseJoin.Clear()
                EnrollSystemDataSet.SchYrSem.Clear()
                EnrollSystemDataSet.Students.Clear()

                Me.StudentsTableAdapter.FillBy(Me.EnrollSystemDataSet.Students, txtSearchName.Text)

                Me.SchYrSemTableAdapter.Fill(Me.EnrollSystemDataSet.SchYrSem)

                Me.SchYrSemCourseJoinTableAdapter.FillBy(Me.EnrollSystemDataSet.SchYrSemCourseJoin)
            Catch ex As Exception
                MsgBox(ex.Message)
            End Try
        End If
    End Sub

    Private Sub SchYrSemDataGridView_Enter(ByVal sender As Object, ByVal e As System.EventArgs) Handles SchYrSemDataGridView.Enter
        If Me.IDNoTextBox.Text = "" Then
            MessageBox.Show("Enter students idno information before entering school year and semester.")

            TabControl1.SelectedTab = TabPage1
            Me.IDNoTextBox.Focus()
        Else
            Me.StudentsBindingSource.EndEdit()
        End If
    End Sub
End Class

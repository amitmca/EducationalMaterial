Option Strict On
Option Explicit On 

Imports System.Data
Imports System.Data.SqlClient
Imports CrystalDecisions.CrystalReports.Engine

Public Class Transcript
    Inherits System.Windows.Forms.Form

    Private HasConnected As Boolean = False
    Private ServerName As String = "localhost"

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents crvTranscript As CrystalDecisions.Windows.Forms.CrystalReportViewer
    Friend WithEvents btnDisplayTranscript As System.Windows.Forms.Button
    Friend WithEvents txtIDNo As System.Windows.Forms.TextBox
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.crvTranscript = New CrystalDecisions.Windows.Forms.CrystalReportViewer
        Me.txtIDNo = New System.Windows.Forms.TextBox
        Me.btnDisplayTranscript = New System.Windows.Forms.Button
        Me.SuspendLayout()
        '
        'crvTranscript
        '
        Me.crvTranscript.ActiveViewIndex = -1
        Me.crvTranscript.DisplayGroupTree = False
        Me.crvTranscript.Location = New System.Drawing.Point(16, 40)
        Me.crvTranscript.Name = "crvTranscript"
        Me.crvTranscript.ReportSource = Nothing
        Me.crvTranscript.Size = New System.Drawing.Size(1000, 648)
        Me.crvTranscript.TabIndex = 0
        '
        'txtIDNo
        '
        Me.txtIDNo.Location = New System.Drawing.Point(48, 8)
        Me.txtIDNo.Name = "txtIDNo"
        Me.txtIDNo.TabIndex = 1
        Me.txtIDNo.Text = ""
        '
        'btnDisplayTranscript
        '
        Me.btnDisplayTranscript.Location = New System.Drawing.Point(168, 8)
        Me.btnDisplayTranscript.Name = "btnDisplayTranscript"
        Me.btnDisplayTranscript.Size = New System.Drawing.Size(136, 23)
        Me.btnDisplayTranscript.TabIndex = 2
        Me.btnDisplayTranscript.Text = "Display Transcript"
        '
        'frmReport
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(1028, 702)
        Me.Controls.AddRange(New System.Windows.Forms.Control() {Me.btnDisplayTranscript, Me.txtIDNo, Me.crvTranscript})
        Me.Name = "frmReport"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Form1"
        Me.WindowState = System.Windows.Forms.FormWindowState.Maximized
        Me.ResumeLayout(False)

    End Sub

#End Region

    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'crystalReport11.PrintOptions.PaperSize = CrystalDecisions.[Shared].PaperSize.PaperFanfoldLegalGerman
        'CrystalReportViewer1.ReportSource = crystalReport11
    End Sub

    Private Sub btnDisplayTranscript_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnDisplayTranscript.Click
        ' In this event the Transcript of Records Report is loaded 
        ' and displayed in the crystal reports viewer.
        ' This report calls for a parameter which is pulled
        ' from the IDNo textbox (IDNo).

        ' Objects used to set the parameters in the report
        Dim pvCollection As New CrystalDecisions.Shared.ParameterValues
        Dim pdvCustomerName As New CrystalDecisions.Shared.ParameterDiscreteValue

        ' Objects used to set the proper database connection information
        Dim tbCurrent As CrystalDecisions.CrystalReports.Engine.Table
        Dim tliCurrent As CrystalDecisions.Shared.TableLogOnInfo

        ' Create a report document instance to hold the report
        Dim rptTranscript As New ReportDocument

        Try
            ' Load the report
            rptTranscript.Load("..\..\reports\rptTranscriptofRecords.rpt")

            'rptTranscript.PrintOptions.PaperSize = CrystalDecisions.[Shared].PaperSize.PaperFanfoldLegalGerman

            ' Set the connection information for all the tables used in the report
            ' Leave UserID and Password blank for trusted connection
            For Each tbCurrent In rptTranscript.Database.Tables
                tliCurrent = tbCurrent.LogOnInfo
                With tliCurrent.ConnectionInfo
                    .ServerName = ServerName
                    .UserID = ""
                    .Password = ""
                    .DatabaseName = "EnrollSystem"
                End With
                tbCurrent.ApplyLogOnInfo(tliCurrent)
            Next tbCurrent

            ' Set the discreet value to the customers name.
            pdvCustomerName.Value = txtIDNo.Text

            ' Add it to the parameter collection.
            pvCollection.Add(pdvCustomerName)

            ' Apply the current parameter values.
            rptTranscript.DataDefinition.ParameterFields("@IDNo").ApplyCurrentValues(pvCollection)

            ' Hide group tree for this report
            crvTranscript.DisplayGroupTree = False

            ' Set the report source for the crystal reports viewer to the 
            ' report instance.
            crvTranscript.ReportSource = rptTranscript

            ' Zoom viewer to fit to the whole page so the user can see the report
            'crvTranscript.Zoom(2)

        Catch Exp As LoadSaveReportException
            MsgBox("Incorrect path for loading report.", _
                    MsgBoxStyle.Critical, "Load Report Error")

        Catch Exp As Exception
            MsgBox(Exp.Message, MsgBoxStyle.Critical, "General Error")

        End Try
    End Sub
End Class

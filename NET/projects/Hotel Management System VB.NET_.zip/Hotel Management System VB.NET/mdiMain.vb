﻿Imports System.Windows.Forms

Public Class mdiMain
    Private blnActive As Boolean

    Private Function IsOpen(ByVal nameForm As String) As Boolean
        Dim childfrm As Form
        Dim strNaam As String
        Dim intPuntje As Integer

        For Each childfrm In Me.MdiChildren
            strNaam = childfrm.GetType.ToString
            intPuntje = strNaam.LastIndexOf(".")
            strNaam = Mid(strNaam, intPuntje + 2, Len(strNaam) - intPuntje)
            If LCase(strNaam) = LCase(nameForm) Then
                childfrm.BringToFront()
                Return True
            End If
        Next
        Return False
    End Function

    Private Sub ShowNewForm(ByVal sender As Object, ByVal e As EventArgs) Handles NewToolStripButton.Click, NewWindowToolStripMenuItem.Click
        ' Create a new instance of the child form.
        Dim ChildForm As New System.Windows.Forms.Form
        ' Make it a child of this MDI form before showing it.
        ChildForm.MdiParent = Me

        m_ChildFormNumber += 1
        ChildForm.Text = "Window " & m_ChildFormNumber

        ChildForm.Show()
    End Sub

    Private Sub ExitToolsStripMenuItem_Click(ByVal sender As Object, ByVal e As EventArgs) Handles ExitToolStripMenuItem.Click
        Me.Close()
    End Sub

    Private Sub CutToolStripMenuItem_Click(ByVal sender As Object, ByVal e As EventArgs)
        ' Use My.Computer.Clipboard to insert the selected text or images into the clipboard
    End Sub

    Private Sub CopyToolStripMenuItem_Click(ByVal sender As Object, ByVal e As EventArgs)
        ' Use My.Computer.Clipboard to insert the selected text or images into the clipboard
    End Sub

    Private Sub PasteToolStripMenuItem_Click(ByVal sender As Object, ByVal e As EventArgs)
        'Use My.Computer.Clipboard.GetText() or My.Computer.Clipboard.GetData to retrieve information from the clipboard.
    End Sub

    Private m_ChildFormNumber As Integer

    Private Sub mnuGuests_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnuGuests.Click
        If blnActive = IsOpen("frmGuest") Then
            Dim Guest As New frmGuest

            Guest.MdiParent = Me
            Guest.StartPosition = FormStartPosition.CenterScreen
            Guest.Show()
        End If
    End Sub

    Private Sub mnuCompany_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnuCompany.Click
        If blnActive = IsOpen("frmCompany") Then
            Dim Company As New frmCompany

            Company.MdiParent = Me
            Company.StartPosition = FormStartPosition.CenterScreen
            Company.Show()
        End If
    End Sub

    Private Sub frmBusinessSource_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles frmBusinessSource.Click
        If blnActive = IsOpen("frmBusinessSource") Then
            Dim BusinessSource As New frmBusinessSource

            BusinessSource.MdiParent = Me
            BusinessSource.StartPosition = FormStartPosition.CenterScreen
            BusinessSource.Show()
        End If
    End Sub

    Private Sub frmChargeType_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles frmChargeType.Click
        If blnActive = IsOpen("frmChargeType") Then
            Dim ChargeType As New frmChargeType

            ChargeType.MdiParent = Me
            ChargeType.StartPosition = FormStartPosition.CenterScreen
            ChargeType.Show()
        End If
    End Sub

    Private Sub frmCountries_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles frmCountries.Click
        If blnActive = IsOpen("frmCountries") Then
            Dim Countries As New frmCountries

            Countries.MdiParent = Me
            Countries.StartPosition = FormStartPosition.CenterScreen
            Countries.Show()
        End If
    End Sub

    Private Sub frmIDType_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles frmIDType.Click
        If blnActive = IsOpen("frmIDType") Then
            Dim IDType As New frmIDType

            IDType.MdiParent = Me
            IDType.StartPosition = FormStartPosition.CenterScreen
            IDType.Show()
        End If
    End Sub

    Private Sub frmPaymentType_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles frmPaymentType.Click
        If blnActive = IsOpen("frmPaymentType") Then
            Dim PaymentType As New frmPaymentType

            PaymentType.MdiParent = Me
            PaymentType.StartPosition = FormStartPosition.CenterScreen
            PaymentType.Show()
        End If
    End Sub

    Private Sub frmRateType_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles frmRateType.Click
        If blnActive = IsOpen("frmRateType") Then
            Dim RateType As New frmRateType

            RateType.MdiParent = Me
            RateType.StartPosition = FormStartPosition.CenterScreen
            RateType.Show()
        End If
    End Sub

    Private Sub frmRoomStatus_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles frmRoomStatus.Click
        If blnActive = IsOpen("frmRoomStatus") Then
            Dim RoomStatus As New frmRoomStatus

            RoomStatus.MdiParent = Me
            RoomStatus.StartPosition = FormStartPosition.CenterScreen
            RoomStatus.Show()
        End If
    End Sub

    Private Sub frmRoomType_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles frmRoomType.Click
        If blnActive = IsOpen("frmRoomType") Then
            Dim RoomType As New frmRoomType

            RoomType.MdiParent = Me
            RoomType.StartPosition = FormStartPosition.CenterScreen
            RoomType.Show()
        End If
    End Sub

    Private Sub frmVehicles_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles frmVehicles.Click
        If blnActive = IsOpen("frmVehicles") Then
            Dim Vehicles As New frmVehicles

            Vehicles.MdiParent = Me
            Vehicles.StartPosition = FormStartPosition.CenterScreen
            Vehicles.Show()
        End If
    End Sub

    Private Sub mnuAbout_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnuAbout.Click
        If blnActive = IsOpen("frmAbout") Then
            Dim About As New frmAbout

            About.MdiParent = Me
            About.StartPosition = FormStartPosition.CenterScreen
            About.Show()
        End If
    End Sub
End Class

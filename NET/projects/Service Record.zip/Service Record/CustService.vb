Imports System.Data.OleDb

Public Class CustService
    Inherits System.Windows.Forms.Form
    Dim ACCESS_CONNECTION_STRING As String = cnSettings()

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents cbAddress As System.Windows.Forms.ComboBox
    Friend WithEvents Panel2 As System.Windows.Forms.Panel
    Friend WithEvents btnExit As System.Windows.Forms.Button
    Friend WithEvents Panel3 As System.Windows.Forms.Panel
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents lvCustomers As System.Windows.Forms.ListView
    Friend WithEvents CustName As System.Windows.Forms.ColumnHeader
    Friend WithEvents Model As System.Windows.Forms.ColumnHeader
    Friend WithEvents SerialNo As System.Windows.Forms.ColumnHeader
    Friend WithEvents DatePurchase As System.Windows.Forms.ColumnHeader
    Friend WithEvents Remarks As System.Windows.Forms.ColumnHeader
    Friend WithEvents OleDbSelectCommand1 As System.Data.OleDb.OleDbCommand
    Friend WithEvents OleDbInsertCommand1 As System.Data.OleDb.OleDbCommand
    Friend WithEvents OleDbUpdateCommand1 As System.Data.OleDb.OleDbCommand
    Friend WithEvents OleDbDeleteCommand1 As System.Data.OleDb.OleDbCommand
    Friend WithEvents cnService As System.Data.OleDb.OleDbConnection
    Friend WithEvents daAddresses As System.Data.OleDb.OleDbDataAdapter
    Friend WithEvents DsService As Service_Record.DsService
    Friend WithEvents CustomerID As System.Windows.Forms.ColumnHeader
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.Panel1 = New System.Windows.Forms.Panel
        Me.lvCustomers = New System.Windows.Forms.ListView
        Me.CustomerID = New System.Windows.Forms.ColumnHeader
        Me.CustName = New System.Windows.Forms.ColumnHeader
        Me.Model = New System.Windows.Forms.ColumnHeader
        Me.SerialNo = New System.Windows.Forms.ColumnHeader
        Me.DatePurchase = New System.Windows.Forms.ColumnHeader
        Me.Remarks = New System.Windows.Forms.ColumnHeader
        Me.DsService = New Service_Record.DsService
        Me.Label2 = New System.Windows.Forms.Label
        Me.cbAddress = New System.Windows.Forms.ComboBox
        Me.Panel2 = New System.Windows.Forms.Panel
        Me.btnExit = New System.Windows.Forms.Button
        Me.Panel3 = New System.Windows.Forms.Panel
        Me.Label1 = New System.Windows.Forms.Label
        Me.OleDbSelectCommand1 = New System.Data.OleDb.OleDbCommand
        Me.cnService = New System.Data.OleDb.OleDbConnection
        Me.OleDbInsertCommand1 = New System.Data.OleDb.OleDbCommand
        Me.OleDbUpdateCommand1 = New System.Data.OleDb.OleDbCommand
        Me.OleDbDeleteCommand1 = New System.Data.OleDb.OleDbCommand
        Me.daAddresses = New System.Data.OleDb.OleDbDataAdapter
        Me.Panel1.SuspendLayout()
        CType(Me.DsService, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel2.SuspendLayout()
        Me.Panel3.SuspendLayout()
        Me.SuspendLayout()
        '
        'Panel1
        '
        Me.Panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Panel1.Controls.Add(Me.lvCustomers)
        Me.Panel1.Controls.Add(Me.Label2)
        Me.Panel1.Controls.Add(Me.cbAddress)
        Me.Panel1.Location = New System.Drawing.Point(8, 40)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(552, 288)
        Me.Panel1.TabIndex = 6
        '
        'lvCustomers
        '
        Me.lvCustomers.Columns.AddRange(New System.Windows.Forms.ColumnHeader() {Me.CustomerID, Me.CustName, Me.Model, Me.SerialNo, Me.DatePurchase, Me.Remarks})
        Me.lvCustomers.DataBindings.Add(New System.Windows.Forms.Binding("Tag", Me.DsService, "Addresses.AddressesCustomers.CustomerID"))
        Me.lvCustomers.FullRowSelect = True
        Me.lvCustomers.Location = New System.Drawing.Point(8, 40)
        Me.lvCustomers.MultiSelect = False
        Me.lvCustomers.Name = "lvCustomers"
        Me.lvCustomers.Size = New System.Drawing.Size(536, 240)
        Me.lvCustomers.TabIndex = 9
        Me.lvCustomers.View = System.Windows.Forms.View.Details
        '
        'CustomerID
        '
        Me.CustomerID.Text = "CustomerID"
        Me.CustomerID.Width = 0
        '
        'CustName
        '
        Me.CustName.Text = "Name"
        Me.CustName.Width = 120
        '
        'Model
        '
        Me.Model.Text = "Model"
        Me.Model.Width = 80
        '
        'SerialNo
        '
        Me.SerialNo.Text = "Serial No"
        '
        'DatePurchase
        '
        Me.DatePurchase.Text = "Date Purchase"
        Me.DatePurchase.Width = 100
        '
        'Remarks
        '
        Me.Remarks.Text = "Remarks"
        '
        'DsService
        '
        Me.DsService.DataSetName = "DsService"
        Me.DsService.Locale = New System.Globalization.CultureInfo("en-US")
        '
        'Label2
        '
        Me.Label2.Location = New System.Drawing.Point(16, 8)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(56, 23)
        Me.Label2.TabIndex = 8
        Me.Label2.Text = "Address:"
        '
        'cbAddress
        '
        Me.cbAddress.DataBindings.Add(New System.Windows.Forms.Binding("Tag", Me.DsService, "Addresses.AddressID"))
        Me.cbAddress.DataSource = Me.DsService
        Me.cbAddress.DisplayMember = "Addresses.Address"
        Me.cbAddress.Location = New System.Drawing.Point(80, 8)
        Me.cbAddress.Name = "cbAddress"
        Me.cbAddress.Size = New System.Drawing.Size(352, 21)
        Me.cbAddress.TabIndex = 7
        Me.cbAddress.ValueMember = "Addresses.Address"
        '
        'Panel2
        '
        Me.Panel2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Panel2.Controls.Add(Me.btnExit)
        Me.Panel2.Location = New System.Drawing.Point(8, 336)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(552, 30)
        Me.Panel2.TabIndex = 7
        '
        'btnExit
        '
        Me.btnExit.Location = New System.Drawing.Point(464, 2)
        Me.btnExit.Name = "btnExit"
        Me.btnExit.TabIndex = 4
        Me.btnExit.Text = "Exit"
        '
        'Panel3
        '
        Me.Panel3.BackColor = System.Drawing.SystemColors.AppWorkspace
        Me.Panel3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Panel3.Controls.Add(Me.Label1)
        Me.Panel3.Location = New System.Drawing.Point(8, 8)
        Me.Panel3.Name = "Panel3"
        Me.Panel3.Size = New System.Drawing.Size(552, 30)
        Me.Panel3.TabIndex = 8
        '
        'Label1
        '
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(6, 3)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(339, 24)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Customer Record"
        '
        'OleDbSelectCommand1
        '
        Me.OleDbSelectCommand1.CommandText = "SELECT Address, AddressID, [Order] FROM Addresses ORDER BY [Order]"
        Me.OleDbSelectCommand1.Connection = Me.cnService
        '
        'cnService
        '
        Me.cnService.ConnectionString = "Jet OLEDB:Global Partial Bulk Ops=2;Jet OLEDB:Registry Path=;Jet OLEDB:Database L" & _
        "ocking Mode=1;Data Source=""E:\Project\Service Record\bin\Data\Service.mdb"";Jet O" & _
        "LEDB:Engine Type=5;Provider=""Microsoft.Jet.OLEDB.4.0"";Jet OLEDB:System database=" & _
        ";Jet OLEDB:SFP=False;persist security info=False;Extended Properties=;Mode=Share" & _
        " Deny None;Jet OLEDB:Encrypt Database=False;Jet OLEDB:Create System Database=Fal" & _
        "se;Jet OLEDB:Don't Copy Locale on Compact=False;Jet OLEDB:Compact Without Replic" & _
        "a Repair=False;User ID=Admin;Jet OLEDB:Global Bulk Transactions=1"
        '
        'OleDbInsertCommand1
        '
        Me.OleDbInsertCommand1.CommandText = "INSERT INTO Addresses(Address) VALUES (?)"
        Me.OleDbInsertCommand1.Connection = Me.cnService
        Me.OleDbInsertCommand1.Parameters.Add(New System.Data.OleDb.OleDbParameter("Address", System.Data.OleDb.OleDbType.VarWChar, 50, "Address"))
        '
        'OleDbUpdateCommand1
        '
        Me.OleDbUpdateCommand1.CommandText = "UPDATE Addresses SET Address = ? WHERE (AddressID = ?) AND (Address = ? OR ? IS N" & _
        "ULL AND Address IS NULL)"
        Me.OleDbUpdateCommand1.Connection = Me.cnService
        Me.OleDbUpdateCommand1.Parameters.Add(New System.Data.OleDb.OleDbParameter("Address", System.Data.OleDb.OleDbType.VarWChar, 50, "Address"))
        Me.OleDbUpdateCommand1.Parameters.Add(New System.Data.OleDb.OleDbParameter("Original_AddressID", System.Data.OleDb.OleDbType.Integer, 0, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "AddressID", System.Data.DataRowVersion.Original, Nothing))
        Me.OleDbUpdateCommand1.Parameters.Add(New System.Data.OleDb.OleDbParameter("Original_Address", System.Data.OleDb.OleDbType.VarWChar, 50, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "Address", System.Data.DataRowVersion.Original, Nothing))
        Me.OleDbUpdateCommand1.Parameters.Add(New System.Data.OleDb.OleDbParameter("Original_Address1", System.Data.OleDb.OleDbType.VarWChar, 50, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "Address", System.Data.DataRowVersion.Original, Nothing))
        '
        'OleDbDeleteCommand1
        '
        Me.OleDbDeleteCommand1.CommandText = "DELETE FROM Addresses WHERE (AddressID = ?) AND (Address = ? OR ? IS NULL AND Add" & _
        "ress IS NULL)"
        Me.OleDbDeleteCommand1.Connection = Me.cnService
        Me.OleDbDeleteCommand1.Parameters.Add(New System.Data.OleDb.OleDbParameter("Original_AddressID", System.Data.OleDb.OleDbType.Integer, 0, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "AddressID", System.Data.DataRowVersion.Original, Nothing))
        Me.OleDbDeleteCommand1.Parameters.Add(New System.Data.OleDb.OleDbParameter("Original_Address", System.Data.OleDb.OleDbType.VarWChar, 50, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "Address", System.Data.DataRowVersion.Original, Nothing))
        Me.OleDbDeleteCommand1.Parameters.Add(New System.Data.OleDb.OleDbParameter("Original_Address1", System.Data.OleDb.OleDbType.VarWChar, 50, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "Address", System.Data.DataRowVersion.Original, Nothing))
        '
        'daAddresses
        '
        Me.daAddresses.DeleteCommand = Me.OleDbDeleteCommand1
        Me.daAddresses.InsertCommand = Me.OleDbInsertCommand1
        Me.daAddresses.SelectCommand = Me.OleDbSelectCommand1
        Me.daAddresses.TableMappings.AddRange(New System.Data.Common.DataTableMapping() {New System.Data.Common.DataTableMapping("Table", "Addresses", New System.Data.Common.DataColumnMapping() {New System.Data.Common.DataColumnMapping("Address", "Address"), New System.Data.Common.DataColumnMapping("AddressID", "AddressID")})})
        Me.daAddresses.UpdateCommand = Me.OleDbUpdateCommand1
        '
        'CustService
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(568, 374)
        Me.Controls.Add(Me.Panel1)
        Me.Controls.Add(Me.Panel2)
        Me.Controls.Add(Me.Panel3)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.Name = "CustService"
        Me.Text = "CustService"
        Me.Panel1.ResumeLayout(False)
        CType(Me.DsService, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel2.ResumeLayout(False)
        Me.Panel3.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub

#End Region

    Private Sub CustService_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        cnService.ConnectionString = cnSettings()
        daAddresses.Fill(DsService)

        AddHandler Me.BindingContext(DsService, "Addresses").PositionChanged, _
                    AddressOf dtAddresses_PositionChanged

        fill_lvCustomers()
    End Sub

    Protected Sub dtAddresses_PositionChanged(ByVal sender As Object, ByVal e As System.EventArgs)
        Try
            fill_lvCustomers()
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
    End Sub

    Public Sub fill_lvCustomers()
        Dim Connection As New OleDbConnection(ACCESS_CONNECTION_STRING)

        lvCustomers.Items.Clear()

        Dim cmdfill As New OleDbCommand("SELECT CustomerID, Name, Model, SerialNo, DatePurchase, Remarks FROM Customers Where AddressID = " & cbAddress.Tag & " ORDER BY [Order]", Connection)

        Try
            Connection.Open()

            Dim datareader As OleDbDataReader

            datareader = cmdfill.ExecuteReader

            While datareader.Read
                Dim lvi As New ListViewItem
                lvi.Text = datareader("CustomerID")
                lvi.SubItems.Add(IIf(IsDBNull(datareader("Name")), "", datareader("Name")))
                lvi.SubItems.Add(IIf(IsDBNull(datareader("Model")), "", datareader("Model")))
                lvi.SubItems.Add(IIf(IsDBNull(datareader("SerialNo")), "", datareader("SerialNo")))
                'lvi.SubItems.Add(IIf(IsDBNull(datareader("DatePurchase")), "", CStr(datareader("DatePurchase"))))
                If IsDBNull(datareader("DatePurchase")) Then
                    lvi.SubItems.Add("")
                Else
                    lvi.SubItems.Add(CStr(datareader("DatePurchase")))
                End If

                lvi.SubItems.Add(IIf(IsDBNull(datareader("Remarks")), "", datareader("Remarks")))
                lvCustomers.Items.Add(lvi)
            End While

            If datareader.HasRows Then
                lvCustomers.TopItem.Selected = True
                lvCustomers.TopItem.Focused = True
                lvCustomers.TopItem.EnsureVisible()
                lvCustomers.Select()
            End If

        Catch ex As Exception
            MsgBox(ex.Message, MsgBoxStyle.Critical, "Error")
        Finally
            Connection.Close()
        End Try
    End Sub

    Private Sub btnExit_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnExit.Click
        Me.Close()
    End Sub

    Private Sub lvCustomers_DoubleClick(ByVal sender As Object, ByVal e As System.EventArgs) Handles lvCustomers.DoubleClick
        Dim frmService As New ServiceRecord
        Dim lvi As New ListViewItem
        Dim intCustID As String

        For Each lvi In lvCustomers.SelectedItems
            intCustID = lvi.SubItems(0).Text
        Next

        intAddressID = cbAddress.Tag
        intCustomerID = intCustID
        frmService.ShowDialog()
    End Sub
End Class

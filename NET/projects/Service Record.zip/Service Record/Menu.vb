Public Class Menu
    Inherits System.Windows.Forms.Form

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents MainMenu1 As System.Windows.Forms.MainMenu
    Friend WithEvents mnuTransaction As System.Windows.Forms.MenuItem
    Friend WithEvents mnuService As System.Windows.Forms.MenuItem
    Friend WithEvents mnuExit As System.Windows.Forms.MenuItem
    Friend WithEvents mnuMasterfile As System.Windows.Forms.MenuItem
    Friend WithEvents mnuReports As System.Windows.Forms.MenuItem
    Friend WithEvents mnuUser As System.Windows.Forms.MenuItem
    Friend WithEvents mnuHelp As System.Windows.Forms.MenuItem
    Friend WithEvents mnuCustomer As System.Windows.Forms.MenuItem
    Friend WithEvents mnuWindow As System.Windows.Forms.MenuItem
    Friend WithEvents mnuHistCard As System.Windows.Forms.MenuItem
    Friend WithEvents mnuAddresses As System.Windows.Forms.MenuItem
    Friend WithEvents mnuPartsRecord As System.Windows.Forms.MenuItem
    Friend WithEvents mnuPartsRecReport As System.Windows.Forms.MenuItem
    Friend WithEvents mnuLogin As System.Windows.Forms.MenuItem
    Friend WithEvents mnuUserMan As System.Windows.Forms.MenuItem
    Friend WithEvents mnuAbout As System.Windows.Forms.MenuItem
    Friend WithEvents mnuDBPath As System.Windows.Forms.MenuItem
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container
        Me.MainMenu1 = New System.Windows.Forms.MainMenu(Me.components)
        Me.mnuTransaction = New System.Windows.Forms.MenuItem
        Me.mnuLogin = New System.Windows.Forms.MenuItem
        Me.mnuService = New System.Windows.Forms.MenuItem
        Me.mnuPartsRecord = New System.Windows.Forms.MenuItem
        Me.mnuExit = New System.Windows.Forms.MenuItem
        Me.mnuMasterfile = New System.Windows.Forms.MenuItem
        Me.mnuAddresses = New System.Windows.Forms.MenuItem
        Me.mnuCustomer = New System.Windows.Forms.MenuItem
        Me.mnuReports = New System.Windows.Forms.MenuItem
        Me.mnuHistCard = New System.Windows.Forms.MenuItem
        Me.mnuPartsRecReport = New System.Windows.Forms.MenuItem
        Me.mnuUser = New System.Windows.Forms.MenuItem
        Me.mnuUserMan = New System.Windows.Forms.MenuItem
        Me.mnuDBPath = New System.Windows.Forms.MenuItem
        Me.mnuWindow = New System.Windows.Forms.MenuItem
        Me.mnuHelp = New System.Windows.Forms.MenuItem
        Me.mnuAbout = New System.Windows.Forms.MenuItem
        Me.SuspendLayout()
        '
        'MainMenu1
        '
        Me.MainMenu1.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.mnuTransaction, Me.mnuMasterfile, Me.mnuReports, Me.mnuUser, Me.mnuWindow, Me.mnuHelp})
        '
        'mnuTransaction
        '
        Me.mnuTransaction.Index = 0
        Me.mnuTransaction.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.mnuLogin, Me.mnuService, Me.mnuPartsRecord, Me.mnuExit})
        Me.mnuTransaction.Text = "&Transaction"
        '
        'mnuLogin
        '
        Me.mnuLogin.Index = 0
        Me.mnuLogin.Text = "&Login"
        '
        'mnuService
        '
        Me.mnuService.Index = 1
        Me.mnuService.Text = "&Service Record"
        '
        'mnuPartsRecord
        '
        Me.mnuPartsRecord.Index = 2
        Me.mnuPartsRecord.Text = "Consumables/Parts Record"
        '
        'mnuExit
        '
        Me.mnuExit.Index = 3
        Me.mnuExit.Text = "E&xit"
        '
        'mnuMasterfile
        '
        Me.mnuMasterfile.Index = 1
        Me.mnuMasterfile.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.mnuAddresses, Me.mnuCustomer})
        Me.mnuMasterfile.Text = "&Masterfile"
        '
        'mnuAddresses
        '
        Me.mnuAddresses.Index = 0
        Me.mnuAddresses.Text = "&Addresses"
        '
        'mnuCustomer
        '
        Me.mnuCustomer.Index = 1
        Me.mnuCustomer.Text = "&Customers"
        '
        'mnuReports
        '
        Me.mnuReports.Index = 2
        Me.mnuReports.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.mnuHistCard, Me.mnuPartsRecReport})
        Me.mnuReports.Text = "&Reports"
        '
        'mnuHistCard
        '
        Me.mnuHistCard.Index = 0
        Me.mnuHistCard.Text = "&History Card Report"
        '
        'mnuPartsRecReport
        '
        Me.mnuPartsRecReport.Index = 1
        Me.mnuPartsRecReport.Text = "Consumables/Parts Record"
        '
        'mnuUser
        '
        Me.mnuUser.Index = 3
        Me.mnuUser.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.mnuUserMan, Me.mnuDBPath})
        Me.mnuUser.Text = "&Utilities"
        '
        'mnuUserMan
        '
        Me.mnuUserMan.Index = 0
        Me.mnuUserMan.Text = "&User Management"
        '
        'mnuDBPath
        '
        Me.mnuDBPath.Index = 1
        Me.mnuDBPath.Text = "Database Path"
        '
        'mnuWindow
        '
        Me.mnuWindow.Index = 4
        Me.mnuWindow.MdiList = True
        Me.mnuWindow.Text = "&Window"
        '
        'mnuHelp
        '
        Me.mnuHelp.Index = 5
        Me.mnuHelp.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.mnuAbout})
        Me.mnuHelp.Text = "&Help"
        '
        'mnuAbout
        '
        Me.mnuAbout.Index = 0
        Me.mnuAbout.Text = "&About"
        '
        'Menu
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(504, 334)
        Me.IsMdiContainer = True
        Me.Menu = Me.MainMenu1
        Me.Name = "Menu"
        Me.Text = "Menu"
        Me.WindowState = System.Windows.Forms.FormWindowState.Maximized
        Me.ResumeLayout(False)

    End Sub

#End Region
    Private blnActive As Boolean

    Private Function IsOpen(ByVal nameForm As String) As Boolean
        Dim childfrm As Form
        Dim strNaam As String
        Dim intPuntje As Integer

        For Each childfrm In Me.MdiChildren
            strNaam = childfrm.GetType.ToString
            intPuntje = strNaam.LastIndexOf(".")
            strNaam = Mid(strNaam, intPuntje + 2, Len(strNaam) - intPuntje)
            If LCase(strNaam) = LCase(nameForm) Then
                childfrm.BringToFront()
                Return True
            End If
        Next
        Return False
    End Function

    Private Sub mnuExit_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnuExit.Click
        Application.Exit()
    End Sub

    Private Sub mnuService_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnuService.Click
        If blnActive = IsOpen("CustService") Then
            Dim Service As New CustService

            Service.MdiParent = Me
            Service.StartPosition = FormStartPosition.CenterScreen
            Service.Show()
        End If
    End Sub

    Private Sub mnuCustomer_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnuCustomer.Click
        If blnActive = IsOpen("Customers") Then
            Dim Customers As New Customers

            Customers.MdiParent = Me
            Customers.StartPosition = FormStartPosition.CenterScreen
            Customers.Show()
        End If
    End Sub


    Private Sub mnuHistCard_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnuHistCard.Click
        If blnActive = IsOpen("HistoryCardDialog") Then
            Dim HistoryCardDialog As New HistoryCardDialog

            HistoryCardDialog.MdiParent = Me
            HistoryCardDialog.StartPosition = FormStartPosition.CenterScreen
            HistoryCardDialog.Show()
        End If
    End Sub

    Private Sub mnuAddresses_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnuAddresses.Click
        If blnActive = IsOpen("Addresses") Then
            Dim Service As New Addresses

            Service.MdiParent = Me
            Service.StartPosition = FormStartPosition.CenterScreen
            Service.Show()
        End If
    End Sub

    Private Sub mnuPartsRecord_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnuPartsRecord.Click
        If blnActive = IsOpen("CustParts") Then
            Dim CustParts As New CustParts

            CustParts.MdiParent = Me
            CustParts.StartPosition = FormStartPosition.CenterScreen
            CustParts.Show()
        End If
    End Sub

    Private Sub mnuPartsRecReport_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnuPartsRecReport.Click
        If blnActive = IsOpen("PartsRecordDialog") Then
            Dim PartsRecordDialog As New PartsRecordDialog

            PartsRecordDialog.MdiParent = Me
            PartsRecordDialog.StartPosition = FormStartPosition.CenterScreen
            PartsRecordDialog.Show()
        End If
    End Sub

    Private Sub mnuLogin_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnuLogin.Click
        If blnActive = IsOpen("Login") Then
            Dim Login As New Login

            Login.ShowDialog()
        End If
    End Sub

    Private Sub mnuUserMan_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnuUserMan.Click
        If blnActive = IsOpen("Password") Then
            Dim Password As New Password

            Password.MdiParent = Me
            Password.StartPosition = FormStartPosition.CenterScreen
            Password.Show()
        End If
    End Sub

    Private Sub Menu_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.Load
        mnuLogin_Click(sender, e)
    End Sub

    Private Sub mnuAbout_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnuAbout.Click
        If blnActive = IsOpen("About") Then
            Dim About As New About

            About.MdiParent = Me
            About.StartPosition = FormStartPosition.CenterScreen
            About.Show()
        End If
    End Sub

    Private Sub mnuDBPath_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnuDBPath.Click
        If blnActive = IsOpen("DBPath") Then
            Dim DBPath As New DBPath

            DBPath.MdiParent = Me
            DBPath.StartPosition = FormStartPosition.CenterScreen
            DBPath.Show()
        End If
    End Sub
End Class

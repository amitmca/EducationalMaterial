Public Class Parts1
    Inherits System.Windows.Forms.Form

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents Panel2 As System.Windows.Forms.Panel
    Friend WithEvents Label13 As System.Windows.Forms.Label
    Friend WithEvents PartsRecordList As System.Windows.Forms.TabControl
    Friend WithEvents Data As System.Windows.Forms.TabPage
    Friend WithEvents cbDatePurchase As System.Windows.Forms.DateTimePicker
    Friend WithEvents grdPartsDetails As System.Windows.Forms.DataGrid
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents txtCopierModel As System.Windows.Forms.TextBox
    Friend WithEvents txtAddress As System.Windows.Forms.TextBox
    Friend WithEvents TxtName As System.Windows.Forms.TextBox
    Friend WithEvents List As System.Windows.Forms.TabPage
    Friend WithEvents grdPartsRecordList As System.Windows.Forms.DataGrid
    Friend WithEvents Panel3 As System.Windows.Forms.Panel
    Friend WithEvents btnDelete As System.Windows.Forms.Button
    Friend WithEvents btnFirst As System.Windows.Forms.Button
    Friend WithEvents btnPrev As System.Windows.Forms.Button
    Friend WithEvents lblNavLocation As System.Windows.Forms.Label
    Friend WithEvents btnNext As System.Windows.Forms.Button
    Friend WithEvents btnLast As System.Windows.Forms.Button
    Friend WithEvents btnAdd As System.Windows.Forms.Button
    Friend WithEvents btnSave As System.Windows.Forms.Button
    Friend WithEvents btnExit As System.Windows.Forms.Button
    Friend WithEvents OleDbSelectCommand1 As System.Data.OleDb.OleDbCommand
    Friend WithEvents OleDbInsertCommand1 As System.Data.OleDb.OleDbCommand
    Friend WithEvents OleDbUpdateCommand1 As System.Data.OleDb.OleDbCommand
    Friend WithEvents OleDbDeleteCommand1 As System.Data.OleDb.OleDbCommand
    Friend WithEvents cnService As System.Data.OleDb.OleDbConnection
    Friend WithEvents daPartsRecord As System.Data.OleDb.OleDbDataAdapter
    Friend WithEvents DsService As Service_Record.DsService
    Friend WithEvents OleDbSelectCommand2 As System.Data.OleDb.OleDbCommand
    Friend WithEvents OleDbInsertCommand2 As System.Data.OleDb.OleDbCommand
    Friend WithEvents OleDbUpdateCommand2 As System.Data.OleDb.OleDbCommand
    Friend WithEvents OleDbDeleteCommand2 As System.Data.OleDb.OleDbCommand
    Friend WithEvents daPartsDetails As System.Data.OleDb.OleDbDataAdapter
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.Panel1 = New System.Windows.Forms.Panel
        Me.Panel2 = New System.Windows.Forms.Panel
        Me.Label13 = New System.Windows.Forms.Label
        Me.PartsRecordList = New System.Windows.Forms.TabControl
        Me.Data = New System.Windows.Forms.TabPage
        Me.cbDatePurchase = New System.Windows.Forms.DateTimePicker
        Me.DsService = New Service_Record.DsService
        Me.grdPartsDetails = New System.Windows.Forms.DataGrid
        Me.Label4 = New System.Windows.Forms.Label
        Me.Label3 = New System.Windows.Forms.Label
        Me.Label2 = New System.Windows.Forms.Label
        Me.Label1 = New System.Windows.Forms.Label
        Me.txtCopierModel = New System.Windows.Forms.TextBox
        Me.txtAddress = New System.Windows.Forms.TextBox
        Me.TxtName = New System.Windows.Forms.TextBox
        Me.List = New System.Windows.Forms.TabPage
        Me.grdPartsRecordList = New System.Windows.Forms.DataGrid
        Me.Panel3 = New System.Windows.Forms.Panel
        Me.btnDelete = New System.Windows.Forms.Button
        Me.btnFirst = New System.Windows.Forms.Button
        Me.btnPrev = New System.Windows.Forms.Button
        Me.lblNavLocation = New System.Windows.Forms.Label
        Me.btnNext = New System.Windows.Forms.Button
        Me.btnLast = New System.Windows.Forms.Button
        Me.btnAdd = New System.Windows.Forms.Button
        Me.btnSave = New System.Windows.Forms.Button
        Me.btnExit = New System.Windows.Forms.Button
        Me.OleDbSelectCommand1 = New System.Data.OleDb.OleDbCommand
        Me.cnService = New System.Data.OleDb.OleDbConnection
        Me.OleDbInsertCommand1 = New System.Data.OleDb.OleDbCommand
        Me.OleDbUpdateCommand1 = New System.Data.OleDb.OleDbCommand
        Me.OleDbDeleteCommand1 = New System.Data.OleDb.OleDbCommand
        Me.daPartsRecord = New System.Data.OleDb.OleDbDataAdapter
        Me.OleDbSelectCommand2 = New System.Data.OleDb.OleDbCommand
        Me.OleDbInsertCommand2 = New System.Data.OleDb.OleDbCommand
        Me.OleDbUpdateCommand2 = New System.Data.OleDb.OleDbCommand
        Me.OleDbDeleteCommand2 = New System.Data.OleDb.OleDbCommand
        Me.daPartsDetails = New System.Data.OleDb.OleDbDataAdapter
        Me.Panel1.SuspendLayout()
        Me.Panel2.SuspendLayout()
        Me.PartsRecordList.SuspendLayout()
        Me.Data.SuspendLayout()
        CType(Me.DsService, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.grdPartsDetails, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.List.SuspendLayout()
        CType(Me.grdPartsRecordList, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel3.SuspendLayout()
        Me.SuspendLayout()
        '
        'Panel1
        '
        Me.Panel1.Controls.Add(Me.Panel2)
        Me.Panel1.Controls.Add(Me.PartsRecordList)
        Me.Panel1.Location = New System.Drawing.Point(8, 8)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(608, 384)
        Me.Panel1.TabIndex = 119
        '
        'Panel2
        '
        Me.Panel2.BackColor = System.Drawing.SystemColors.AppWorkspace
        Me.Panel2.Controls.Add(Me.Label13)
        Me.Panel2.Location = New System.Drawing.Point(6, 6)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(594, 38)
        Me.Panel2.TabIndex = 11
        '
        'Label13
        '
        Me.Label13.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label13.ForeColor = System.Drawing.SystemColors.HighlightText
        Me.Label13.Location = New System.Drawing.Point(4, 8)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(348, 23)
        Me.Label13.TabIndex = 0
        Me.Label13.Text = "Consumables/Parts Record"
        '
        'PartsRecordList
        '
        Me.PartsRecordList.Controls.Add(Me.Data)
        Me.PartsRecordList.Controls.Add(Me.List)
        Me.PartsRecordList.Location = New System.Drawing.Point(6, 54)
        Me.PartsRecordList.Name = "PartsRecordList"
        Me.PartsRecordList.SelectedIndex = 0
        Me.PartsRecordList.Size = New System.Drawing.Size(594, 324)
        Me.PartsRecordList.TabIndex = 0
        '
        'Data
        '
        Me.Data.Controls.Add(Me.cbDatePurchase)
        Me.Data.Controls.Add(Me.grdPartsDetails)
        Me.Data.Controls.Add(Me.Label4)
        Me.Data.Controls.Add(Me.Label3)
        Me.Data.Controls.Add(Me.Label2)
        Me.Data.Controls.Add(Me.Label1)
        Me.Data.Controls.Add(Me.txtCopierModel)
        Me.Data.Controls.Add(Me.txtAddress)
        Me.Data.Controls.Add(Me.TxtName)
        Me.Data.Location = New System.Drawing.Point(4, 22)
        Me.Data.Name = "Data"
        Me.Data.Size = New System.Drawing.Size(586, 298)
        Me.Data.TabIndex = 0
        Me.Data.Text = "Data"
        '
        'cbDatePurchase
        '
        Me.cbDatePurchase.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.DsService, "PartsRecord.DatePurchase"))
        Me.cbDatePurchase.Format = System.Windows.Forms.DateTimePickerFormat.Short
        Me.cbDatePurchase.Location = New System.Drawing.Point(450, 72)
        Me.cbDatePurchase.Name = "cbDatePurchase"
        Me.cbDatePurchase.Size = New System.Drawing.Size(117, 20)
        Me.cbDatePurchase.TabIndex = 27
        Me.cbDatePurchase.Value = New Date(2006, 3, 13, 0, 0, 0, 0)
        '
        'DsService
        '
        Me.DsService.DataSetName = "DsService"
        Me.DsService.Locale = New System.Globalization.CultureInfo("en-US")
        '
        'grdPartsDetails
        '
        Me.grdPartsDetails.DataMember = ""
        Me.grdPartsDetails.HeaderForeColor = System.Drawing.SystemColors.ControlText
        Me.grdPartsDetails.Location = New System.Drawing.Point(8, 96)
        Me.grdPartsDetails.Name = "grdPartsDetails"
        Me.grdPartsDetails.Size = New System.Drawing.Size(574, 192)
        Me.grdPartsDetails.TabIndex = 26
        '
        'Label4
        '
        Me.Label4.Location = New System.Drawing.Point(336, 72)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(104, 23)
        Me.Label4.TabIndex = 25
        Me.Label4.Text = "DATE PURCHASE:"
        Me.Label4.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'Label3
        '
        Me.Label3.Location = New System.Drawing.Point(24, 72)
        Me.Label3.Name = "Label3"
        Me.Label3.TabIndex = 24
        Me.Label3.Text = "COPIER MODEL:"
        Me.Label3.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label2
        '
        Me.Label2.Location = New System.Drawing.Point(24, 40)
        Me.Label2.Name = "Label2"
        Me.Label2.TabIndex = 23
        Me.Label2.Text = "ADDRESS:"
        Me.Label2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label1
        '
        Me.Label1.Location = New System.Drawing.Point(24, 8)
        Me.Label1.Name = "Label1"
        Me.Label1.TabIndex = 22
        Me.Label1.Text = "NAME:"
        Me.Label1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'txtCopierModel
        '
        Me.txtCopierModel.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.DsService, "PartsRecord.CopierModel"))
        Me.txtCopierModel.Location = New System.Drawing.Point(128, 72)
        Me.txtCopierModel.Name = "txtCopierModel"
        Me.txtCopierModel.Size = New System.Drawing.Size(190, 20)
        Me.txtCopierModel.TabIndex = 21
        Me.txtCopierModel.Text = ""
        '
        'txtAddress
        '
        Me.txtAddress.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.DsService, "PartsRecord.Address"))
        Me.txtAddress.Location = New System.Drawing.Point(128, 40)
        Me.txtAddress.Name = "txtAddress"
        Me.txtAddress.Size = New System.Drawing.Size(439, 20)
        Me.txtAddress.TabIndex = 20
        Me.txtAddress.Text = ""
        '
        'TxtName
        '
        Me.TxtName.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.DsService, "PartsRecord.Name"))
        Me.TxtName.Location = New System.Drawing.Point(128, 8)
        Me.TxtName.Name = "TxtName"
        Me.TxtName.Size = New System.Drawing.Size(439, 20)
        Me.TxtName.TabIndex = 19
        Me.TxtName.Text = ""
        '
        'List
        '
        Me.List.Controls.Add(Me.grdPartsRecordList)
        Me.List.Location = New System.Drawing.Point(4, 22)
        Me.List.Name = "List"
        Me.List.Size = New System.Drawing.Size(586, 298)
        Me.List.TabIndex = 1
        Me.List.Text = "List"
        Me.List.Visible = False
        '
        'grdPartsRecordList
        '
        Me.grdPartsRecordList.AllowNavigation = False
        Me.grdPartsRecordList.DataMember = ""
        Me.grdPartsRecordList.HeaderForeColor = System.Drawing.SystemColors.ControlText
        Me.grdPartsRecordList.Location = New System.Drawing.Point(8, 8)
        Me.grdPartsRecordList.Name = "grdPartsRecordList"
        Me.grdPartsRecordList.Size = New System.Drawing.Size(544, 288)
        Me.grdPartsRecordList.TabIndex = 0
        '
        'Panel3
        '
        Me.Panel3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Panel3.Controls.Add(Me.btnDelete)
        Me.Panel3.Controls.Add(Me.btnFirst)
        Me.Panel3.Controls.Add(Me.btnPrev)
        Me.Panel3.Controls.Add(Me.lblNavLocation)
        Me.Panel3.Controls.Add(Me.btnNext)
        Me.Panel3.Controls.Add(Me.btnLast)
        Me.Panel3.Controls.Add(Me.btnAdd)
        Me.Panel3.Controls.Add(Me.btnSave)
        Me.Panel3.Controls.Add(Me.btnExit)
        Me.Panel3.Location = New System.Drawing.Point(8, 400)
        Me.Panel3.Name = "Panel3"
        Me.Panel3.Size = New System.Drawing.Size(608, 33)
        Me.Panel3.TabIndex = 120
        '
        'btnDelete
        '
        Me.btnDelete.Location = New System.Drawing.Point(418, 4)
        Me.btnDelete.Name = "btnDelete"
        Me.btnDelete.TabIndex = 22
        Me.btnDelete.Text = "&Delete"
        '
        'btnFirst
        '
        Me.btnFirst.Location = New System.Drawing.Point(12, 4)
        Me.btnFirst.Name = "btnFirst"
        Me.btnFirst.Size = New System.Drawing.Size(40, 23)
        Me.btnFirst.TabIndex = 16
        Me.btnFirst.Text = "<<"
        '
        'btnPrev
        '
        Me.btnPrev.Location = New System.Drawing.Point(51, 4)
        Me.btnPrev.Name = "btnPrev"
        Me.btnPrev.Size = New System.Drawing.Size(35, 23)
        Me.btnPrev.TabIndex = 17
        Me.btnPrev.Text = "<"
        '
        'lblNavLocation
        '
        Me.lblNavLocation.BackColor = System.Drawing.Color.White
        Me.lblNavLocation.Location = New System.Drawing.Point(84, 4)
        Me.lblNavLocation.Name = "lblNavLocation"
        Me.lblNavLocation.Size = New System.Drawing.Size(95, 23)
        Me.lblNavLocation.TabIndex = 117
        Me.lblNavLocation.Text = "No Records"
        Me.lblNavLocation.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'btnNext
        '
        Me.btnNext.Location = New System.Drawing.Point(180, 4)
        Me.btnNext.Name = "btnNext"
        Me.btnNext.Size = New System.Drawing.Size(35, 23)
        Me.btnNext.TabIndex = 18
        Me.btnNext.Text = ">"
        '
        'btnLast
        '
        Me.btnLast.Location = New System.Drawing.Point(214, 4)
        Me.btnLast.Name = "btnLast"
        Me.btnLast.Size = New System.Drawing.Size(40, 23)
        Me.btnLast.TabIndex = 19
        Me.btnLast.Text = ">>"
        '
        'btnAdd
        '
        Me.btnAdd.Location = New System.Drawing.Point(267, 4)
        Me.btnAdd.Name = "btnAdd"
        Me.btnAdd.TabIndex = 20
        Me.btnAdd.Text = "&Add"
        '
        'btnSave
        '
        Me.btnSave.Location = New System.Drawing.Point(343, 4)
        Me.btnSave.Name = "btnSave"
        Me.btnSave.TabIndex = 21
        Me.btnSave.Text = "&Save"
        '
        'btnExit
        '
        Me.btnExit.Location = New System.Drawing.Point(493, 4)
        Me.btnExit.Name = "btnExit"
        Me.btnExit.TabIndex = 23
        Me.btnExit.Text = "E&xit"
        '
        'OleDbSelectCommand1
        '
        Me.OleDbSelectCommand1.CommandText = "SELECT Address, CopierModel, DatePurchase, Name, PartsID FROM PartsRecord"
        Me.OleDbSelectCommand1.Connection = Me.cnService
        '
        'cnService
        '
        Me.cnService.ConnectionString = "Jet OLEDB:Global Partial Bulk Ops=2;Jet OLEDB:Registry Path=;Jet OLEDB:Database L" & _
        "ocking Mode=1;Data Source=""E:\Project\Service Record\bin\Data\Service.mdb"";Jet O" & _
        "LEDB:Engine Type=5;Provider=""Microsoft.Jet.OLEDB.4.0"";Jet OLEDB:System database=" & _
        ";Jet OLEDB:SFP=False;persist security info=False;Extended Properties=;Mode=Share" & _
        " Deny None;Jet OLEDB:Encrypt Database=False;Jet OLEDB:Create System Database=Fal" & _
        "se;Jet OLEDB:Don't Copy Locale on Compact=False;Jet OLEDB:Compact Without Replic" & _
        "a Repair=False;User ID=Admin;Jet OLEDB:Global Bulk Transactions=1"
        '
        'OleDbInsertCommand1
        '
        Me.OleDbInsertCommand1.CommandText = "INSERT INTO PartsRecord(Address, CopierModel, DatePurchase, Name) VALUES (?, ?, ?" & _
        ", ?)"
        Me.OleDbInsertCommand1.Connection = Me.cnService
        Me.OleDbInsertCommand1.Parameters.Add(New System.Data.OleDb.OleDbParameter("Address", System.Data.OleDb.OleDbType.VarWChar, 50, "Address"))
        Me.OleDbInsertCommand1.Parameters.Add(New System.Data.OleDb.OleDbParameter("CopierModel", System.Data.OleDb.OleDbType.VarWChar, 50, "CopierModel"))
        Me.OleDbInsertCommand1.Parameters.Add(New System.Data.OleDb.OleDbParameter("DatePurchase", System.Data.OleDb.OleDbType.DBDate, 0, "DatePurchase"))
        Me.OleDbInsertCommand1.Parameters.Add(New System.Data.OleDb.OleDbParameter("Name", System.Data.OleDb.OleDbType.VarWChar, 50, "Name"))
        '
        'OleDbUpdateCommand1
        '
        Me.OleDbUpdateCommand1.CommandText = "UPDATE PartsRecord SET Address = ?, CopierModel = ?, DatePurchase = ?, Name = ? W" & _
        "HERE (PartsID = ?) AND (Address = ? OR ? IS NULL AND Address IS NULL) AND (Copie" & _
        "rModel = ? OR ? IS NULL AND CopierModel IS NULL) AND (DatePurchase = ? OR ? IS N" & _
        "ULL AND DatePurchase IS NULL) AND (Name = ? OR ? IS NULL AND Name IS NULL)"
        Me.OleDbUpdateCommand1.Connection = Me.cnService
        Me.OleDbUpdateCommand1.Parameters.Add(New System.Data.OleDb.OleDbParameter("Address", System.Data.OleDb.OleDbType.VarWChar, 50, "Address"))
        Me.OleDbUpdateCommand1.Parameters.Add(New System.Data.OleDb.OleDbParameter("CopierModel", System.Data.OleDb.OleDbType.VarWChar, 50, "CopierModel"))
        Me.OleDbUpdateCommand1.Parameters.Add(New System.Data.OleDb.OleDbParameter("DatePurchase", System.Data.OleDb.OleDbType.DBDate, 0, "DatePurchase"))
        Me.OleDbUpdateCommand1.Parameters.Add(New System.Data.OleDb.OleDbParameter("Name", System.Data.OleDb.OleDbType.VarWChar, 50, "Name"))
        Me.OleDbUpdateCommand1.Parameters.Add(New System.Data.OleDb.OleDbParameter("Original_PartsID", System.Data.OleDb.OleDbType.Integer, 0, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "PartsID", System.Data.DataRowVersion.Original, Nothing))
        Me.OleDbUpdateCommand1.Parameters.Add(New System.Data.OleDb.OleDbParameter("Original_Address", System.Data.OleDb.OleDbType.VarWChar, 50, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "Address", System.Data.DataRowVersion.Original, Nothing))
        Me.OleDbUpdateCommand1.Parameters.Add(New System.Data.OleDb.OleDbParameter("Original_Address1", System.Data.OleDb.OleDbType.VarWChar, 50, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "Address", System.Data.DataRowVersion.Original, Nothing))
        Me.OleDbUpdateCommand1.Parameters.Add(New System.Data.OleDb.OleDbParameter("Original_CopierModel", System.Data.OleDb.OleDbType.VarWChar, 50, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "CopierModel", System.Data.DataRowVersion.Original, Nothing))
        Me.OleDbUpdateCommand1.Parameters.Add(New System.Data.OleDb.OleDbParameter("Original_CopierModel1", System.Data.OleDb.OleDbType.VarWChar, 50, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "CopierModel", System.Data.DataRowVersion.Original, Nothing))
        Me.OleDbUpdateCommand1.Parameters.Add(New System.Data.OleDb.OleDbParameter("Original_DatePurchase", System.Data.OleDb.OleDbType.DBDate, 0, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "DatePurchase", System.Data.DataRowVersion.Original, Nothing))
        Me.OleDbUpdateCommand1.Parameters.Add(New System.Data.OleDb.OleDbParameter("Original_DatePurchase1", System.Data.OleDb.OleDbType.DBDate, 0, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "DatePurchase", System.Data.DataRowVersion.Original, Nothing))
        Me.OleDbUpdateCommand1.Parameters.Add(New System.Data.OleDb.OleDbParameter("Original_Name", System.Data.OleDb.OleDbType.VarWChar, 50, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "Name", System.Data.DataRowVersion.Original, Nothing))
        Me.OleDbUpdateCommand1.Parameters.Add(New System.Data.OleDb.OleDbParameter("Original_Name1", System.Data.OleDb.OleDbType.VarWChar, 50, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "Name", System.Data.DataRowVersion.Original, Nothing))
        '
        'OleDbDeleteCommand1
        '
        Me.OleDbDeleteCommand1.CommandText = "DELETE FROM PartsRecord WHERE (PartsID = ?) AND (Address = ? OR ? IS NULL AND Add" & _
        "ress IS NULL) AND (CopierModel = ? OR ? IS NULL AND CopierModel IS NULL) AND (Da" & _
        "tePurchase = ? OR ? IS NULL AND DatePurchase IS NULL) AND (Name = ? OR ? IS NULL" & _
        " AND Name IS NULL)"
        Me.OleDbDeleteCommand1.Connection = Me.cnService
        Me.OleDbDeleteCommand1.Parameters.Add(New System.Data.OleDb.OleDbParameter("Original_PartsID", System.Data.OleDb.OleDbType.Integer, 0, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "PartsID", System.Data.DataRowVersion.Original, Nothing))
        Me.OleDbDeleteCommand1.Parameters.Add(New System.Data.OleDb.OleDbParameter("Original_Address", System.Data.OleDb.OleDbType.VarWChar, 50, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "Address", System.Data.DataRowVersion.Original, Nothing))
        Me.OleDbDeleteCommand1.Parameters.Add(New System.Data.OleDb.OleDbParameter("Original_Address1", System.Data.OleDb.OleDbType.VarWChar, 50, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "Address", System.Data.DataRowVersion.Original, Nothing))
        Me.OleDbDeleteCommand1.Parameters.Add(New System.Data.OleDb.OleDbParameter("Original_CopierModel", System.Data.OleDb.OleDbType.VarWChar, 50, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "CopierModel", System.Data.DataRowVersion.Original, Nothing))
        Me.OleDbDeleteCommand1.Parameters.Add(New System.Data.OleDb.OleDbParameter("Original_CopierModel1", System.Data.OleDb.OleDbType.VarWChar, 50, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "CopierModel", System.Data.DataRowVersion.Original, Nothing))
        Me.OleDbDeleteCommand1.Parameters.Add(New System.Data.OleDb.OleDbParameter("Original_DatePurchase", System.Data.OleDb.OleDbType.DBDate, 0, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "DatePurchase", System.Data.DataRowVersion.Original, Nothing))
        Me.OleDbDeleteCommand1.Parameters.Add(New System.Data.OleDb.OleDbParameter("Original_DatePurchase1", System.Data.OleDb.OleDbType.DBDate, 0, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "DatePurchase", System.Data.DataRowVersion.Original, Nothing))
        Me.OleDbDeleteCommand1.Parameters.Add(New System.Data.OleDb.OleDbParameter("Original_Name", System.Data.OleDb.OleDbType.VarWChar, 50, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "Name", System.Data.DataRowVersion.Original, Nothing))
        Me.OleDbDeleteCommand1.Parameters.Add(New System.Data.OleDb.OleDbParameter("Original_Name1", System.Data.OleDb.OleDbType.VarWChar, 50, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "Name", System.Data.DataRowVersion.Original, Nothing))
        '
        'daPartsRecord
        '
        Me.daPartsRecord.DeleteCommand = Me.OleDbDeleteCommand1
        Me.daPartsRecord.InsertCommand = Me.OleDbInsertCommand1
        Me.daPartsRecord.SelectCommand = Me.OleDbSelectCommand1
        Me.daPartsRecord.TableMappings.AddRange(New System.Data.Common.DataTableMapping() {New System.Data.Common.DataTableMapping("Table", "PartsRecord", New System.Data.Common.DataColumnMapping() {New System.Data.Common.DataColumnMapping("Address", "Address"), New System.Data.Common.DataColumnMapping("CopierModel", "CopierModel"), New System.Data.Common.DataColumnMapping("DatePurchase", "DatePurchase"), New System.Data.Common.DataColumnMapping("Name", "Name"), New System.Data.Common.DataColumnMapping("PartsID", "PartsID")})})
        Me.daPartsRecord.UpdateCommand = Me.OleDbUpdateCommand1
        '
        'OleDbSelectCommand2
        '
        Me.OleDbSelectCommand2.CommandText = "SELECT [Date], Description, Encoder, MR, PartsDetailID, PartsID, Qty, RecordedBy " & _
        "FROM PartsDetails"
        Me.OleDbSelectCommand2.Connection = Me.cnService
        '
        'OleDbInsertCommand2
        '
        Me.OleDbInsertCommand2.CommandText = "INSERT INTO PartsDetails([Date], Description, Encoder, MR, PartsID, Qty, Recorded" & _
        "By) VALUES (?, ?, ?, ?, ?, ?, ?)"
        Me.OleDbInsertCommand2.Connection = Me.cnService
        Me.OleDbInsertCommand2.Parameters.Add(New System.Data.OleDb.OleDbParameter("Date", System.Data.OleDb.OleDbType.DBDate, 0, "Date"))
        Me.OleDbInsertCommand2.Parameters.Add(New System.Data.OleDb.OleDbParameter("Description", System.Data.OleDb.OleDbType.VarWChar, 50, "Description"))
        Me.OleDbInsertCommand2.Parameters.Add(New System.Data.OleDb.OleDbParameter("Encoder", System.Data.OleDb.OleDbType.VarWChar, 50, "Encoder"))
        Me.OleDbInsertCommand2.Parameters.Add(New System.Data.OleDb.OleDbParameter("MR", System.Data.OleDb.OleDbType.VarWChar, 50, "MR"))
        Me.OleDbInsertCommand2.Parameters.Add(New System.Data.OleDb.OleDbParameter("PartsID", System.Data.OleDb.OleDbType.Integer, 0, "PartsID"))
        Me.OleDbInsertCommand2.Parameters.Add(New System.Data.OleDb.OleDbParameter("Qty", System.Data.OleDb.OleDbType.VarWChar, 50, "Qty"))
        Me.OleDbInsertCommand2.Parameters.Add(New System.Data.OleDb.OleDbParameter("RecordedBy", System.Data.OleDb.OleDbType.VarWChar, 50, "RecordedBy"))
        '
        'OleDbUpdateCommand2
        '
        Me.OleDbUpdateCommand2.CommandText = "UPDATE PartsDetails SET [Date] = ?, Description = ?, Encoder = ?, MR = ?, PartsID" & _
        " = ?, Qty = ?, RecordedBy = ? WHERE (PartsDetailID = ?) AND ([Date] = ? OR ? IS " & _
        "NULL AND [Date] IS NULL) AND (Description = ? OR ? IS NULL AND Description IS NU" & _
        "LL) AND (Encoder = ? OR ? IS NULL AND Encoder IS NULL) AND (MR = ? OR ? IS NULL " & _
        "AND MR IS NULL) AND (PartsID = ? OR ? IS NULL AND PartsID IS NULL) AND (Qty = ? " & _
        "OR ? IS NULL AND Qty IS NULL) AND (RecordedBy = ? OR ? IS NULL AND RecordedBy IS" & _
        " NULL)"
        Me.OleDbUpdateCommand2.Connection = Me.cnService
        Me.OleDbUpdateCommand2.Parameters.Add(New System.Data.OleDb.OleDbParameter("Date", System.Data.OleDb.OleDbType.DBDate, 0, "Date"))
        Me.OleDbUpdateCommand2.Parameters.Add(New System.Data.OleDb.OleDbParameter("Description", System.Data.OleDb.OleDbType.VarWChar, 50, "Description"))
        Me.OleDbUpdateCommand2.Parameters.Add(New System.Data.OleDb.OleDbParameter("Encoder", System.Data.OleDb.OleDbType.VarWChar, 50, "Encoder"))
        Me.OleDbUpdateCommand2.Parameters.Add(New System.Data.OleDb.OleDbParameter("MR", System.Data.OleDb.OleDbType.VarWChar, 50, "MR"))
        Me.OleDbUpdateCommand2.Parameters.Add(New System.Data.OleDb.OleDbParameter("PartsID", System.Data.OleDb.OleDbType.Integer, 0, "PartsID"))
        Me.OleDbUpdateCommand2.Parameters.Add(New System.Data.OleDb.OleDbParameter("Qty", System.Data.OleDb.OleDbType.VarWChar, 50, "Qty"))
        Me.OleDbUpdateCommand2.Parameters.Add(New System.Data.OleDb.OleDbParameter("RecordedBy", System.Data.OleDb.OleDbType.VarWChar, 50, "RecordedBy"))
        Me.OleDbUpdateCommand2.Parameters.Add(New System.Data.OleDb.OleDbParameter("Original_PartsDetailID", System.Data.OleDb.OleDbType.Integer, 0, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "PartsDetailID", System.Data.DataRowVersion.Original, Nothing))
        Me.OleDbUpdateCommand2.Parameters.Add(New System.Data.OleDb.OleDbParameter("Original_Date", System.Data.OleDb.OleDbType.DBDate, 0, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "Date", System.Data.DataRowVersion.Original, Nothing))
        Me.OleDbUpdateCommand2.Parameters.Add(New System.Data.OleDb.OleDbParameter("Original_Date1", System.Data.OleDb.OleDbType.DBDate, 0, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "Date", System.Data.DataRowVersion.Original, Nothing))
        Me.OleDbUpdateCommand2.Parameters.Add(New System.Data.OleDb.OleDbParameter("Original_Description", System.Data.OleDb.OleDbType.VarWChar, 50, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "Description", System.Data.DataRowVersion.Original, Nothing))
        Me.OleDbUpdateCommand2.Parameters.Add(New System.Data.OleDb.OleDbParameter("Original_Description1", System.Data.OleDb.OleDbType.VarWChar, 50, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "Description", System.Data.DataRowVersion.Original, Nothing))
        Me.OleDbUpdateCommand2.Parameters.Add(New System.Data.OleDb.OleDbParameter("Original_Encoder", System.Data.OleDb.OleDbType.VarWChar, 50, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "Encoder", System.Data.DataRowVersion.Original, Nothing))
        Me.OleDbUpdateCommand2.Parameters.Add(New System.Data.OleDb.OleDbParameter("Original_Encoder1", System.Data.OleDb.OleDbType.VarWChar, 50, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "Encoder", System.Data.DataRowVersion.Original, Nothing))
        Me.OleDbUpdateCommand2.Parameters.Add(New System.Data.OleDb.OleDbParameter("Original_MR", System.Data.OleDb.OleDbType.VarWChar, 50, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "MR", System.Data.DataRowVersion.Original, Nothing))
        Me.OleDbUpdateCommand2.Parameters.Add(New System.Data.OleDb.OleDbParameter("Original_MR1", System.Data.OleDb.OleDbType.VarWChar, 50, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "MR", System.Data.DataRowVersion.Original, Nothing))
        Me.OleDbUpdateCommand2.Parameters.Add(New System.Data.OleDb.OleDbParameter("Original_PartsID", System.Data.OleDb.OleDbType.Integer, 0, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "PartsID", System.Data.DataRowVersion.Original, Nothing))
        Me.OleDbUpdateCommand2.Parameters.Add(New System.Data.OleDb.OleDbParameter("Original_PartsID1", System.Data.OleDb.OleDbType.Integer, 0, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "PartsID", System.Data.DataRowVersion.Original, Nothing))
        Me.OleDbUpdateCommand2.Parameters.Add(New System.Data.OleDb.OleDbParameter("Original_Qty", System.Data.OleDb.OleDbType.VarWChar, 50, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "Qty", System.Data.DataRowVersion.Original, Nothing))
        Me.OleDbUpdateCommand2.Parameters.Add(New System.Data.OleDb.OleDbParameter("Original_Qty1", System.Data.OleDb.OleDbType.VarWChar, 50, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "Qty", System.Data.DataRowVersion.Original, Nothing))
        Me.OleDbUpdateCommand2.Parameters.Add(New System.Data.OleDb.OleDbParameter("Original_RecordedBy", System.Data.OleDb.OleDbType.VarWChar, 50, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "RecordedBy", System.Data.DataRowVersion.Original, Nothing))
        Me.OleDbUpdateCommand2.Parameters.Add(New System.Data.OleDb.OleDbParameter("Original_RecordedBy1", System.Data.OleDb.OleDbType.VarWChar, 50, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "RecordedBy", System.Data.DataRowVersion.Original, Nothing))
        '
        'OleDbDeleteCommand2
        '
        Me.OleDbDeleteCommand2.CommandText = "DELETE FROM PartsDetails WHERE (PartsDetailID = ?) AND ([Date] = ? OR ? IS NULL A" & _
        "ND [Date] IS NULL) AND (Description = ? OR ? IS NULL AND Description IS NULL) AN" & _
        "D (Encoder = ? OR ? IS NULL AND Encoder IS NULL) AND (MR = ? OR ? IS NULL AND MR" & _
        " IS NULL) AND (PartsID = ? OR ? IS NULL AND PartsID IS NULL) AND (Qty = ? OR ? I" & _
        "S NULL AND Qty IS NULL) AND (RecordedBy = ? OR ? IS NULL AND RecordedBy IS NULL)" & _
        ""
        Me.OleDbDeleteCommand2.Connection = Me.cnService
        Me.OleDbDeleteCommand2.Parameters.Add(New System.Data.OleDb.OleDbParameter("Original_PartsDetailID", System.Data.OleDb.OleDbType.Integer, 0, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "PartsDetailID", System.Data.DataRowVersion.Original, Nothing))
        Me.OleDbDeleteCommand2.Parameters.Add(New System.Data.OleDb.OleDbParameter("Original_Date", System.Data.OleDb.OleDbType.DBDate, 0, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "Date", System.Data.DataRowVersion.Original, Nothing))
        Me.OleDbDeleteCommand2.Parameters.Add(New System.Data.OleDb.OleDbParameter("Original_Date1", System.Data.OleDb.OleDbType.DBDate, 0, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "Date", System.Data.DataRowVersion.Original, Nothing))
        Me.OleDbDeleteCommand2.Parameters.Add(New System.Data.OleDb.OleDbParameter("Original_Description", System.Data.OleDb.OleDbType.VarWChar, 50, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "Description", System.Data.DataRowVersion.Original, Nothing))
        Me.OleDbDeleteCommand2.Parameters.Add(New System.Data.OleDb.OleDbParameter("Original_Description1", System.Data.OleDb.OleDbType.VarWChar, 50, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "Description", System.Data.DataRowVersion.Original, Nothing))
        Me.OleDbDeleteCommand2.Parameters.Add(New System.Data.OleDb.OleDbParameter("Original_Encoder", System.Data.OleDb.OleDbType.VarWChar, 50, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "Encoder", System.Data.DataRowVersion.Original, Nothing))
        Me.OleDbDeleteCommand2.Parameters.Add(New System.Data.OleDb.OleDbParameter("Original_Encoder1", System.Data.OleDb.OleDbType.VarWChar, 50, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "Encoder", System.Data.DataRowVersion.Original, Nothing))
        Me.OleDbDeleteCommand2.Parameters.Add(New System.Data.OleDb.OleDbParameter("Original_MR", System.Data.OleDb.OleDbType.VarWChar, 50, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "MR", System.Data.DataRowVersion.Original, Nothing))
        Me.OleDbDeleteCommand2.Parameters.Add(New System.Data.OleDb.OleDbParameter("Original_MR1", System.Data.OleDb.OleDbType.VarWChar, 50, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "MR", System.Data.DataRowVersion.Original, Nothing))
        Me.OleDbDeleteCommand2.Parameters.Add(New System.Data.OleDb.OleDbParameter("Original_PartsID", System.Data.OleDb.OleDbType.Integer, 0, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "PartsID", System.Data.DataRowVersion.Original, Nothing))
        Me.OleDbDeleteCommand2.Parameters.Add(New System.Data.OleDb.OleDbParameter("Original_PartsID1", System.Data.OleDb.OleDbType.Integer, 0, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "PartsID", System.Data.DataRowVersion.Original, Nothing))
        Me.OleDbDeleteCommand2.Parameters.Add(New System.Data.OleDb.OleDbParameter("Original_Qty", System.Data.OleDb.OleDbType.VarWChar, 50, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "Qty", System.Data.DataRowVersion.Original, Nothing))
        Me.OleDbDeleteCommand2.Parameters.Add(New System.Data.OleDb.OleDbParameter("Original_Qty1", System.Data.OleDb.OleDbType.VarWChar, 50, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "Qty", System.Data.DataRowVersion.Original, Nothing))
        Me.OleDbDeleteCommand2.Parameters.Add(New System.Data.OleDb.OleDbParameter("Original_RecordedBy", System.Data.OleDb.OleDbType.VarWChar, 50, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "RecordedBy", System.Data.DataRowVersion.Original, Nothing))
        Me.OleDbDeleteCommand2.Parameters.Add(New System.Data.OleDb.OleDbParameter("Original_RecordedBy1", System.Data.OleDb.OleDbType.VarWChar, 50, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "RecordedBy", System.Data.DataRowVersion.Original, Nothing))
        '
        'daPartsDetails
        '
        Me.daPartsDetails.DeleteCommand = Me.OleDbDeleteCommand2
        Me.daPartsDetails.InsertCommand = Me.OleDbInsertCommand2
        Me.daPartsDetails.SelectCommand = Me.OleDbSelectCommand2
        Me.daPartsDetails.TableMappings.AddRange(New System.Data.Common.DataTableMapping() {New System.Data.Common.DataTableMapping("Table", "PartsDetails", New System.Data.Common.DataColumnMapping() {New System.Data.Common.DataColumnMapping("Date", "Date"), New System.Data.Common.DataColumnMapping("Description", "Description"), New System.Data.Common.DataColumnMapping("Encoder", "Encoder"), New System.Data.Common.DataColumnMapping("MR", "MR"), New System.Data.Common.DataColumnMapping("PartsDetailID", "PartsDetailID"), New System.Data.Common.DataColumnMapping("PartsID", "PartsID"), New System.Data.Common.DataColumnMapping("Qty", "Qty"), New System.Data.Common.DataColumnMapping("RecordedBy", "RecordedBy")})})
        Me.daPartsDetails.UpdateCommand = Me.OleDbUpdateCommand2
        '
        'Parts1
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(624, 440)
        Me.Controls.Add(Me.Panel1)
        Me.Controls.Add(Me.Panel3)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.Name = "Parts1"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Parts"
        Me.Panel1.ResumeLayout(False)
        Me.Panel2.ResumeLayout(False)
        Me.PartsRecordList.ResumeLayout(False)
        Me.Data.ResumeLayout(False)
        CType(Me.DsService, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.grdPartsDetails, System.ComponentModel.ISupportInitialize).EndInit()
        Me.List.ResumeLayout(False)
        CType(Me.grdPartsRecordList, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel3.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub

#End Region
    Protected Overrides Function ProcessCmdKey(ByRef msg As System.Windows.Forms.Message, ByVal keyData As System.Windows.Forms.Keys) As Boolean
        Select Case msg.WParam.ToInt32()
            Case 13 ' enter Key 
                If TypeOf Me.ActiveControl Is TextBox Or TypeOf Me.ActiveControl Is ComboBox Then
                    SendKeys.Send("{Tab}")
                    Return True
                End If
        End Select
        Return MyBase.ProcessCmdKey(msg, keyData)
    End Function 'ProcessCmdKey 

    Private Sub btnExit_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnExit.Click
        Save_Record()
        Me.Close()
    End Sub

    Private Sub Parts_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        cnService.ConnectionString = cnSettings()

        daPartsRecord.Fill(DsService)
        daPartsDetails.Fill(DsService)

        BindPartsDetails()
        BindPartsRecordList()

        AddHandler Me.BindingContext(DsService, "PartsRecord").PositionChanged, _
            AddressOf PartsRecord_PositionChanged

        DisplayNav(sender, e)
    End Sub

    Sub BindPartsDetails()

        With grdPartsDetails
            .CaptionText = "Parts Details"
            .DataMember = "PartsRecord.PartsRecordDetails"
            .DataSource = DsService
        End With

        ' You must clear out the TableStyles collection before 
        grdPartsDetails.TableStyles.Clear()

        Dim grdTableStyle1 As New DataGridTableStyle
        With grdTableStyle1
            .MappingName = "PartsDetails"
        End With

        Dim grdColStyle1 As New DataGridTextBoxColumn
        With grdColStyle1
            .MappingName = "Date"
            .HeaderText = "Date"
            .NullText = ""
            .Width = 80
        End With

        Dim grdColStyle2 As New DataGridTextBoxColumn
        With grdColStyle2
            .MappingName = "Qty"
            .HeaderText = "Qty"
            .NullText = ""
            .Width = 50
        End With

        Dim grdColStyle3 As New DataGridTextBoxColumn
        With grdColStyle3
            .MappingName = "Description"
            .HeaderText = "Description"
            .NullText = ""
            .Width = 200
        End With

        Dim grdColStyle4 As New DataGridTextBoxColumn
        With grdColStyle4
            .MappingName = "MR"
            .HeaderText = "MR"
            .NullText = ""
            .Width = 75
        End With

        Dim grdColStyle5 As New DataGridTextBoxColumn
        With grdColStyle5
            .MappingName = "RecordedBy"
            .HeaderText = "RecordedBy"
            .NullText = ""
            .Width = 75
        End With

        Dim grdColStyle6 As New DataGridTextBoxColumn
        With grdColStyle6
            .MappingName = "Encoder"
            .HeaderText = "Encoder"
            .NullText = ""
            .Width = 50
            .ReadOnly = True
            DsService.Tables("PartsRecord").ChildRelations("PartsRecordDetails").ChildTable.Columns("Encoder").DefaultValue = strUser
        End With

        grdTableStyle1.GridColumnStyles.AddRange _
            (New DataGridColumnStyle() {grdColStyle1, grdColStyle2, _
            grdColStyle3, grdColStyle4, grdColStyle5, grdColStyle6})
        grdPartsDetails.TableStyles.Add(grdTableStyle1)
    End Sub

    Sub BindPartsRecordList()

        With grdPartsRecordList
            .CaptionText = "PartsRecord"
            .DataMember = "PartsRecord"
            .DataSource = DsService
        End With

        ' You must clear out the TableStyles collection before 
        grdPartsRecordList.TableStyles.Clear()

        Dim grdTableStyle1 As New DataGridTableStyle
        With grdTableStyle1
            .MappingName = "PartsRecord"
        End With

        Dim grdColStyle1 As New DataGridTextBoxColumn
        With grdColStyle1
            .MappingName = "Name"
            .HeaderText = "Name"
            .NullText = ""
            .Width = 150
        End With

        Dim grdColStyle2 As New DataGridTextBoxColumn
        With grdColStyle2
            .MappingName = "Address"
            .HeaderText = "Address"
            .NullText = ""
            .Width = 200
        End With

        Dim grdColStyle3 As New DataGridTextBoxColumn
        With grdColStyle3
            .MappingName = "CopierModel"
            .HeaderText = "CopierModel"
            .NullText = ""
            .Width = 100
        End With

        Dim grdColStyle4 As New DataGridTextBoxColumn
        With grdColStyle4
            .MappingName = "DatePurchase"
            .HeaderText = "DatePurchase"
            .NullText = ""
            .Width = 100
        End With

        grdTableStyle1.GridColumnStyles.AddRange _
            (New DataGridColumnStyle() {grdColStyle1, grdColStyle2, _
            grdColStyle3, grdColStyle4})
        grdPartsRecordList.TableStyles.Add(grdTableStyle1)
    End Sub

    Private Sub btnNext_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnNext.Click
        Save_Record()
        Me.BindingContext(DsService, "PartsRecord").Position += 1
    End Sub

    Private Sub btnPrev_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnPrev.Click
        Save_Record()
        Me.BindingContext(DsService, "PartsRecord").Position -= 1
    End Sub

    Private Sub btnLast_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnLast.Click
        Save_Record()
        Me.BindingContext(DsService, "PartsRecord").Position = Me.BindingContext(DsService, "PartsRecord").Count - 1
    End Sub

    Private Sub btnFirst_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnFirst.Click
        Save_Record()
        Me.BindingContext(DsService, "PartsRecord").Position = 0
    End Sub

    Private Sub btnAdd_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnAdd.Click
        If btnAdd.Text = "&Add" Then
            Me.BindingContext(DsService, "PartsRecord").AddNew()
            Change_Button(False)
            btnAdd.Text = "&Revert"
        Else
            Me.BindingContext(DsService, "PartsRecord").CancelCurrentEdit()
            Change_Button(True)
            btnAdd.Text = "&Add"
            DisplayNav(sender, e)
        End If
    End Sub

    Private Sub btnSave_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSave.Click
        Try
            If btnAdd.Text = "&Revert" Then
                If TxtName.Text = "" Then
                    MessageBox.Show("Please don't leave Customer field blank.", "Error", MessageBoxButtons.OK)
                    Exit Sub
                End If
            End If
            Save_Record()
            Change_Button(True)
            btnAdd.Text = "&Add"

            DisplayNav(sender, e)
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
    End Sub

    Private Sub btnDelete_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnDelete.Click
        Try
            If MsgBox("Are you sure you want to delete this record?", MsgBoxStyle.YesNo) = MsgBoxResult.No Then Exit Sub

            Me.BindingContext(DsService, "PartsRecord").RemoveAt(Me.BindingContext(DsService, "PartsRecord").Position)

            Save_Record()

            DisplayNav(sender, e)
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
    End Sub

    Private Sub Save_Record()
        Try
            Me.BindingContext(DsService, "PartsRecord").EndCurrentEdit()

            daPartsRecord.Update(DsService)
            daPartsDetails.Update(DsService)
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
    End Sub

    Private Sub Change_Button(ByVal bval As Boolean)
        btnFirst.Enabled = bval
        btnPrev.Enabled = bval
        btnNext.Enabled = bval
        btnLast.Enabled = bval
        btnDelete.Enabled = bval
        btnExit.Enabled = bval
    End Sub

    Private Sub DisplayNav(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnFirst.Click, btnPrev.Click, btnNext.Click, btnLast.Click, btnDelete.Click
        'Update record position when Update & Delete events
        lblNavLocation.Text = Me.BindingContext(DsService, "PartsRecord").Position + 1 & " of " & Me.BindingContext(DsService, "PartsRecord").Count
    End Sub

    Private Sub PartsRecord_PositionChanged(ByVal sender As Object, ByVal e As System.EventArgs)
        DisplayNav(sender, e)
    End Sub

    Private Sub grdPartsDetails_Enter(ByVal sender As Object, ByVal e As System.EventArgs) Handles grdPartsDetails.Enter
        If TxtName.Text = "" Then
            MessageBox.Show("Enter students idno information before entering school year and semester.")

            Me.TxtName.Focus()
        Else
            Me.BindingContext(DsService, "PartsRecord").EndCurrentEdit()

            daPartsRecord.Update(DsService)
        End If
    End Sub
End Class

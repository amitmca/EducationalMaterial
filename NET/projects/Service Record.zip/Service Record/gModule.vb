Imports System.Data.OleDb

Module gModule
    Public CompDB As String
    Public intAddressID As Integer
    Public intCustomerID As Integer
    Public blnLogin As Boolean
    Public strUser As String 'Use to determine the encoder

    Public Function DB_Path()
        Dim dbConn As OleDbConnection
        Dim dbCommand As New OleDbCommand
        Dim strPath As String

        dbConn = New OleDbConnection("Provider=Microsoft.Jet.OLEDB.4.0;Data Source=" & Application.StartupPath & "\dbpath.mdb;Jet OLEDB:Database Password=jay")
        dbCommand.CommandText = "SELECT * FROM Path"
        dbCommand.Connection = dbConn
        dbConn.Open()
        Dim dbDR As OleDb.OleDbDataReader = dbCommand.ExecuteReader

        dbDR.Read()
        strPath = dbDR("Path".ToString)

        dbConn.Close()

        Return strPath
    End Function

    Public Function cnSettings() As String
        Return "Provider=Microsoft.Jet.OLEDB.4.0;Data Source=" & DB_Path() & ";Jet OLEDB:Database Password=jay"
    End Function

End Module

